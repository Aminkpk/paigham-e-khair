const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const TEEN_UID = "teen_789";
const ADMIN_EMAIL = "kpkricecompny@gmail.com";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function serverTime(testEnvContext) {
  // In rules-unit-testing, Date() or FieldValue works; use serverTimestamp
  const { serverTimestamp } = require("firebase/firestore");
  return serverTimestamp();
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfile(uid, ageGroup = "ADULT") {
  const now = new Date();
  return {
    userId: uid,
    displayName: "Zaid Ahmad",
    ageGroup,
    language: "ur",
    onboardingCompleted: true,
    dailyReminderEnabled: true,
    teenSafeMode: ageGroup === "TEEN",
    blockedUserIds: [],
    completedDaysCount: 0,
    totalGoodDeedsCount: 0,
    currentStreak: 0,
    lastActivityDate: "2026-11-14",
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user cannot read users, lessons, or communityPosts", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("lessons").where("published", "==", true).get());
  await assertFails(unauthDb.collection("communityPosts").where("status", "==", "APPROVED").get());
});

test("User can create and read own profile, but cannot read Bob's profile or list users", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(aliceDb.collection("users").get());
});

test("Teen user cannot disable teenSafeMode", async () => {
  const teenDb = testEnv.authenticatedContext(TEEN_UID).firestore();
  const badTeenProfile = validProfile(TEEN_UID, "TEEN");
  badTeenProfile.teenSafeMode = false;
  await assertFails(teenDb.collection("users").doc(TEEN_UID).set(badTeenProfile));
});

test("Shadow update with ghost field on user profile is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const payload = validProfile(ALICE_UID);
  payload.isAdmin = true;
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).set(payload));
});

test("User can manage own lessonProgress and goodDeeds, isolated from other users", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date();

  const progressPayload = {
    userId: ALICE_UID,
    lessonDay: 1,
    completed: true,
    bookmarked: true,
    activityCompleted: false,
    reflectionText: "I will reflect on my purpose today.",
    bestQuizScore: 100,
    quizAttempts: 1,
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("lessonProgress").doc("day_1").set(progressPayload)
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("lessonProgress").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("lessonProgress").get()
  );

  const deedPayload = {
    userId: ALICE_UID,
    deedKey: "kind_speech",
    titleUrdu: "نرم گفتاری",
    titleEnglish: "Speak kindly",
    category: "character",
    note: "Helped a neighbor",
    dateKey: "2026-11-14",
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("goodDeeds").doc("deed_1").set(deedPayload)
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("goodDeeds").doc("deed_1").get()
  );
});

test("Community posts allow adult creation and helpful increment, block TEEN posting and status tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const teenDb = testEnv.authenticatedContext(TEEN_UID).firestore();
  const now = new Date();

  const post = {
    authorUid: ALICE_UID,
    authorDisplayName: "Alice",
    authorAgeGroup: "ADULT",
    topic: "COMMUNITY_SERVICE",
    content: "Organized a clean street drive with our neighbors.",
    status: "APPROVED",
    helpfulCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(aliceDb.collection("communityPosts").doc("post_1").set(post));

  // Teen cannot create public community post
  await assertFails(
    teenDb.collection("communityPosts").doc("post_teen").set({
      ...post,
      authorUid: TEEN_UID,
      authorAgeGroup: "TEEN",
    })
  );

  // Bob can read approved posts with matching filter, fail without filter
  await assertSucceeds(
    bobDb.collection("communityPosts").where("status", "==", "APPROVED").get()
  );
  await assertFails(bobDb.collection("communityPosts").get());

  // Bob can increment helpfulCount by 1
  await assertSucceeds(
    bobDb.collection("communityPosts").doc("post_1").update({
      helpfulCount: 1,
      updatedAt: now,
    })
  );

  // Bob cannot jump helpfulCount by 10 or edit content
  await assertFails(
    bobDb.collection("communityPosts").doc("post_1").update({
      helpfulCount: 11,
      updatedAt: now,
    })
  );
});

test("Email spoofing test: unverified admin email is rejected from admin writes", async () => {
  const spoofedAdminDb = testEnv
    .authenticatedContext("spoof_1", { email: ADMIN_EMAIL, email_verified: false })
    .firestore();
  const now = new Date();

  await assertFails(
    spoofedAdminDb.collection("announcements").doc("ann_1").set({
      titleUrdu: "اعلان",
      titleEnglish: "Announcement",
      bodyUrdu: "خوش آمدید",
      bodyEnglish: "Welcome",
      active: true,
      authorUid: "spoof_1",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Verified admin can publish announcements, lessons, and review content reports", async () => {
  const adminDb = testEnv
    .authenticatedContext("admin_1", { email: ADMIN_EMAIL, email_verified: true })
    .firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    adminDb.collection("announcements").doc("ann_1").set({
      titleUrdu: "رمضان پروگرام",
      titleEnglish: "Program Launch",
      bodyUrdu: "30 روزہ کورس شروع ہو چکا ہے۔",
      bodyEnglish: "30-day program has started.",
      active: true,
      authorUid: "admin_1",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("announcements").where("active", "==", true).get()
  );

  // Alice creates a report
  await assertSucceeds(
    aliceDb.collection("contentReports").doc("rep_1").set({
      reporterUid: ALICE_UID,
      targetType: "LESSON_FEEDBACK",
      targetId: "day_1",
      reason: "Please add more youth examples.",
      status: "OPEN",
      adminNote: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice cannot update report status
  await assertFails(
    aliceDb.collection("contentReports").doc("rep_1").update({
      status: "REVIEWED",
      adminNote: "Self approved",
      updatedAt: now,
    })
  );

  // Verified admin can review report
  await assertSucceeds(
    adminDb.collection("contentReports").doc("rep_1").update({
      status: "REVIEWED",
      adminNote: "Added in next curriculum update.",
      updatedAt: now,
    })
  );
});

package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AudioPlaybackState {
    IDLE,
    PLAYING,
    PAUSED,
    UNAVAILABLE
}

data class AudioPlayerStatus(
    val playbackState: AudioPlaybackState = AudioPlaybackState.IDLE,
    val speed: Float = 1.0f,
    val isUrduVoiceAvailable: Boolean = false,
    val isEnglishVoiceAvailable: Boolean = false,
    val activeLanguageIsUrdu: Boolean = true,
    val statusNoteUr: String = "صوتی خواندگی کی جانچ ہو رہی ہے...",
    val statusNoteEn: String = "Checking device voice availability..."
)

class LessonAudioPlayer(context: Context) {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var currentText: String = ""
    private var currentIsUrdu: Boolean = true

    private val _status = MutableStateFlow(AudioPlayerStatus())
    val status: StateFlow<AudioPlayerStatus> = _status.asStateFlow()

    init {
        tts = TextToSpeech(appContext) { initStatus ->
            if (initStatus == TextToSpeech.SUCCESS) {
                isInitialized = true
                val urduLocale = Locale.forLanguageTag("ur-PK")
                val urduSupport = tts?.isLanguageAvailable(urduLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                val urFallback = tts?.isLanguageAvailable(Locale.forLanguageTag("ur")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                val engSupport = tts?.isLanguageAvailable(Locale.US) ?: TextToSpeech.LANG_NOT_SUPPORTED

                val hasUrdu = urduSupport >= TextToSpeech.LANG_AVAILABLE || urFallback >= TextToSpeech.LANG_AVAILABLE
                val hasEng = engSupport >= TextToSpeech.LANG_AVAILABLE

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _status.value = _status.value.copy(playbackState = AudioPlaybackState.PLAYING)
                    }

                    override fun onDone(utteranceId: String?) {
                        _status.value = _status.value.copy(playbackState = AudioPlaybackState.IDLE)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _status.value = _status.value.copy(playbackState = AudioPlaybackState.IDLE)
                    }
                })

                _status.value = _status.value.copy(
                    isUrduVoiceAvailable = hasUrdu,
                    isEnglishVoiceAvailable = hasEng,
                    statusNoteUr = if (hasUrdu) {
                        "آپ کے آلے پر اردو صوتی خواندگی دستیاب ہے۔"
                    } else {
                        "آپ کے آلے پر اردو TTS آواز انسٹال نہیں ہے۔ تحریری سبق مکمل دستیاب ہے؛ انگریزی آواز یا ایڈمن آڈیو لنک استعمال کیا جا سکتا ہے۔"
                    },
                    statusNoteEn = if (hasEng) {
                        "Device speech engine is ready."
                    } else {
                        "Device speech voice is unavailable — full text-based lesson is ready below."
                    }
                )
            } else {
                _status.value = _status.value.copy(
                    playbackState = AudioPlaybackState.UNAVAILABLE,
                    statusNoteUr = "اس آلے پر صوتی انجن دستیاب نہیں — تحریری سبق مکمل طور پر دستیاب ہے۔",
                    statusNoteEn = "Text-to-Speech engine unavailable on this device — text lesson is ready."
                )
            }
        }
    }

    fun play(text: String, isUrdu: Boolean) {
        currentText = text
        currentIsUrdu = isUrdu
        if (!isInitialized) return

        val engine = tts ?: return
        val canSpeakLang = if (isUrdu) _status.value.isUrduVoiceAvailable else _status.value.isEnglishVoiceAvailable
        if (!canSpeakLang) {
            _status.value = _status.value.copy(
                playbackState = AudioPlaybackState.UNAVAILABLE,
                activeLanguageIsUrdu = isUrdu
            )
            return
        }

        val targetLocale = if (isUrdu) Locale.forLanguageTag("ur-PK") else Locale.US
        engine.language = targetLocale
        engine.setSpeechRate(_status.value.speed)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lesson_utterance")
        _status.value = _status.value.copy(
            playbackState = AudioPlaybackState.PLAYING,
            activeLanguageIsUrdu = isUrdu
        )
    }

    fun pauseOrStop() {
        tts?.stop()
        _status.value = _status.value.copy(playbackState = AudioPlaybackState.PAUSED)
    }

    fun resumeOrReplay(text: String, isUrdu: Boolean) {
        val toSpeak = if (currentText.isNotBlank()) currentText else text
        play(toSpeak, isUrdu)
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.75f, 1.5f)
        _status.value = _status.value.copy(speed = clamped)
        tts?.setSpeechRate(clamped)
        if (_status.value.playbackState == AudioPlaybackState.PLAYING && currentText.isNotBlank()) {
            play(currentText, currentIsUrdu)
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

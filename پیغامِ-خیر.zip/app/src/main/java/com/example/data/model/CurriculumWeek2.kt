package com.example.data.model

object CurriculumWeek2 {
    val lessons: List<CuratedLesson> = listOf(
        CuratedLesson(
            dayNumber = 8,
            weekNumber = 2,
            categoryIds = listOf("family_life", "islamic_character", "youth_development"),
            titleUr = "والدین کے حقوق اور احترام",
            titleEn = "Rights and Respect of Parents",
            objectivesUr = listOf(
                "قرآن و سنت کی روشنی میں والدین کے بلند مقام کو سمجھنا۔",
                "گفتگو، لہجے اور خدمت میں والدین کے ساتھ احسان کرنا۔",
                "والدین کی وفات کے بعد بھی دعا اور نیکی کے ذریعے خدمت جاری رکھنا۔"
            ),
            objectivesEn = listOf(
                "Appreciate the elevated status of parents in the Quran and Sunnah.",
                "Practice gentleness in tone, patience, and practical service to parents.",
                "Honor parents through ongoing kindness and prayer throughout life."
            ),
            introUr = "دنیا میں اللہ کی رضا اور برکت کا سب سے قریبی دروازہ والدین کی خدمت اور ان کا دل خوش رکھنا ہے۔",
            introEn = "One of the closest doors to blessing and Allah's pleasure in this world is honoring and caring for one's parents.",
            explanationUr = "قرآن کریم میں اللہ تعالیٰ نے اپنی بندگی کے فوراً بعد والدین کے ساتھ حسنِ سلوک کا حکم دیا ہے۔ حتیٰ کہ جب وہ بڑھاپے کو پہنچ جائیں تو انہیں 'اُف' تک کہنے اور جھڑکنے سے منع فرمایا، بلکہ ان کے سامنے عاجزی اور رحمت کا بازو جھکانے کی تعلیم دی۔ آج کی تیز رفتار زندگی میں کبھی ہم موبائل یا کام میں مصروف ہو کر والدین کی بات بے دھیانی سے سنتے ہیں، جو ان کے دل کو ٹھیس پہنچا سکتا ہے۔ والدین کے پاس محبت سے بیٹھنا، ان کی بات توجہ سے سننا، ان کی ضروریات پوری کرنا اور ان کے لیے دعا کرنا سب سے بڑی سعادت ہے۔",
            explanationEn = "Right after commanding worship of Himself alone, Allah commands kindness and excellence toward parents. When they reach old age, we are forbidden even a sigh of annoyance ('uff') and instructed to speak to them with honor and humility. In our busy screen-filled days, giving parents undivided attention, warm tone, financial or household help, and heartfelt prayer is a direct path to spiritual blessing.",
            quranArabic = "وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا",
            quranTranslationUr = "اور آپ کے رب نے فیصلہ فرما دیا ہے کہ اس کے سوا کسی کی عبادت نہ کرو اور والدین کے ساتھ احسان (بہترین سلوک) کرو۔",
            quranTranslationEn = "And your Lord has decreed that you worship none but Him, and be dutiful and kind to parents.",
            quranRefUr = "سورۃ بنی اسرائیل 17:23",
            quranRefEn = "Surah Al-Isra 17:23",
            hadithTextUr = "رب کی رضا والد کی رضا میں ہے اور رب کی ناراضگی والد کی ناراضگی میں ہے۔",
            hadithTextEn = "The pleasure of the Lord lies in the pleasure of the parent, and His displeasure lies in their displeasure.",
            hadithRefUr = "جامع ترمذی، حدیث 1899 (مستند)",
            hadithRefEn = "Jami' at-Tirmidhi, Hadith 1899 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "والدین کے بلانے پر موبائل فوراً رکھ کر ادب سے 'جی' کہنا اور گھر کے کاموں میں ان کا ہاتھ بٹانا۔",
            teenExampleEn = "Putting down your phone immediately when your parents call, answering respectfully, and helping with chores.",
            youngAdultExampleUr = "مصروف تعلیم یا نوکری کے باوجود روزانہ والدین سے محبت بھری بات چیت کرنا اور ان کے مشورے کی قدر کرنا۔",
            youngAdultExampleEn = "Making time amidst university or work to call or sit warmly with your parents and value their counsel.",
            adultExampleUr = "بڑھاپے میں والدین کی بیماری، دوائی اور تنہائی کا صبر و محبت سے خیال رکھنا اور ان کی خدمت کو بوجھ نہ سمجھنا۔",
            adultExampleEn = "Caring patiently for aging parents' health, company, and comfort without ever showing impatience.",
            keyLessonsUr = listOf(
                "والدین سے 'اُف' تک کہنا اور تلخ لہجہ اختیار کرنا منع ہے۔",
                "والدین کی خدمت اور ان کی دعا زندگی میں برکت لاتی ہے۔",
                "اپنا وقت اور توجہ دینا بھی والدین کے بڑے حقوق میں شامل ہے۔"
            ),
            keyLessonsEn = listOf(
                "Even a harsh sigh of impatience toward parents is forbidden.",
                "Serving parents and earning their prayers brings immense blessing.",
                "Undivided attention and gentle speech are vital rights of parents."
            ),
            practicalActivityUr = "آج والدین کے پاس بیٹھ کر فون ایک طرف رکھیں، ان کی خیریت پوچھیں، کوئی کام خود پوچھ کر کریں اور ان کے لیے دعا کریں۔",
            practicalActivityEn = "Set your phone aside today, sit with your parents (or call them), ask how they are, help with a task, and pray for them.",
            reflectionPromptUr = "کون سی بات یا مصروفیت مجھے والدین کو پورا وقت اور نرم لہجہ دینے سے روکتی ہے؟",
            reflectionPromptEn = "What distraction or habit keeps me from giving my parents warmer time and gentler speech?",
            goodDeedChallengeUr = "آج والدین (یا سرپرست/بزرگوں) کے لیے کوئی پسندیدہ چیز لائیں یا گھر کا کوئی کام ان کے کہے بغیر کر دیں۔",
            goodDeedChallengeEn = "Do a helpful chore for your parents or elders before they ask, or bring them something thoughtful.",
            quiz = listOf(
                QuizQuestion("d8q1", "سورۃ بنی اسرائیل (17:23) میں اللہ کی عبادت کے فوراً بعد کس کا حکم دیا گیا ہے؟", "What does Surah Al-Isra (17:23) command right after worshipping Allah?", listOf("سفر کرنے کا", "والدین کے ساتھ احسان کا", "تجارت کا", "مقابلے کا"), listOf("Traveling", "Kindness and excellence to parents", "Commerce", "Competition"), 1, "والدین کے ساتھ حسنِ سلوک کو عبادت کے فوراً بعد بیان کیا گیا ہے۔", "Kindness to parents is placed directly beside devotion to Allah."),
                QuizQuestion("d8q2", "بڑھاپے میں والدین کے ساتھ کیسے پیش آنا چاہیے؟", "How should one treat parents in their old age?", listOf("جلدی میں جواب دینا", "نرمی، ادب اور دعا کے ساتھ خدمت کرنا", "اُف کہہ کر ٹال دینا", "نظر انداز کرنا"), listOf("Rushing them", "With gentleness, honor, and prayerful service", "Showing annoyance", "Ignoring them"), 1, "بڑھاپے میں والدین کو زیادہ محبت اور صبر کی ضرورت ہوتی ہے۔", "Aging parents deserve utmost patience, care, and gentle speech."),
                QuizQuestion("d8q3", "ترمذی کی حدیث کے مطابق رب کی رضا کس میں ہے؟", "According to the Hadith in at-Tirmidhi, where does Allah's pleasure lie?", listOf("دوستوں کی تعریف میں", "والدین کی رضا میں", "زیادہ سونے میں", "بحث جیتنے میں"), listOf("Friends' praise", "Parents' pleasure", "Extra sleep", "Winning debates"), 1, "والدین کو راضی اور خوش رکھنا اللہ کی خوشنودی کا ذریعہ ہے۔", "Pleasing one's parents is tied to pleasing Allah."),
                QuizQuestion("d8q4", "اگر والدین کسی جائز بات پر نصیحت کریں تو ہمارا رویہ کیا ہونا چاہیے؟", "How should we respond when parents offer sincere advice?", listOf("غصے سے بولنا", "ادب سے سننا اور غور کرنا", "کمرے سے نکل جانا", "مذاق اڑانا"), listOf("Snap back", "Listen respectfully and reflect", "Walk out", "Mock them"), 1, "اختلافِ رائے میں بھی والدین کا احترام واجب ہے۔", "Even when views differ, respect and gentle tone remain mandatory."),
                QuizQuestion("d8q5", "آج کے دور میں والدین کی حق تلفی کی ایک عام شکل کیا ہے؟", "What is a common way parents are unintentionally neglected today?", listOf("انہیں تحفہ دینا", "ان کے سامنے ہر وقت فون میں مگن رہنا", "ان کے لیے دعا کرنا", "ان سے مشورہ لینا"), listOf("Giving gifts", "Staying absorbed in phones while sitting with them", "Praying for them", "Seeking their advice"), 1, "پوری توجہ کے ساتھ گفتگو کرنا والدین کو اپنائیت کا احساس دلاتا ہے۔", "Giving undivided attention shows true love and respect.")
            )
        ),
        CuratedLesson(
            dayNumber = 9,
            weekNumber = 2,
            categoryIds = listOf("family_life", "peace_tolerance"),
            titleUr = "میاں بیوی کے باہمی حقوق اور ذمہ داریاں",
            titleEn = "Responsibilities Between Husband and Wife",
            objectivesUr = listOf(
                "ازدواجی رشتے کو محبت، رحمت اور سکون کی بنیاد پر سمجھنا۔",
                "عزت، مشاورت اور ذمہ داریوں کی منصفانہ تقسیم کو اپنانا۔",
                "نوجوانوں کو مستقبل کی صحت مند خاندانی زندگی کے لیے تیار کرنا۔"
            ),
            objectivesEn = listOf(
                "Understand marriage as a bond of tranquility, affection, and mercy.",
                "Practice mutual respect, consultation, and fair shared responsibility.",
                "Prepare young learners for respectful, supportive family life."
            ),
            introUr = "مضبوط معاشرہ مضبوط گھر سے بنتا ہے اور گھر کی بنیاد میاں بیوی کے درمیان محبت، احترام اور رحمدلی پر ہوتی ہے۔",
            introEn = "Strong societies grow from peaceful homes built on affection, respect, and mercy between spouses.",
            explanationUr = "قرآن کریم میاں بیوی کے رشتے کو سکون، مودت (محبت) اور رحمت کی نشانی قرار دیتا ہے اور دونوں کو ایک دوسرے کا 'لباس' یعنی سہارا، پردہ اور زینت بتاتا ہے۔ نبی کریم ﷺ گھر کے کاموں میں خود اپنے اہلِ خانہ کا ہاتھ بٹاتے تھے اور فرماتے تھے کہ تم میں بہترین وہ ہے جو اپنے گھر والوں کے لیے بہترین ہو۔ ازدواجی زندگی میں انا اور برتری کی جنگ نہیں بلکہ باہمی مشورہ، شکر گزاری، حقوق کی ادائیگی اور ایک دوسرے کی خامیوں سے درگزر کامیابی کا راز ہے۔",
            explanationEn = "The Quran describes marriage as a source of tranquility, love, and mercy, calling spouses garments of comfort and protection for one another. The Prophet ﷺ helped with household chores and taught that the best among believers are those who are best to their families. A healthy marriage thrives not on ego or dominance, but on consultation, appreciation, fairness, and gracious forgiveness.",
            quranArabic = "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً",
            quranTranslationUr = "اور اس کی نشانیوں میں سے ہے کہ اس نے تمہارے لیے تمہاری ہی جنس سے جوڑے بنائے تاکہ تم ان کے پاس سکون پاؤ، اور تمہارے درمیان محبت اور رحمت پیدا کر دی۔",
            quranTranslationEn = "And among His signs is that He created for you spouses from among yourselves so you may find tranquility in them, and He placed between you affection and mercy.",
            quranRefUr = "سورۃ الروم 30:21",
            quranRefEn = "Surah Ar-Rum 30:21",
            hadithTextUr = "تم میں سب سے بہتر وہ ہے جو اپنے گھر والوں کے لیے سب سے بہتر ہو، اور میں اپنے گھر والوں کے لیے تم سب سے بہتر ہوں۔",
            hadithTextEn = "The best of you are those who are best to their families, and I am the best of you to my family.",
            hadithRefUr = "جامع ترمذی، حدیث 3895 (مستند)",
            hadithRefEn = "Jami' at-Tirmidhi, Hadith 3895 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "گھر میں اپنے والدین کے باہمی احترام کو دیکھ کر سیکھنا کہ گھریلو سکون نرمی اور تعاون سے آتا ہے، ضد سے نہیں۔",
            teenExampleEn = "Learning at home that peaceful families rely on cooperation and respect, not stubbornness.",
            youngAdultExampleUr = "شادی یا مستقبل کے خاندان کے بارے میں یہ سوچ رکھنا کہ رشتہ کردار، ذمہ داری اور احترام کی شراکت داری ہے۔",
            youngAdultExampleEn = "Approaching marriage readiness with emotional maturity, honesty, and shared responsibility.",
            adultExampleUr = "شریکِ حیات کی روزمرہ محنت پر دل سے شکریہ ادا کرنا، گھریلو کام میں مدد کرنا اور اختلاف کے وقت عزت برقرار رکھنا۔",
            adultExampleEn = "Thanking your spouse sincerely for daily efforts, sharing chores, and keeping dignity intact during disagreements.",
            keyLessonsUr = listOf(
                "گھریلو رشتہ محبت، رحمت اور سکون کا نام ہے۔",
                "گھر والوں کے ساتھ اچھا سلوک بہترین انسان ہونے کا معیار ہے۔",
                "باہمی احترام، تعاون اور شکر گزاری گھر کو جنت کا نمونہ بناتی ہے۔"
            ),
            keyLessonsEn = listOf(
                "Marriage is anchored in tranquility, love, and mercy.",
                "True goodness is measured by how kindly one treats family at home.",
                "Gratitude, consultation, and shared effort keep homes peaceful."
            ),
            practicalActivityUr = "آج اپنے گھر میں کسی اہم ذمہ داری میں اہلِ خانہ (یا شریکِ حیات) کی مدد کریں اور ان کی محنت کی تعریف کریں۔",
            practicalActivityEn = "Help with a household responsibility today and express genuine appreciation to your spouse or family members.",
            reflectionPromptUr = "ہم اپنے گھر کے ماحول کو زیادہ پرسکون، تعاون پر مبنی اور محبت بھرا کیسے بنا سکتے ہیں؟",
            reflectionPromptEn = "How can I make my home environment calmer, warmer, and more supportive?",
            goodDeedChallengeUr = "آج گھر کے اندر سب کے لیے چائے یا کھانے کے انتظام میں خود بڑھ کر مدد کریں۔",
            goodDeedChallengeEn = "Volunteer to prepare a meal, tea, or tidy up a shared space at home today.",
            quiz = listOf(
                QuizQuestion("d9q1", "سورۃ الروم (30:21) میں میاں بیوی کے رشتے کی کون سی تین خوبیاں بیان ہوئی ہیں؟", "Which three qualities of marriage are named in Surah Ar-Rum (30:21)?", listOf("مال، شہرت، طاقت", "سکون، محبت (مودت)، رحمت", "ضد، بحث، مقابلہ", "خاموشی، دوری، خوف"), listOf("Wealth, fame, power", "Tranquility, affection, and mercy", "Stubbornness, debate, rivalry", "Silence, distance, fear"), 1, "قرآن نے سکون، محبت اور رحمت کو ازدواجی رشتے کی روح قرار دیا ہے۔", "Tranquility, love, and mercy form the heart of marriage."),
                QuizQuestion("d9q2", "حدیث کے مطابق لوگوں میں سب سے بہتر کون ہے؟", "Who is the best among people according to the Hadith?", listOf("جو باہر بہت ہنسے اور گھر میں سخت ہو", "جو اپنے گھر والوں کے ساتھ سب سے بہتر ہو", "جو صرف پیسہ کمائے", "جو گھر کے کام کبھی نہ کرے"), listOf("Gentle outside but harsh at home", "Best toward their own family", "Focused only on money", "Never helps at home"), 1, "اصل اخلاق گھر کی چار دیواری میں پرکھا جاتا ہے۔", "True character shines inside one's own home."),
                QuizQuestion("d9q3", "نبی کریم ﷺ کا گھریلو معمول کیا تھا؟", "What was the Prophet's ﷺ practice at home?", listOf("گھر کے کاموں میں اہلِ خانہ کی مدد کرنا", "کبھی بات نہ کرنا", "ہر کام پر تنقید کرنا", "گھر سے الگ رہنا"), listOf("Helping his family with household chores", "Avoiding conversation", "Criticizing small errors", "Staying aloof"), 0, "صحیح بخاری میں آتا ہے کہ آپ ﷺ گھر کے کام کاج میں مصروف رہتے تھے۔", "He actively assisted with household tasks in humility and love."),
                QuizQuestion("d9q4", "اختلافِ رائے کی صورت میں میاں بیوی کو کیا کرنا چاہیے؟", "How should spouses handle disagreements?", listOf("چیخ و پکار کرنا", "احترام، صبر اور مشاورت سے حل نکالنا", "گھر چھوڑ دینا", "دوسروں کے سامنے طعنہ دینا"), listOf("Shouting", "Resolve calmly through respect and consultation", "Walking out", "Publicly shaming each other"), 1, "عزتِ نفس کی حفاظت ہر تنازعے میں ضروری ہے۔", "Protecting dignity prevents lasting wounds."),
                QuizQuestion("d9q5", "شکر گزاری گھر میں کیا اثر ڈالتی ہے؟", "What effect does appreciation have in a family?", listOf("کوئی اثر نہیں", "محبت بڑھاتی اور تھکن کم کرتی ہے", "غرور پیدا کرتی ہے", "وقت ضائع کرتی ہے"), listOf("No effect", "Deepens affection and lightens daily burdens", "Creates pride", "Wastes time"), 1, "قدردانی کے چند بول دلوں کو قریب لے آتے ہیں۔", "Simple words of gratitude strengthen family warmth.")
            )
        ),
        CuratedLesson(
            dayNumber = 10,
            weekNumber = 2,
            categoryIds = listOf("family_life", "youth_development", "islamic_character"),
            titleUr = "محبت اور اچھے اخلاق کے ساتھ بچوں کی تربیت",
            titleEn = "Raising Children with Love and Good Character",
            objectivesUr = listOf(
                "بچوں کی تربیت میں ڈانٹ کے بجائے محبت، رحمت اور عملی نمونے کی طاقت سمجھنا۔",
                "بچوں میں سچائی، حیا، اعتماد اور احترامِ انسانیت کی قدریں پروان چڑھانا۔",
                "تمام بچوں کے ساتھ انصاف اور توجہ کا برتاؤ برقرار رکھنا۔"
            ),
            objectivesEn = listOf(
                "Understand why warmth, mercy, and personal example shape children better than harshness.",
                "Nurture honesty, confidence, empathy, and respect in younger generations.",
                "Maintain fairness and attentive care among all children."
            ),
            introUr = "بچے نصیحت سے کم اور اپنے بڑوں کے عمل اور محبت بھرے ماحول سے زیادہ سیکھتے ہیں۔",
            introEn = "Children learn far more from our daily example and warmth than from lectures.",
            explanationUr = "نبی کریم ﷺ بچوں سے بے حد شفقت فرماتے تھے، انہیں گود میں بٹھاتے، سلام کرتے اور ان کی بات توجہ سے سنتے تھے۔ بچوں کی اچھی تربیت صرف مہنگے اسکول یا کپڑوں کا نام نہیں، بلکہ انہیں وقت دینا، ان کے سامنے سچ بولنا، ان کے سوالات کا صبر سے جواب دینا اور انہیں نیکی کی محبت دلانا ہے۔ تشدد، طنز اور دوسروں سے بے جا موازنہ بچے کے اعتماد کو توڑ دیتا ہے، جبکہ حوصلہ افزائی، حکمت اور حضرت لقمانؑ جیسی شفیق نصیحتیں مضبوط اور بااخلاق انسان بناتی ہیں۔",
            explanationEn = "The Prophet ﷺ showed extraordinary mercy to children—greeting them warmly, listening to them, and showing affection. Good upbringing goes beyond material provision; it means giving time, modeling honesty, answering questions patiently, and teaching moral values with kindness. Harshness and unfair comparisons wound a child's confidence, whereas gentle guidance—like Luqman's wise counsel in the Quran—builds resilient character.",
            quranArabic = "يَا بُنَيَّ أَقِمِ الصَّلَاةَ وَأْمُرْ بِالْمَعْرُوفِ وَانْهَ عَنِ الْمُنكَرِ وَاصْبِرْ عَلَىٰ مَا أَصَابَكَ",
            quranTranslationUr = "اے میرے پیارے بیٹے! نماز قائم کر، نیکی کا حکم دے، برائی سے منع کر اور جو تکلیف پہنچے اس پر صبر کر۔",
            quranTranslationEn = "O my dear son, establish prayer, enjoin what is right, forbid what is wrong, and be patient over whatever befalls you.",
            quranRefUr = "سورۃ لقمان 31:17",
            quranRefEn = "Surah Luqman 31:17",
            hadithTextUr = "جو ہمارے چھوٹوں پر رحم نہ کرے اور ہمارے بڑوں کا حق نہ پہچانے وہ ہم میں سے نہیں۔",
            hadithTextEn = "He is not of us who does not show mercy to our young ones and recognize the honor of our elders.",
            hadithRefUr = "جامع ترمذی، حدیث 1919 / سنن ابی داؤد، حدیث 4943 (مستند)",
            hadithRefEn = "Jami' at-Tirmidhi, Hadith 1919 / Sunan Abi Dawud, Hadith 4943 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اپنے چھوٹے بہن بھائیوں پر رعب جمانے کے بجائے محبت سے ان کی پڑھائی میں مدد کرنا اور اچھا نمونہ بننا۔",
            teenExampleEn = "Being a gentle, patient role model for younger siblings instead of bossing them around.",
            youngAdultExampleUr = "چھوٹے بچوں یا رشتہ داروں کے سامنے صبر، صاف زبان اور مثبت اخلاق کا عملی مظاہرہ کرنا۔",
            youngAdultExampleEn = "Modeling clean speech, calm patience, and kindness whenever younger kids look up to you.",
            adultExampleUr = "بچوں کو غلطی پر مارنے یا شرمندہ کرنے کے بجائے گلے لگا کر وجہ سمجھانا اور ان کی خوبیوں کی تعریف کرنا۔",
            adultExampleEn = "Guiding children through mistakes with calm conversation and encouragement instead of shaming or harshness.",
            keyLessonsUr = listOf(
                "بچوں کے ساتھ شفقت اور رحمت تربیت کی بنیاد ہے۔",
                "والدین اور بڑے اپنا عملی نمونہ بچوں کے لیے سب سے بڑا سبق ہیں۔",
                "بچوں کے درمیان برابری اور حوصلہ افزائی اعتماد پیدا کرتی ہے۔"
            ),
            keyLessonsEn = listOf(
                "Mercy and warmth are the foundation of sound upbringing.",
                "Our own behavior is the strongest curriculum children observe.",
                "Fairness and encouragement cultivate confident, ethical youth."
            ),
            practicalActivityUr = "آج گھر کے کسی چھوٹے بچے یا چھوٹے بہن بھائی کے ساتھ 15 منٹ کھیل، کہانی یا محبت بھری گفتگو میں گزاریں۔",
            practicalActivityEn = "Spend 15 joyful, attentive minutes with a child or younger sibling today listening, reading, or encouraging them.",
            reflectionPromptUr = "کیا میرے رویے سے گھر کے چھوٹے بچے نرمی اور سچائی سیکھ رہے ہیں؟",
            reflectionPromptEn = "What habits are younger family members learning simply by watching me?",
            goodDeedChallengeUr = "آج کسی بچے کی کوئی چھوٹی سی اچھائی پر دل کھول کر شاباش دیں اور اس کی حوصلہ افزائی کریں۔",
            goodDeedChallengeEn = "Praise a child or younger sibling today for a specific good quality or effort.",
            quiz = listOf(
                QuizQuestion("d10q1", "بچوں کی تربیت میں سب سے مؤثر چیز کیا ہے؟", "What is most influential in raising children?", listOf("صرف سخت سزا", "محبت اور بڑوں کا اپنا عملی نمونہ", "موازنہ کرنا", "بے جا لاڈ"), listOf("Harsh punishment", "Love and the elders' own living example", "Constant comparison", "Neglect"), 1, "بچے بڑوں کے عمل کی نقل کرتے ہیں۔", "Children mirror the character they witness daily."),
                QuizQuestion("d10q2", "سورۃ لقمان (31:17) میں حضرت لقمانؑ نے بیٹے کو کس انداز میں نصیحت کی؟", "How did Luqman (AS) address his son in Surah Luqman (31:17)?", listOf("غصے اور لعن طعن سے", "'اے میرے پیارے بیٹے' کہہ کر شفقت سے", "سخت ڈانٹ سے", "دوسروں کے سامنے"), listOf("With anger", "'O my dear son' — with warmth and wisdom", "With harsh scolding", "By shaming publicly"), 1, "شفیق خطاب دل کے دروازے کھول دیتا ہے۔", "Affectionate words open a young person's heart to guidance."),
                QuizQuestion("d10q3", "حدیث کے مطابق چھوٹوں کے ساتھ ہمارا برتاؤ کیسا ہونا چاہیے؟", "According to the Hadith, how must we treat the young?", listOf("سختی کا", "رحم اور شفقت کا", "لاپرواہی کا", "تکبر کا"), listOf("With severity", "With mercy and compassion", "With neglect", "With pride"), 1, "چھوٹوں پر رحم ایمان کی نشانی ہے۔", "Mercy toward the young is an essential mark of faith."),
                QuizQuestion("d10q4", "بچوں میں غیر ضروری موازنہ کرنے کا کیا نقصان ہوتا ہے؟", "What harm comes from constantly comparing children to others?", listOf("محبت بڑھتی ہے", "حسد اور کم اعتمادی پیدا ہوتی ہے", "دوستی مضبوط ہوتی ہے", "صبر بڑھتا ہے"), listOf("Love grows", "It breeds jealousy and lowers confidence", "Friendships deepen", "Patience rises"), 1, "ہر بچے کی صلاحیت منفرد ہے؛ حوصلہ افزائی بہتر رہتی ہے۔", "Every child is unique; encouragement builds confidence."),
                QuizQuestion("d10q5", "بچے کی غلطی پر درست ردعمل کیا ہے؟", "What is a constructive response to a child's mistake?", listOf("مارنا پیٹنا", "نرمی سے سمجھانا اور اصلاح کا طریقہ بتانا", "بے عزتی کرنا", "کبھی نہ بولنا"), listOf("Hitting", "Explaining calmly and guiding how to fix it", "Humiliating them", "Silent treatment"), 1, "اصلاح کا مقصد سکھانا ہے، توڑنا نہیں۔", "Correction aims to teach, never to break spirit.")
            )
        ),
        CuratedLesson(
            dayNumber = 11,
            weekNumber = 2,
            categoryIds = listOf("family_life", "unity_brotherhood"),
            titleUr = "خاندانی رشتے برقرار رکھنا (صلہ رحمی)",
            titleEn = "Maintaining Family Relationships (Silah Rahmi)",
            objectivesUr = listOf(
                "صلہ رحمی (رشتے جوڑنے) کی فضیلت اور قطع رحمی کے نقصان کو سمجھنا۔",
                "رشتے داری صرف برابر کے جواب تک محدود نہ رکھنا بلکہ توڑنے والے سے بھی جوڑنا۔",
                "بزرگوں، خالہ، پھوپھی، چچا، ماموں اور کزنز سے رابطہ برقرار رکھنا۔"
            ),
            objectivesEn = listOf(
                "Understand the blessings of maintaining kinship ties (Silah Rahmi).",
                "Go beyond conditional politeness by reconnecting even when others pull away.",
                "Keep active care for extended family and elders."
            ),
            introUr = "مضبوط خاندانی رشتے مشکل وقت میں ڈھال اور خوشی کے لمحات میں رونق ہوتے ہیں۔",
            introEn = "Strong family ties act as a shield in hardship and a source of shared joy in blessing.",
            explanationUr = "اسلام نے خونی اور خاندانی رشتوں کو جوڑنے (صلہ رحمی) پر غیر معمولی زور دیا ہے۔ نبی کریم ﷺ نے فرمایا کہ اصل رشتے جوڑنے والا وہ نہیں جو بدلے میں احسان کرے (کہ وہ آئے تو میں جاؤں)، بلکہ اصل صلہ رحمی کرنے والا وہ ہے کہ جب اس سے رشتہ توڑا جائے تب بھی وہ اسے جوڑے۔ آج کے دور میں انا، معمولی جائیداد کے جھگڑے یا کسی غلط فہمی کی وجہ سے سالوں تک بھائی بہن اور رشتہ دار بول چال بند رکھتے ہیں، جس سے برکت اٹھ جاتی ہے۔ ایک مختصر فون کال، عیادت، اور معافی رشتوں میں نئی جان ڈال سکتی ہے۔",
            explanationEn = "Islam places immense value on Silah Rahmi—maintaining kinship bonds. The Prophet ﷺ explained that the true maintainer of family ties is not merely the one who reciprocates visits, but the one who reconnects when relatives cut ties. Today, petty misunderstandings or pride often separate siblings and relatives for years. A brief phone call, visiting a sick aunt or uncle, or offering the first greeting restores warmth and blessing.",
            quranArabic = "وَاتَّقُوا اللَّهَ الَّذِي تَسَاءَلُونَ بِهِ وَالْأَرْحَامَ",
            quranTranslationUr = "اور اللہ سے ڈرو جس کے نام پر تم ایک دوسرے سے سوال کرتے ہو، اور رشتے داریوں کا لحاظ رکھو۔",
            quranTranslationEn = "And be mindful of Allah, through whom you ask one another, and honor the ties of kinship.",
            quranRefUr = "سورۃ النساء 4:1",
            quranRefEn = "Surah An-Nisa 4:1",
            hadithTextUr = "جو چاہتا ہے کہ اس کے رزق میں کشادگی اور عمر میں برکت ہو، اسے چاہیے کہ صلہ رحمی (رشتے داری کا خیال) کرے۔",
            hadithTextEn = "Whoever wishes for their provision to be expanded and their life to be blessed should maintain the ties of kinship.",
            hadithRefUr = "صحیح بخاری، حدیث 5986 / صحیح مسلم، حدیث 2557 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 5986 / Sahih Muslim, Hadith 2557 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "دادا دادی، نانا نانی یا کزنز سے عید یا عام دنوں میں خوش اخلاقی سے ملنا اور حال چال پوچھنا۔",
            teenExampleEn = "Checking in warmly with grandparents, aunts, uncles, and cousins instead of isolating yourself in your room.",
            youngAdultExampleUr = "مصروفیت کے باوجود ہفتے میں ایک بار اپنے کسی بزرگ رشتہ دار کو فون کر کے خیریت معلوم کرنا۔",
            youngAdultExampleEn = "Calling an elderly relative once a week despite your busy university or job schedule.",
            adultExampleUr = "کسی ناراض رشتہ دار سے پرانی رنجش بھلا کر پہل کرنا اور خاندانی میل جول کی فضا بحال کرنا۔",
            adultExampleEn = "Taking the dignified first step to greet and mend ties with an estranged relative.",
            keyLessonsUr = listOf(
                "صلہ رحمی رزق اور عمر میں برکت کا سبب ہے۔",
                "اصل صلہ رحمی یہ ہے کہ توڑنے والے سے بھی رشتہ جوڑا جائے۔",
                "انا کو قربان کر کے رشتہ بچا لینا بڑی عقلمندی ہے۔"
            ),
            keyLessonsEn = listOf(
                "Maintaining kinship ties brings blessing in sustenance and life.",
                "True Silah Rahmi means reconnecting even when others drift away.",
                "Setting aside pride to preserve family bonds is true wisdom."
            ),
            practicalActivityUr = "آج کسی ایسے رشتہ دار کو فون یا پیغام بھیجیں جن سے کافی دنوں سے بات نہ ہوئی ہو اور ان کی خیریت پوچھیں۔",
            practicalActivityEn = "Call or message a relative you haven't spoken with in a while simply to wish them well.",
            reflectionPromptUr = "کیا خاندان میں کوئی ایسا فرد ہے جس کی طرف مجھے پہل کر کے تعلق بہتر بنانا چاہیے؟",
            reflectionPromptEn = "Is there a relative in my family toward whom I can take a gentle step of reconciliation?",
            goodDeedChallengeUr = "آج کسی بزرگ رشتہ دار کی خیریت دریافت کریں اور ان کے لیے دل سے دعا کریں۔",
            goodDeedChallengeEn = "Check on an elderly relative today and make sincere dua for them.",
            quiz = listOf(
                QuizQuestion("d11q1", "صحیح بخاری و مسلم کے مطابق صلہ رحمی کا کیا دنیاوی و اخروی فائدہ ہے؟", "What blessing is promised for maintaining kinship ties in Bukhari & Muslim?", listOf("شہرت", "رزق میں کشادگی اور عمر میں برکت", "زیادہ سفر", "پریشانی"), listOf("Fame", "Expanded provision and blessed lifespan", "More travel", "Worry"), 1, "رشتے جوڑنے سے گھر اور رزق میں برکت نازل ہوتی ہے۔", "Silah Rahmi brings barakah in provision and life."),
                QuizQuestion("d11q2", "حدیث کے مطابق اصل صلہ رحمی کرنے والا کون ہے؟", "Who truly maintains kinship ties according to the Prophet ﷺ?", listOf("جو صرف بدلے میں ملے", "جو تعلق توڑنے والے سے بھی رشتہ جوڑے", "جو صرف امیر رشتہ داروں سے ملے", "جو صرف عید پر میسج کرے"), listOf("One who only visits those who visit them", "One who reconnects even when ties are cut", "One who visits only wealthy relatives", "One who sends a single annual text"), 1, "برابری کے معاملے سے بڑھ کر توڑے ہوئے رشتے جوڑنا اصل کمال ہے۔", "Reconnecting despite distance or coldness is true Silah Rahmi."),
                QuizQuestion("d11q3", "سورۃ النساء (4:1) میں اللہ کے تقویٰ کے ساتھ کس بات کی تاکید ہے؟", "In Surah An-Nisa (4:1), what is emphasized alongside mindfulness of Allah?", listOf("تجارت", "رشتے داریوں (الارحام) کا احترام", "کھیل", "خاموشی"), listOf("Trade", "Honoring kinship ties", "Sports", "Silence"), 1, "رشتوں کا احترام قرآنی حکم ہے۔", "Respecting kinship bonds is a clear Quranic duty."),
                QuizQuestion("d11q4", "خاندانی رشتے ٹوٹنے کی بڑی وجہ کیا ہوتی ہے؟", "What often breaks family relationships?", listOf("محبت", "انا، غلط فہمی اور معاف نہ کرنا", "مل بیٹھنا", "دعا کرنا"), listOf("Affection", "Pride, misunderstanding, and refusal to forgive", "Gathering together", "Praying for each other"), 1, "تھوڑی سی عاجزی بڑے سے بڑا خاندانی فاصلہ مٹا سکتی ہے۔", "A little humility heals long family distances."),
                QuizQuestion("d11q5", "غریب یا کمزور رشتہ دار کے ساتھ کیسا سلوک ہونا چاہیے؟", "How should one treat relatives who are financially struggling?", listOf("دوری اختیار کرنا", "ان کی عزتِ نفس بچاتے ہوئے مدد اور محبت کرنا", "احسان جتانا", "تقریب میں نہ بلانا"), listOf("Avoid them", "Support them kindly while protecting their dignity", "Remind them of favors", "Exclude them"), 1, "کمزور رشتہ دار کی عزت اور خاموش مدد دوہرا اجر رکھتی ہے۔", "Quietly supporting struggling relatives carries double reward.")
            )
        ),
        CuratedLesson(
            dayNumber = 12,
            weekNumber = 2,
            categoryIds = listOf("family_life", "community_service", "peace_tolerance"),
            titleUr = "پڑوسیوں کے حقوق",
            titleEn = "Rights of Neighbors",
            objectivesUr = listOf(
                "اسلام میں پڑوسی کے غیر معمولی مقام کو جاننا۔",
                "پڑوسی کو تکلیف سے بچانا (شور، کچرا، راستہ روکنا، بدگمانی)۔",
                "مذہب و برادری سے بالاتر ہو کر ہر پڑوسی کے ساتھ خیر خواہی کرنا۔"
            ),
            objectivesEn = listOf(
                "Recognize the high status of neighbors in Islamic teachings.",
                "Protect neighbors from harm such as noise, litter, blocked paths, or gossip.",
                "Show practical care and goodwill to all neighbors regardless of background."
            ),
            introUr = "سماجی امن کی پہلی اینٹ اپنے دروازے کے باہر کھڑے پڑوسی کے ساتھ محبت اور احترام کا برتاؤ ہے۔",
            introEn = "Social peace begins right outside your front door with kindness and respect toward your neighbors.",
            explanationUr = "نبی کریم ﷺ نے فرمایا کہ حضرت جبرائیلؑ مجھے پڑوسی کے بارے میں اتنی تاکید کرتے رہے کہ مجھے گمان ہونے لگا کہ شاید پڑوسی کو وراثت میں شریک کر دیا جائے گا۔ پڑوسی چاہے مسلمان ہو یا غیر مسلم، رشتہ دار ہو یا اجنبی، اس کا پہلا حق یہ ہے کہ ہماری ذات، زبان، شور، کوڑے یا گاڑی پارکنگ سے اسے کوئی تکلیف نہ پہنچے۔ دوسرا حق اس کی ضرورت، بیماری اور خوشی غمی میں ساتھ دینا اور تحفے یا کھانے میں اسے یاد رکھنا ہے۔ اچھے پڑوسی پورے محلے کو محفوظ اور خوشحال بنا دیتے ہیں۔",
            explanationEn = "The Prophet ﷺ remarked that Angel Jibril continued advising him about neighbors so persistently that he thought neighbors might be given a share of inheritance. Whether Muslim or non-Muslim, relative or stranger, a neighbor's primary right is safety from harm—no loud noise at night, no trash by their gate, no blocked driveways, and no intrusive gossip. Beyond avoiding harm, sharing food, checking on sick neighbors, and offering help builds a trustworthy, caring neighborhood.",
            quranArabic = "وَالْجَارِ ذِي الْقُرْبَىٰ وَالْجَارِ الْجُنُبِ",
            quranTranslationUr = "اور رشتہ دار پڑوسی اور اجنبی پڑوسی کے ساتھ بھی اچھا سلوک کرو۔",
            quranTranslationEn = "And do good to the neighbor who is near of kin and the neighbor who is a stranger.",
            quranRefUr = "سورۃ النساء 4:36",
            quranRefEn = "Surah An-Nisa 4:36",
            hadithTextUr = "اللہ کی قسم وہ مومن نہیں جس کا پڑوسی اس کی شرارتوں (تکلیفوں) سے محفوظ نہ ہو۔",
            hadithTextEn = "By Allah, he does not truly believe whose neighbor is not safe from his harm.",
            hadithRefUr = "صحیح بخاری، حدیث 6016 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6016 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "گلی میں کھیلتے وقت پڑوسیوں کی کھڑکیوں، پودوں یا بزرگوں کے آرام کا خیال رکھنا اور سلام کرنا۔",
            teenExampleEn = "Greeting neighbors politely and keeping noise or ball games from disturbing elderly neighbors or damaging property.",
            youngAdultExampleUr = "گلی یا اپارٹمنٹ کے باہر پارکنگ اور صفائی کا خیال رکھنا اور بزرگ پڑوسی کا سامان اٹھانے میں مدد کرنا۔",
            youngAdultExampleEn = "Parking considerately, keeping shared hallways clean, and helping carry groceries for a neighbor.",
            adultExampleUr = "گھر میں اچھا کھانا پکے تو تھوڑا سا پڑوسی کے ہاں بھیجنا اور ان کی غیر موجودگی میں ان کے گھر کی حفاظت کا خیال رکھنا۔",
            adultExampleEn = "Sharing a dish of food with neighbors and looking out for their home's safety when they are away.",
            keyLessonsUr = listOf(
                "رشتہ دار ہو یا اجنبی، ہر پڑوسی حسنِ سلوک کا حقدار ہے۔",
                "پڑوسی کو تکلیف سے بچانا ایمان کی علامت ہے۔",
                "چھوٹے تحفے، سلام اور مدد محلے میں محبت پیدا کرتے ہیں۔"
            ),
            keyLessonsEn = listOf(
                "Every neighbor—related or unfamiliar, of any background—deserves kindness.",
                "Keeping neighbors safe from harm is a direct measure of faith.",
                "Small greetings, shared food, and practical help unite a street."
            ),
            practicalActivityUr = "آج اپنے کسی پڑوسی سے مسکرا کر ملیں، خیریت پوچھیں، اور اپنے دروازے کے باہر کی جگہ صاف رکھیں۔",
            practicalActivityEn = "Greet a neighbor warmly today, ask how they are, and ensure your shared entrance or street edge is tidy.",
            reflectionPromptUr = "کیا میرے گھر کے کسی عمل (آواز، کوڑا، پارکنگ) سے پڑوسی کو کوئی تکلیف تو نہیں ہو رہی؟",
            reflectionPromptEn = "Could any habit of mine—noise, parking, or waste—be inconveniencing my neighbors?",
            goodDeedChallengeUr = "آج کسی پڑوسی کے گھر کوئی چھوٹا تحفہ یا کھانے کی چیز بھیجیں یا ان کا کوئی کام کر دیں۔",
            goodDeedChallengeEn = "Share a warm meal, fruit, or helpful favor with a neighbor today.",
            quiz = listOf(
                QuizQuestion("d12q1", "صحیح بخاری کے مطابق کس شخص کا ایمان کامل نہیں؟", "According to Sahih al-Bukhari, whose faith is incomplete?", listOf("جس کا گھر چھوٹا ہو", "جس کا پڑوسی اس کی تکلیف سے محفوظ نہ ہو", "جو کم سفر کرے", "جو کم کھائے"), listOf("One with a small home", "One whose neighbor is not safe from their harm", "One who travels little", "One who eats little"), 1, "پڑوسی کو امن و تحفظ دینا ایمان کا بنیادی تقاضا ہے۔", "Ensuring a neighbor's safety and peace is essential to faith."),
                QuizQuestion("d12q2", "سورۃ النساء (4:36) کے مطابق کن پڑوسیوں سے اچھا سلوک لازم ہے؟", "Which neighbors deserve good treatment per Surah An-Nisa (4:36)?", listOf("صرف رشتہ دار پڑوسی", "رشتہ دار اور اجنبی دونوں پڑوسی", "صرف امیر پڑوسی", "صرف ایک ہی برادری کے"), listOf("Only relatives", "Both close/related and unfamiliar neighbors", "Only wealthy neighbors", "Only one's own group"), 1, "قرآن ہر طرح کے پڑوسی کے ساتھ احسان کا حکم دیتا ہے۔", "The Quran mandates kindness to both familiar and unfamiliar neighbors."),
                QuizQuestion("d12q3", "نبی کریم ﷺ کو جبرائیلؑ کی تاکید سے پڑوسی کے بارے میں کیا گمان گزرا؟", "What did the Prophet ﷺ think due to Jibril's repeated emphasis on neighbors?", listOf("کہ شاید پڑوسی کو وراثت میں حصہ دار بنا دیا جائے", "کہ محلہ بدلنا منع ہے", "کہ روزے کم ہوں گے", "کہ تحفہ دینا منع ہے"), listOf("That neighbors might be made heirs", "That moving homes is forbidden", "That fasting would decrease", "That gifts are forbidden"), 0, "یہ واقعہ پڑوسی کے عظیم حق کو ظاہر کرتا ہے۔", "This highlights the extraordinary status of neighbors in Islam."),
                QuizQuestion("d12q4", "پڑوسی کے حق کی عملی خلاف ورزی کیا ہے؟", "Which action violates a neighbor's rights?", listOf("سلام کرنا", "رات دیر تک اونچی آواز میں شور مچانا یا ان کے آگے کچرا ڈالنا", "بیماری میں پوچھنا", "کھانا بانٹنا"), listOf("Greeting kindly", "Playing loud noise late at night or leaving trash by their door", "Visiting when sick", "Sharing food"), 1, "تکلیف دہ شور اور گندگی پڑوسی کے حق کے خلاف ہے۔", "Disturbing noise and litter harm a neighbor's comfort."),
                QuizQuestion("d12q5", "محلے کو محفوظ اور متحد کیسے بنایا جا سکتا ہے؟", "How can a neighborhood become safer and more united?", listOf("دروازے بند کر کے", "باہمی سلام، احترام اور ضرورت میں مدد سے", "ایک دوسرے کی جاسوسی سے", "افواہ پھیلا کر"), listOf("Never speaking", "Mutual greetings, respect, and helping in need", "Spying on each other", "Spreading rumors"), 1, "پڑوسیوں کا تعاون پورے محلے کی طاقت بنتا ہے۔", "Mutual goodwill turns neighbors into a caring community.")
            )
        ),
        CuratedLesson(
            dayNumber = 13,
            weekNumber = 2,
            categoryIds = listOf("community_service", "islamic_character"),
            titleUr = "دوسروں کا احترام اور لوگوں کی مدد کرنا",
            titleEn = "Respecting Others and Helping People",
            objectivesUr = listOf(
                "ہر انسان (بشمول محنت کش، ملازمین اور کمزور طبقات) کے وقار کا احترام سیکھنا۔",
                "معاشرتی برتری کے بجائے عاجزی اور نفع بخش کردار اپنانا۔",
                "اپنی صلاحیت، وقت یا مسکراہٹ سے روزانہ کسی کے کام آنا۔"
            ),
            objectivesEn = listOf(
                "Honor the dignity of every person, including laborers, helpers, and vulnerable groups.",
                "Replace social arrogance with humility and practical usefulness.",
                "Use your skills, time, or even a kind word to ease someone's burden daily."
            ),
            introUr = "انسان کا اصل قد اس کے عہدے یا دولت سے نہیں بلکہ اس بات سے ناپا جاتا ہے کہ وہ کمزور اور عام لوگوں سے کیسا سلوک کرتا ہے۔",
            introEn = "True nobility is measured not by wealth or status, but by how respectfully you treat everyday people and those with less power.",
            explanationUr = "ہمارے معاشرے میں اکثر طاقتور کے سامنے جھکنا اور صفائی کرنے والے، ڈرائیور، گھریلو ملازم یا ویٹر کے ساتھ تلخی سے بولنا عام ہو جاتا ہے۔ اسلام ہر انسان کو عزتِ نفس دیتا ہے۔ نبی کریم ﷺ نے فرمایا کہ بہترین انسان وہ ہے جو لوگوں کو سب سے زیادہ فائدہ پہنچائے۔ راستے سے کوئی تکلیف دہ چیز ہٹانا، کسی بوڑھے کا وزن اٹھا دینا، صف میں اپنی باری کا احترام کرنا، یا کسی پریشان حال کو حوصلہ دینا—یہ سب چھوٹے نظر آنے والے اعمال دنیا کو خوبصورت اور محفوظ بناتے ہیں۔",
            explanationEn = "Sadly, society often flatters the powerful while speaking harshly to cleaners, drivers, shop helpers, or domestic workers. Islam affirms the dignity of every human being. The Prophet ﷺ taught that the best of people are those most beneficial to others. Removing an obstacle from a path, waiting patiently in line, speaking gently to service workers, and carrying an elder's bag are small acts that elevate an entire society.",
            quranArabic = "وَلَقَدْ كَرَّمْنَا بَنِي آدَمَ",
            quranTranslationUr = "اور بے شک ہم نے بنی آدم (تمام انسانوں) کو عزت و تکریم عطا کی ہے۔",
            quranTranslationEn = "And We have certainly honored the children of Adam.",
            quranRefUr = "سورۃ بنی اسرائیل 17:70",
            quranRefEn = "Surah Al-Isra 17:70",
            hadithTextUr = "لوگوں میں سب سے بہترین وہ ہے جو لوگوں کے لیے سب سے زیادہ نفع بخش (مددگار) ہو۔",
            hadithTextEn = "The best of people are those who are most beneficial to other people.",
            hadithRefUr = "المعجم الاوسط للطبرانی / صحیح الجامع، حدیث 3289 (مستند مفہوم کے ساتھ معروف روایت)",
            hadithRefEn = "Al-Mu'jam al-Awsat / Sahih al-Jami', Hadith 3289 (Verified meaning; classical citation)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول کے خاکروب، چوکیدار یا بس ڈرائیور کو سلام اور شکریہ کہنا اور کسی نئے طالب علم کو راستہ بتانا۔",
            teenExampleEn = "Greeting school custodians, guards, and bus drivers warmly and welcoming a new student.",
            youngAdultExampleUr = "قطار (Queue) کا احترام کرنا، بزرگوں کے لیے بس یا کمرے میں نشست چھوڑنا اور کمزور کی مدد کرنا۔",
            youngAdultExampleEn = "Respecting queues, offering your seat to elders or pregnant women, and helping peers politely.",
            adultExampleUr = "ملازمین اور مزدوروں کی اجرت وقت پر اور عزت کے ساتھ ادا کرنا اور کبھی ان کی تذلیل نہ کرنا۔",
            adultExampleEn = "Paying workers promptly and fairly, and always speaking to staff with dignity and thanks.",
            keyLessonsUr = listOf(
                "ہر انسان بحیثیت اولادِ آدم عزت و احترام کا مستحق ہے۔",
                "سب سے اچھا انسان وہی ہے جس سے دوسروں کو فائدہ پہنچے۔",
                "شکریہ، مسکراہٹ اور عاجزی معاشرتی فاصلے مٹاتی ہیں۔"
            ),
            keyLessonsEn = listOf(
                "Every human being carries God-given dignity.",
                "Greatness lies in being genuinely helpful to others.",
                "Respecting workers and smiling kindly heals social divides."
            ),
            practicalActivityUr = "آج کم از کم دو ایسے افراد (چوکیدار، صفائی کارکن، دکاندار یا ڈرائیور) کو پورے احترام سے سلام کریں اور شکریہ ادا کریں۔",
            practicalActivityEn = "Greet and sincerely thank at least two service workers today (e.g., cleaner, guard, driver, or clerk).",
            reflectionPromptUr = "کیا میں لوگوں کے عہدے دیکھ کر اپنا لہجہ بدلتا ہوں یا سب سے یکساں احترام سے پیش آتا ہوں؟",
            reflectionPromptEn = "Do I change my tone based on someone's status, or treat everyone with equal respect?",
            goodDeedChallengeUr = "آج راستے میں پڑی کوئی تکلیف دہ چیز ہٹا دیں یا کسی کی فوری چھوٹی سی مدد کر دیں۔",
            goodDeedChallengeEn = "Remove a hazard from a walkway or quietly assist someone carrying a load today.",
            quiz = listOf(
                QuizQuestion("d13q1", "سورۃ بنی اسرائیل (17:70) کے مطابق اللہ نے کسے تکریم عطا کی ہے؟", "Whom has Allah honored according to Surah Al-Isra (17:70)?", listOf("صرف مالداروں کو", "تمام بنی آدم (انسانوں) کو", "صرف بادشاہوں کو", "صرف ایک قبیلے کو"), listOf("Only the wealthy", "All children of Adam (all humanity)", "Only rulers", "Only one tribe"), 1, "انسانی وقار رنگ، نسل اور حیثیت سے بالاتر ہے۔", "Human dignity belongs to all humanity regardless of rank."),
                QuizQuestion("d13q2", "حدیث کے مطابق لوگوں میں سب سے بہترین کون ہے؟", "Who are the best among people according to the Hadith?", listOf("جو سب سے زیادہ نفع بخش ہو", "جو سب سے مہنگی سواری رکھے", "جو سب سے الگ رہے", "جو دوسروں پر حکم چلائے"), listOf("Those most beneficial to others", "Those with luxury cars", "Those who isolate themselves", "Those who order others around"), 0, "خلقِ خدا کے کام آنا بہترین کردار کی پہچان ہے۔", "Being useful and helpful to humanity is true excellence."),
                QuizQuestion("d13q3", "محنت کشوں اور ملازمین کے ساتھ کیسا رویہ رکھنا چاہیے؟", "How should workers and helpers be treated?", listOf("سخت لہجے سے", "مکمل احترام، شکر گزاری اور بروقت اجرت کے ساتھ", "کم حق دے کر", "نظر انداز کر کے"), listOf("Harshly", "With dignity, gratitude, and timely fair pay", "Underpaying", "Ignoring them"), 1, "عزت اور انصاف ہر محنت کش کا حق ہے۔", "Dignity and prompt, fair compensation are every worker's right."),
                QuizQuestion("d13q4", "راستے سے تکلیف دہ چیز ہٹانا اسلام میں کیا شمار ہوتا ہے؟", "How does Islam view removing a harmful obstacle from a road?", listOf("معمولی کام", "صدقہ اور ایمان کا حصہ", "وقت کا ضیاع", "دوسروں کا کام"), listOf("Trivial", "An act of charity and part of faith", "A waste of time", "Someone else's job"), 1, "چھوٹی سماجی ذمہ داری بھی عبادت بن جاتی ہے۔", "Even small civic care counts as charity."),
                QuizQuestion("d13q5", "عاجزی کا انسان کے تعلقات پر کیا اثر پڑتا ہے؟", "How does humility affect relationships?", listOf("عزت کم ہوتی ہے", "محبت اور احترام بڑھتا ہے", "لوگ ڈرتے ہیں", "کوئی فرق نہیں پڑتا"), listOf("Respect drops", "It builds warmth and mutual respect", "People feel afraid", "No effect"), 1, "تواضع دلوں کو قریب لاتی ہے۔", "Humility brings hearts together.")
            )
        ),
        CuratedLesson(
            dayNumber = 14,
            weekNumber = 2,
            categoryIds = listOf("family_life", "quizzes_assessments"),
            titleUr = "ہفتہ وار جائزہ اور عملی امتحان",
            titleEn = "Weekly Review and Practical Assessment",
            objectivesUr = listOf(
                "ہفتہ دوم (خاندانی اور سماجی ذمہ داریوں) کے تمام اسباق کا خلاصہ دہرانا۔",
                "والدین، گھر والوں، رشتہ داروں اور پڑوسیوں کے ساتھ اپنے رویے کا احتساب کرنا۔",
                "تیسرے ہفتے (اتحاد و امن) کے لیے دل کو تیار کرنا۔"
            ),
            objectivesEn = listOf(
                "Review all Week 2 lessons on family and neighborhood responsibilities.",
                "Evaluate how our tone and care improved toward parents, family, relatives, and neighbors.",
                "Prepare to enter Week 3 on Unity, Peace, and Brotherhood."
            ),
            introUr = "ہفتہ دوم میں ہم نے اپنے اردگرد کے قریبی دائروں—گھر، خاندان اور محلے—کو محبت سے سنوارنا سیکھا۔",
            introEn = "In Week 2, we learned to nurture the circles closest to us: parents, home, extended family, and neighbors.",
            explanationUr = "اس ہفتے ہم نے والدین کے ادب، میاں بیوی کے تعاون، بچوں کی شفیق تربیت، صلہ رحمی، پڑوسیوں کے حقوق اور عام لوگوں کے احترام کا مطالعہ کیا۔ اصل تبدیلی اس وقت آتی ہے جب ہمارے گھر والے خود محسوس کریں کہ پیغامِ خیر نے ہمارے اندر نرمی، صبر اور خدمت کا جذبہ بڑھا دیا ہے۔ آج اپنے اس ہفتے کی کارکردگی کا جائزہ لیں اور کسی ایک رشتے کو مزید مضبوط کرنے کا عملی عزم کریں۔",
            explanationEn = "This week covered respecting parents, marital kindness, loving upbringing, maintaining kinship ties, neighbors' rights, and honoring all people. Real growth shows when our families actually feel greater warmth, patience, and helpfulness from us. Take today to reflect on Week 2 and strengthen one family or neighborhood bond.",
            quranArabic = "وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ۖ وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ",
            quranTranslationUr = "اور نیکی اور پرہیزگاری کے کاموں میں ایک دوسرے کی مدد کرو، اور گناہ اور زیادتی میں تعاون نہ کرو۔",
            quranTranslationEn = "And cooperate in righteousness and piety, but do not cooperate in sin and aggression.",
            quranRefUr = "سورۃ المائدہ 5:2",
            quranRefEn = "Surah Al-Ma'idah 5:2",
            hadithTextUr = "جو اللہ اور آخرت کے دن پر ایمان رکھتا ہے، وہ اپنے پڑوسی کو تکلیف نہ دے اور اپنے مہمان کی عزت کرے۔",
            hadithTextEn = "Whoever believes in Allah and the Last Day should not harm their neighbor and should honor their guest.",
            hadithRefUr = "صحیح بخاری، حدیث 6018 / صحیح مسلم، حدیث 47 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6018 / Sahih Muslim, Hadith 47 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اس ہفتے والدین اور بہن بھائیوں کے ساتھ اپنی مدد اور احترام کی عادت کا جائزہ لینا۔",
            teenExampleEn = "Reviewing how consistently you respected your parents and supported siblings this week.",
            youngAdultExampleUr = "گھر والوں اور ہمسایوں کے ساتھ روابط میں آنے والی مثبت تبدیلی کو نوٹ کرنا۔",
            youngAdultExampleEn = "Noticing how your communication with family and neighbors improved over Week 2.",
            adultExampleUr = "گھر کے اندر شکر گزاری، بچوں کی تربیت اور رشتہ داروں سے رابطے کو مستقل ہفتہ وار عادت بنانا۔",
            adultExampleEn = "Turning family gratitude, patient parenting, and weekly relative check-ins into lasting routines.",
            keyLessonsUr = listOf(
                "نیکی میں باہمی تعاون گھر اور محلے کو مضبوط بناتا ہے۔",
                "گھر والوں کے ساتھ اچھا سلوک سچے کردار کا ثبوت ہے۔",
                "ہر ہفتے کا جائزہ اگلے قدم کو واضح کرتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Cooperating in goodness strengthens homes and neighborhoods.",
                "How we treat family is the clearest mirror of our character.",
                "Weekly reflection turns good intentions into steady habits."
            ),
            practicalActivityUr = "گھر والوں کے ساتھ بیٹھ کر نیکی کے کسی ایک مشترکہ کام (جیسے صفائی، کسی کی مدد یا خاندانی دعا) کی منصوبہ بندی کریں۔",
            practicalActivityEn = "Plan one small shared act of kindness with your family (such as a home cleanup, helping a neighbor, or family prayer).",
            reflectionPromptUr = "ہفتہ دوم میں کس رشتے میں سب سے زیادہ بہتری آئی اور کس رشتے کو ابھی مزید توجہ چاہیے؟",
            reflectionPromptEn = "Which relationship improved most during Week 2, and which one needs extra care next?",
            goodDeedChallengeUr = "آج گھر کے سب افراد کے لیے کوئی خوشگوار سرپرائز یا محبت بھرا پیغام پیش کریں۔",
            goodDeedChallengeEn = "Surprise your family with a thoughtful gesture or warm words of appreciation today.",
            quiz = listOf(
                QuizQuestion("d14q1", "سورۃ المائدہ (5:2) میں کس چیز میں تعاون کا حکم دیا گیا ہے؟", "What does Surah Al-Ma'idah (5:2) command us to cooperate in?", listOf("گناہ اور زیادتی میں", "نیکی اور تقویٰ کے کاموں میں", "جھگڑوں میں", "غیبت میں"), listOf("Sin and aggression", "Righteousness and piety", "Quarrels", "Backbiting"), 1, "نیکی کے کاموں میں مل کر آگے بڑھنا قرآنی اصول ہے۔", "Cooperating in goodness is a core Quranic principle."),
                QuizQuestion("d14q2", "ہفتہ دوم کا بنیادی دائرہ کیا تھا؟", "What was the core focus of Week 2?", listOf("صرف انفرادی عبادت", "خاندانی اور معاشرتی ذمہ داریاں", "تاریخی جنگیں", "تجارت"), listOf("Solitary habits", "Family and social responsibilities", "Ancient history", "Commerce"), 1, "دوسرا ہفتہ گھر، رشتہ داروں اور محلے کے حقوق پر مشتمل تھا۔", "Week 2 focused on home, kinship, and neighborhood care."),
                QuizQuestion("d14q3", "والدین کی رضا اور گھر والوں کے ساتھ اچھا سلوک کیا ظاہر کرتا ہے؟", "What do kindness to parents and family reveal?", listOf("کمزوری", "اعلیٰ اسلامی اخلاق اور سچا ایمان", "مجبوری", "تکلف"), listOf("Weakness", "High Islamic character and sincere faith", "Helplessness", "Formality"), 1, "اہلِ خانہ کے ساتھ حسنِ سلوک دین کا مرکزی درس ہے۔", "Care for family is central to authentic Islamic character."),
                QuizQuestion("d14q4", "اگر کوئی رشتہ دار ناراض ہو تو ہمیں کیا کرنا چاہیے؟", "If a relative is distant or upset, what should we do?", listOf("بات بالکل بند کر دیں", "انا چھوڑ کر محبت سے رابطہ بحال کرنے کی کوشش کریں", "لوگوں میں شکایت کریں", "انتظار کریں"), listOf("Cut ties completely", "Set aside pride and reach out kindly", "Complain publicly", "Wait forever"), 1, "پہل کرنے والا زیادہ اجر پاتا ہے۔", "Taking the first kind step brings greater reward."),
                QuizQuestion("d14q5", "پڑوسی اور مہمان کا احترام کس چیز کی علامت بتایا گیا ہے؟", "Honoring neighbors and guests is described as a sign of what?", listOf("امارت", "اللہ اور آخرت پر سچے ایمان کی", "سیاست", "تکبر"), listOf("Wealth", "Sincere faith in Allah and the Last Day", "Politics", "Pride"), 1, "ایمان کا عملی ثبوت انسانوں کے ساتھ اچھے سلوک سے ملتا ہے۔", "Faith expresses itself in kindness to neighbors and guests.")
            )
        )
    )
}

package com.example.data.model

object CurriculumWeek4 {
    val lessons: List<CuratedLesson> = listOf(
        CuratedLesson(
            dayNumber = 22,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "islamic_character"),
            titleUr = "رشوت اور بدعنوانی کو مسترد کرنا",
            titleEn = "Rejecting Bribery and Corruption",
            objectivesUr = listOf(
                "رشوت، سفارشِ ناحق اور مالی بدعنوانی کی شرعی و اخلاقی حرمت سمجھنا۔",
                "ملازمت اور کاروبار میں حلال روزی اور شفافیت کی برکت جاننا۔",
                "چھوٹی سطح پر بھی بے ایمانی اور ناانصافی کا حصہ نہ بننے کا عزم کرنا۔"
            ),
            objectivesEn = listOf(
                "Understand the strict prohibition of bribery, favoritism, and corruption.",
                "Appreciate the blessing of lawful, honest earnings in work and business.",
                "Commit to avoiding dishonest shortcuts even in small everyday matters."
            ),
            introUr = "رشوت اور کرپشن وہ دیمک ہیں جو قابل لوگوں کا حق مارتی ہیں، اداروں کو کھوکھلا کرتی ہیں اور معاشرے سے برکت اٹھا دیتی ہیں۔",
            introEn = "Bribery and corruption quietly rot institutions, steal from the deserving, and destroy public trust.",
            explanationUr = "اکثر لوگ بڑی کرپشن پر تو تنقید کرتے ہیں مگر چھوٹے کام نکلوانے کے لیے 'چائے پانی' یا ناجائز سفارش کو معمولی سمجھ لیتے ہیں۔ اسلام نے رشوت دینے والے، لینے والے اور دونوں کے درمیان واسطہ بننے والے پر سخت وعید سنائی ہے۔ قرآن ناحق طریقے سے دوسروں کا مال کھانے اور حکام تک رشوت پہنچانے سے واضح منع کرتا ہے۔ جب کوئی فرد دیانت داری پر ڈٹ جاتا ہے، تو وقتی طور پر راستہ مشکل لگ سکتا ہے، مگر اللہ حلال رزق میں برکت، عزت اور سکون عطا فرماتا ہے۔",
            explanationEn = "People often condemn grand corruption while excusing small bribes, 'gifts for favors,' or unfair nepotism in daily errands. Islam condemns the giver, taker, and facilitator of bribery alike, and the Quran strictly forbids consuming others' wealth unjustly or bribing authorities to bend justice. Standing firm on honest earnings may feel slower at first, yet lawful income brings peace of mind and lasting blessing.",
            quranArabic = "وَلَا تَأْكُلُوا أَمْوَالَكُم بَيْنَكُم بِالْبَاطِلِ وَتُدْلُوا بِهَا إِلَى الْحُكَّامِ لِتَأْكُلُوا فَرِيقًا مِّنْ أَمْوَالِ النَّاسِ بِالْإِثْمِ وَأَنتُمْ تَعْلَمُونَ",
            quranTranslationUr = "اور آپس میں ایک دوسرے کا مال ناحق طریقے سے نہ کھاؤ اور نہ ہی حکام کے آگے (رشوت کے طور پر) پیش کرو تاکہ جان بوجھ کر گناہ کے ساتھ لوگوں کے مال کا کچھ حصہ کھا جاؤ۔",
            quranTranslationEn = "And do not consume one another's wealth unjustly or send it in bribery to the rulers in order that you may knowingly consume a portion of the wealth of others in sin.",
            quranRefUr = "سورۃ البقرۃ 2:188",
            quranRefEn = "Surah Al-Baqarah 2:188",
            hadithTextUr = "رسول اللہ ﷺ نے رشوت دینے والے اور رشوت لینے والے دونوں پر لعنت فرمائی ہے۔",
            hadithTextEn = "The Messenger of Allah ﷺ cursed both the one who gives a bribe and the one who takes a bribe.",
            hadithRefUr = "سنن ابی داؤد، حدیث 3580 / جامع ترمذی، حدیث 1337 (مستند)",
            hadithRefEn = "Sunan Abi Dawud, Hadith 3580 / Jami' at-Tirmidhi, Hadith 1337 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول یا کھیلوں کی ٹیم میں انتخاب کے لیے کسی ناجائز سفارش کے بجائے اپنی محنت اور قابلیت پر بھروسہ کرنا۔",
            teenExampleEn = "Relying on honest practice and merit for school teams or awards instead of unfair favoritism.",
            youngAdultExampleUr = "لائسنس، سرٹیفکیٹ یا نوکری کے حصول میں ایجنٹ یا رشوت کا سہارا لینے سے انکار کر کے قانونی طریقہ اپنانا۔",
            youngAdultExampleEn = "Refusing illegal shortcuts or bribes when applying for documents, licenses, or jobs.",
            adultExampleUr = "دفتر یا کاروبار میں کمیشن، کک بیک یا تحفے کے نام پر ناجائز فائدہ نہ لینا اور میرٹ پر فیصلے کرنا۔",
            adultExampleEn = "Rejecting kickbacks, hidden commissions, or biased favors at work and honoring merit.",
            keyLessonsUr = listOf(
                "رشوت دینا اور لینا دونوں سخت حرام اور معاشرتی ظلم ہیں۔",
                "ناجائز سفارش کسی حقدار کا حق چھیننے کے مترادف ہے۔",
                "تھوڑا حلال رزق ڈھیر سارے حرام مال سے ہزار گنا بہتر ہے۔"
            ),
            keyLessonsEn = listOf(
                "Both offering and accepting bribes are strictly forbidden.",
                "Unfair favoritism steals opportunities from deserving people.",
                "Honest, lawful income brings far greater peace than ill-gotten gain."
            ),
            practicalActivityUr = "اپنے کام، پڑھائی یا گھریلو لین دین میں آج ایک اصول طے کریں کہ کسی بھی معاملے میں غیر قانونی یا بے ایمانی والا شارٹ کٹ نہیں اپنائیں گے۔",
            practicalActivityEn = "Set a firm rule in your daily work, studies, and errands: zero dishonest shortcuts, regardless of convenience.",
            reflectionPromptUr = "کیا میں نے کبھی 'چیزیں جلدی کرانے' کے نام پر کسی بے ایمانی یا ناحق سفارش کو معمولی سمجھا ہے؟",
            reflectionPromptEn = "Have I ever excused small dishonest favors just to speed something up?",
            goodDeedChallengeUr = "آج اپنی باری کا صبر سے انتظار کریں اور ایمانداری کے ساتھ اپنا حق یا فرض پورا کریں۔",
            goodDeedChallengeEn = "Wait patiently in line today and refuse any unfair shortcut or favoritism.",
            quiz = listOf(
                QuizQuestion("d22q1", "سورۃ البقرۃ (2:188) میں کس عمل سے منع فرمایا گیا ہے؟", "What does Surah Al-Baqarah (2:188) prohibit?", listOf("حلال تجارت سے", "ناحق مال کھانے اور حکام کو رشوت دینے سے", "صدقہ دینے سے", "سفر کرنے سے"), listOf("Lawful trade", "Consuming wealth unjustly and bribing officials", "Giving charity", "Traveling"), 1, "قرآن مالی بدعنوانی اور رشوت کو واضح طور پر حرام قرار دیتا ہے۔", "The Quran explicitly forbids bribery and unjust wealth."),
                QuizQuestion("d22q2", "حدیث کے مطابق رشوت کے معاملے میں کون وعید کا مستحق ہے؟", "According to the Hadith, who is condemned in bribery?", listOf("صرف لینے والا", "دینے والا اور لینے والا دونوں", "صرف دیکھنے والا", "کوئی نہیں"), listOf("Only the taker", "Both the giver and the taker", "Only bystanders", "No one"), 1, "رشوت کا لین دین کرنے والے دونوں فریق گناہ میں شریک ہیں۔", "Both offering and taking bribes are condemned."),
                QuizQuestion("d22q3", "ناجائز سفارش کا معاشرے کو کیا نقصان ہوتا ہے؟", "How does unfair nepotism harm society?", listOf("قابلیت کی حوصلہ افزائی ہوتی ہے", "حقدار اور محنتی لوگوں کا حق مارا جاتا ہے", "ادارے مضبوط ہوتے ہیں", "انصاف بڑھتا ہے"), listOf("Merit grows", "Deserving, hardworking people lose their rights", "Institutions strengthen", "Justice rises"), 1, "میرٹ کا قتل پورے معاشرے کو مایوس اور کمزور کرتا ہے۔", "Ignoring merit demoralizes honest citizens and weakens institutions."),
                QuizQuestion("d22q4", "تھوڑے حلال رزق کی کیا خوبی ہے؟", "What is the blessing of modest lawful earnings?", listOf("دل میں سکون اور برکت", "لوگوں کا خوف", "پریشانی", "بے اطمینانی"), listOf("Inner peace and blessing (Barakah)", "Fear of people", "Worry", "Restlessness"), 0, "حلال کمائی میں کم مقدار بھی سکون اور کفایت لاتی ہے۔", "Lawful income brings tranquility and lasting blessing."),
                QuizQuestion("d22q5", "بدعنوانی کے خاتمے کا آغاز کہاں سے ہوتا ہے؟", "Where does ending corruption begin?", listOf("صرف دوسروں کو کوسنے سے", "ہر فرد کے خود رشوت و بے ایمانی سے انکار کرنے سے", "قوانین توڑنے سے", "خاموش تماشائی بننے سے"), listOf("Only blaming others", "Each individual refusing dishonest shortcuts personally", "Breaking rules", "Doing nothing"), 1, "معاشرتی دیانت انفرادی انکار اور استقامت سے جنم لیتی ہے۔", "Social integrity starts with personal refusal to compromise honesty.")
            )
        ),
        CuratedLesson(
            dayNumber = 23,
            weekNumber = 4,
            categoryIds = listOf("community_service", "social_reform"),
            titleUr = "یتیموں اور غریب خاندانوں کی مدد",
            titleEn = "Helping Orphans and Poor Families",
            objectivesUr = listOf(
                "یتیموں، بیواؤں اور سفید پوش غریبوں کی کفالت کی عظیم فضیلت جاننا۔",
                "امداد کرتے وقت مستحق کی عزتِ نفس اور پردہ داری کا خیال رکھنا۔",
                "زکوٰۃ و صدقات کے ساتھ تعلیم اور ہنر سکھا کر خاندانوں کو خود کفیل بنانا۔"
            ),
            objectivesEn = listOf(
                "Appreciate the high honor of supporting orphans, widows, and struggling families.",
                "Protect recipients' dignity and privacy when giving charity (avoiding showy photos).",
                "Pair financial relief with education and skills so families become self-reliant."
            ),
            introUr = "جس معاشرے میں کمزور، یتیم اور غریب خود کو تنہا نہ سمجھیں، وہاں اللہ کی رحمت اور امن اترتا ہے۔",
            introEn = "When orphans and struggling families are cared for with dignity, a community receives mercy and stability.",
            explanationUr = "نبی کریم ﷺ خود بچپن میں یتیم تھے اور قرآن نے بار بار یتیم کی عزت کرنے اور اسے نہ جھڑکنے کا حکم دیا ہے۔ آپ ﷺ نے فرمایا کہ میں اور یتیم کی کفالت کرنے والا جنت میں دو انگلیوں کی طرح قریب ہوں گے۔ آج کے دور میں مدد کا بہترین طریقہ یہ ہے کہ ہم اپنے اردگرد خاموش سفید پوش خاندانوں کی خبر رکھیں، ان کی مدد کرتے وقت تصویر کھینچ کر تشہیر نہ کریں تاکہ ان کی عزتِ نفس مجروح نہ ہو، اور ممکن ہو تو کسی یتیم بچے کی تعلیم یا کسی گھرانے کے روزگار کا ذریعہ بنیں۔",
            explanationEn = "The Prophet ﷺ himself grew up an orphan, and the Quran repeatedly warns against harshness toward orphans or turning away the needy. He promised that whoever sponsors an orphan will stand beside him in Paradise like two adjacent fingers. True charity protects human dignity—never humiliating recipients with publicity photos, quietly noticing struggling neighbors, and helping children stay in school or parents earn a living.",
            quranArabic = "فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ ۝ وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ",
            quranTranslationUr = "پس آپ یتیم پر سختی نہ کیجیے، اور مانگنے والے کو نہ جھڑکیے۔",
            quranTranslationEn = "So as for the orphan, do not oppress him; and as for the one who asks, do not repel him.",
            quranRefUr = "سورۃ الضحیٰ 93:9-10",
            quranRefEn = "Surah Ad-Duha 93:9-10",
            hadithTextUr = "میں اور یتیم کی کفالت کرنے والا جنت میں اس طرح (قریب) ہوں گے۔ اور آپ ﷺ نے شہادت کی اور درمیانی انگلی ملا کر دکھائی۔",
            hadithTextEn = "I and the one who sponsors an orphan will be in Paradise like these two—and he held his index and middle fingers close together.",
            hadithRefUr = "صحیح بخاری، حدیث 5304 / 6005 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 5304 / 6005 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اپنے جیب خرچ کا چھوٹا سا حصہ بچا کر کسی ضرورت مند ہم جماعت کی کاپی کتابوں یا کھانے میں خاموشی سے مدد کرنا۔",
            teenExampleEn = "Saving a small part of your pocket money to quietly help buy school supplies or lunch for a classmate in need.",
            youngAdultExampleUr = "یونیورسٹی کے دوستوں کے ساتھ مل کر مستحق بچوں کو مفت ٹیوشن پڑھانا یا راشن ڈرائیو منظم کرنا۔",
            youngAdultExampleEn = "Organizing free tutoring for underserved kids or a quiet student food drive without filming faces.",
            adultExampleUr = "کسی بیوہ یا غریب رشتہ دار/پڑوسی کے بچوں کی ماہانہ فیس یا علاج میں خاموشی سے تعاون کرنا۔",
            adultExampleEn = "Quietly covering school fees, groceries, or medical bills for a widowed neighbor or struggling family.",
            keyLessonsUr = listOf(
                "یتیم کی کفالت جنت میں قربِ نبوی ﷺ کا ذریعہ ہے۔",
                "امداد کرتے وقت کسی کی تصویر یا تشہیر کر کے عزت مجروح نہ کریں۔",
                "تعلیم اور ہنر میں مدد غریب خاندان کو مستقل سہارا دیتی ہے۔"
            ),
            keyLessonsEn = listOf(
                "Caring for orphans earns closeness to the Prophet ﷺ in Paradise.",
                "Never publicize or shame recipients while giving charity.",
                "Education and job skills empower families long-term."
            ),
            practicalActivityUr = "اپنے گھر سے قابلِ استعمال کپڑے، کتابیں یا تھوڑی رقم الگ کریں اور کسی مستحق خاندان یا معتبر فلاحی ادارے تک عزت کے ساتھ پہنچائیں۔",
            practicalActivityEn = "Set aside clean, usable books, clothes, or modest funds today to share respectfully with a needy family or trusted local charity.",
            reflectionPromptUr = "کیا میں مستحق لوگوں کی مدد عزتِ نفس کے ساتھ کرتا ہوں یا صرف رسم پوری کرتا ہوں؟",
            reflectionPromptEn = "When I give help, do I prioritize the recipient's dignity and privacy?",
            goodDeedChallengeUr = "آج خاموشی سے کسی مستحق شخص، مزدور یا یتیم کے حق میں کچھ صدقہ نکالیں۔",
            goodDeedChallengeEn = "Give a quiet act of charity today without telling anyone about it.",
            quiz = listOf(
                QuizQuestion("d23q1", "صحیح بخاری کی حدیث کے مطابق یتیم کی کفالت کرنے والا جنت میں کس کے قریب ہوگا؟", "According to Sahih al-Bukhari, whom will the orphan's sponsor be close to in Paradise?", listOf("تنہا ہوگا", "نبی کریم ﷺ کے بالکل قریب", "دور ہوگا", "معلوم نہیں"), listOf("Alone", "Close beside the Prophet ﷺ like two fingers", "Far away", "Unknown"), 1, "یتیم کی پرورش اور سرپرستی غیر معمولی اعزاز رکھتی ہے۔", "Caring for orphans holds one of the highest honors in Paradise."),
                QuizQuestion("d23q2", "سورۃ الضحیٰ (93:9-10) میں یتیم اور سائل کے ساتھ کس بات سے منع کیا گیا؟", "What does Surah Ad-Duha (93:9-10) forbid regarding orphans and those in need?", listOf("ان کی مدد کرنے سے", "سختی کرنے اور جھڑکنے سے", "سلام کرنے سے", "تعلیم دینے سے"), listOf("Helping them", "Oppressing the orphan or scolding the one asking", "Greeting them", "Educating them"), 1, "کمزوروں کے ساتھ نرمی اور وقار لازم ہے۔", "Gentleness and respect toward the vulnerable are obligatory."),
                QuizQuestion("d23q3", "امداد کرتے وقت مستحق کی عزتِ نفس بچانے کا طریقہ کیا ہے؟", "How do we protect dignity when giving charity?", listOf("تصویر کھینچ کر سوشل میڈیا پر لگانا", "خاموشی اور رازداری سے مدد کرنا", "بھیڑ جمع کرنا", "احسان جتانا"), listOf("Posting photos online", "Giving quietly and privately", "Calling a crowd", "Reminding them later"), 1, "دایاں ہاتھ دے تو بائیں کو خبر نہ ہو—یہی بہترین صدقہ ہے۔", "Quiet charity protects recipients from embarrassment."),
                QuizQuestion("d23q4", "غریب خاندانوں کی طویل مدتی مدد کا بہترین طریقہ کیا ہے؟", "What is a lasting way to uplift poor families?", listOf("صرف ایک وقت کا کھانا", "بچوں کی تعلیم اور والدین کے روزگار/ہنر میں مدد", "تنقید کرنا", "نظر انداز کرنا"), listOf("A single meal only", "Supporting children's education and parents' livelihood/skills", "Criticizing them", "Ignoring them"), 1, "خود کفالت خاندان کو مستقل عزت دیتی ہے۔", "Education and livelihood skills build lasting independence."),
                QuizQuestion("d23q5", "'سفید پوش' مستحق افراد سے کیا مراد ہے؟", "Who are 'dignified discreetly struggling' (Safaid-posh) families?", listOf("جو گلیوں میں شور مچائیں", "جو عزتِ نفس کی وجہ سے ہاتھ نہیں پھیلاتے مگر ضرورت مند ہوتے ہیں", "جو امیر ہوتے ہیں", "جو مدد سے انکار کریں"), listOf("Loud beggars", "Needful families who do not ask out of self-respect", "Wealthy people", "Those who refuse work"), 1, "اپنے اردگرد ایسے خاموش مستحقین کا خیال رکھنا بڑی نیکی ہے۔", "Noticing and quietly helping discreetly struggling neighbors is deeply rewarded.")
            )
        ),
        CuratedLesson(
            dayNumber = 24,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "peace_tolerance"),
            titleUr = "عدل، انصاف اور انسانی حقوق",
            titleEn = "Justice, Fairness and Human Rights",
            objectivesUr = listOf(
                "عدل و انصاف کو ہر تعلق اور دوستی سے بالاتر سمجھنا۔",
                "گواہی، فیصلے، وراثت اور کاروبار میں سچا انصاف قائم کرنا۔",
                "بنیادی انسانی حقوق (جان، مال، عزت، تعلیم، انصاف) کا تحفظ کرنا۔"
            ),
            objectivesEn = listOf(
                "Uphold justice above personal bias, family ties, or group loyalty.",
                "Practice fairness in testimony, judgments, inheritance, and daily decisions.",
                "Protect universal human rights: life, property, dignity, and fair treatment."
            ),
            introUr = "معاشرے کفر سے تو چل سکتے ہیں مگر ظلم اور ناانصافی سے تباہ ہو جاتے ہیں؛ عدل امن کی جان ہے۔",
            introEn = "No society can survive persistent injustice; fairness is the lifeblood of peace and prosperity.",
            explanationUr = "قرآن کریم کا حکم ہے کہ انصاف کے علمبردار بنو اور اللہ کے لیے سچی گواہی دو، خواہ وہ تمہارے اپنے، والدین یا قریبی رشتہ داروں کے خلاف ہی کیوں نہ ہو۔ کسی قوم یا فرد کی دشمنی بھی تمہیں ناانصافی پر آمادہ نہ کرے۔ گھر میں اولاد کے درمیان برابری، کاروبار میں پورا حق، ملازمین کے ساتھ انصاف، عورتوں اور بیٹیوں کو ان کا پورا وراثتی حق دینا، اور اقلیتوں کے شہری حقوق کا تحفظ—یہ سب اسلام کے عطا کردہ عملی انسانی حقوق ہیں۔",
            explanationEn = "The Quran commands believers to stand firmly for justice as witnesses for Allah, even if it goes against themselves, parents, or close relatives—and never to let hatred of any group lead them to act unfairly. Practical justice includes fairness among children at home, giving daughters and women their full rightful inheritance, honoring workers' wages, and protecting minority citizens' rights and safety.",
            quranArabic = "يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ بِالْقِسْطِ شُهَدَاءَ لِلَّهِ وَلَوْ عَلَىٰ أَنفُسِكُمْ أَوِ الْوَالِدَيْنِ وَالْأَقْرَبِينَ",
            quranTranslationUr = "اے ایمان والو! انصاف پر مضبوطی سے قائم رہنے والے اور اللہ کے لیے سچی گواہی دینے والے بنو، خواہ وہ تمہاری اپنی ذات یا والدین یا رشتہ داروں کے خلاف ہی ہو۔",
            quranTranslationEn = "O you who believe, be persistently standing firm in justice, witnesses for Allah, even if it be against yourselves or parents and relatives.",
            quranRefUr = "سورۃ النساء 4:135",
            quranRefEn = "Surah An-Nisa 4:135",
            hadithTextUr = "انصاف کرنے والے لوگ اللہ کے نزدیک نور کے منبروں پر ہوں گے، جو اپنے فیصلوں، اہلِ خانہ اور ماتحتوں میں عدل کرتے ہیں۔",
            hadithTextEn = "Those who are just will be seated upon pulpits of light beside Allah—those who act fairly in their rulings, their families, and those under their care.",
            hadithRefUr = "صحیح مسلم، حدیث 1827 (مستند)",
            hadithRefEn = "Sahih Muslim, Hadith 1827 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "کھیل میں فاؤل یا پوائنٹ کا فیصلہ کرتے وقت اپنے قریبی دوست کی بے جا طرفداری نہ کرنا بلکہ سچ بتانا۔",
            teenExampleEn = "Calling a fair foul or score during a game even if it goes against your best friend.",
            youngAdultExampleUr = "کسی گروہ یا دوست کے جھگڑے میں اندھی حمایت کے بجائے اصل حقائق معلوم کر کے منصفانہ رائے دینا۔",
            youngAdultExampleEn = "Checking the facts before taking sides in a campus dispute, rather than blindly defending your circle.",
            adultExampleUr = "خاندانی وراثت میں بہنوں اور بیٹیوں کو ان کا پورا شرعی و قانونی حصہ خوش دلی سے ادا کرنا اور ملازمین سے انصاف کرنا۔",
            adultExampleEn = "Ensuring sisters and daughters receive their full rightful inheritance willingly, and treating staff fairly.",
            keyLessonsUr = listOf(
                "عدل دوستی، خاندان اور ذاتی مفاد سے بالاتر ہے۔",
                "دشمنی میں بھی کسی پر ظلم یا ناانصافی جائز نہیں۔",
                "اہلِ خانہ اور ماتحتوں سے انصاف نورِ آخرت کا باعث ہے۔"
            ),
            keyLessonsEn = listOf(
                "Justice rises above personal bias, friendship, or kinship.",
                "Disliking someone never justifies treating them unfairly.",
                "Fairness at home and in leadership earns great honor with Allah."
            ),
            practicalActivityUr = "آج کسی ایک معاملے (کام کی تقسیم، وقت، خرید و فروخت یا فیصلہ) میں خود سے پوچھیں: کیا یہ فیصلہ بالکل منصفانہ ہے؟",
            practicalActivityEn = "Pause over one decision today (task sharing, pricing, or resolving a dispute) and verify it is completely fair to both sides.",
            reflectionPromptUr = "کیا میں اپنوں کی غلطی پر چشم پوشی اور غیروں کی غلطی پر سختی تو نہیں کرتا؟",
            reflectionPromptEn = "Do I excuse mistakes made by my own circle while judging outsiders harshly?",
            goodDeedChallengeUr = "آج کسی شخص کو اس کا پورا حق (وقت، تعریف یا بقایا ادائیگی) فوراً اور خوش دلی سے ادا کریں۔",
            goodDeedChallengeEn = "Promptly give someone their full due today—whether credit, time, or payment.",
            quiz = listOf(
                QuizQuestion("d24q1", "سورۃ النساء (4:135) کے مطابق سچی گواہی اور انصاف کب لازم ہے؟", "When is standing firm for justice required per Surah An-Nisa (4:135)?", listOf("صرف غیروں کے خلاف", "ہر حال میں، خواہ اپنے یا والدین اور رشتہ داروں کے خلاف ہو", "صرف جب فائدہ ہو", "صرف عدالت میں"), listOf("Only against strangers", "Always, even against oneself, parents, or relatives", "Only when convenient", "Only in court"), 1, "سچا عدل رشتوں اور مفاد کی پرواہ نہیں کرتا۔", "True justice never bends for personal or family favoritism."),
                QuizQuestion("d24q2", "صحیح مسلم کی حدیث کے مطابق انصاف کرنے والوں کا مقام کیا ہوگا؟", "What rank do the just hold according to Sahih Muslim?", listOf("عام مقام", "اللہ کے نزدیک نور کے منبروں پر", "آخری صف میں", "معلوم نہیں"), listOf("Ordinary rank", "Upon pulpits of light beside Allah", "Last row", "Unknown"), 1, "فیصلوں، گھر اور ماتحتوں میں عدل کرنے والوں کو خاص اعزاز ملے گا۔", "Fair leaders and fair parents receive pulpits of light."),
                QuizQuestion("d24q3", "کسی قوم یا شخص سے اختلاف یا ناپسندیدگی کی حالت میں کیا حکم ہے؟", "What is the Quranic rule when dealing with people you dislike?", listOf("ان کا حق مار لیا جائے", "کسی کی دشمنی تمہیں ناانصافی پر آمادہ نہ کرے", "سخت سلوک کیا جائے", "جھوٹا الزام لگایا جائے"), listOf("Deny their rights", "Never let hatred lead you into acting unjustly", "Be harsh", "Invent accusations"), 1, "سورۃ المائدہ (5:8) میں دشمنی میں بھی عدل قائم رکھنے کا حکم ہے۔", "Surah Al-Ma'idah (5:8) forbids injustice even toward rivals."),
                QuizQuestion("d24q4", "خاندانی سطح پر ایک بڑا ظلم جس سے بچنا ضروری ہے، کیا ہے؟", "What is a common injustice within families that must be avoided?", listOf("تحفے دینا", "بیٹیوں اور بہنوں کو وراثت کے حق سے محروم کرنا", "دعوت کرنا", "دعا دینا"), listOf("Giving gifts", "Depriving daughters and sisters of rightful inheritance", "Inviting relatives", "Praying for them"), 1, "خواتین کو ان کا وراثتی حق دینا قرآنی فرض ہے۔", "Giving women their full rightful inheritance is a strict duty."),
                QuizQuestion("d24q5", "انصاف کس دائرے میں ضروری ہے؟", "Where is fairness required?", listOf("صرف ججوں کے لیے", "گھر، بچوں، ملازمین، تجارت اور پورے معاشرے میں", "صرف دفتر میں", "صرف سیاست میں"), listOf("Only for judges", "At home, with children, workers, trade, and society", "Only in offices", "Only in politics"), 1, "ہر ذمہ دار شخص اپنے دائرے میں عدل کا پابند ہے۔", "Every person is responsible for justice within their sphere.")
            )
        ),
        CuratedLesson(
            dayNumber = 25,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "islamic_character"),
            titleUr = "لوگوں کے مال اور امانت کی حفاظت",
            titleEn = "Protecting People's Property and Trust",
            objectivesUr = listOf(
                "امانت کی وسیع تعریف: مال، راز، وقت، عہدہ اور عوامی املاک۔",
                "سرکاری و عوامی اثاثوں (بجلی، پانی، پارکس، سڑکیں) کو اپنی امانت سمجھنا۔",
                "امانتیں ان کے حقداروں تک بحفاظت پہنچانے کی ذمہ داری اپنانا۔"
            ),
            objectivesEn = listOf(
                "Understand trust (Amanah) broadly: money, confidences, time, office, and public property.",
                "Protect public assets such as parks, water, electricity, and shared spaces.",
                "Return trusts intact and fulfill delegated duties faithfully."
            ),
            introUr = "جس معاشرے میں امانت کا احساس زندہ ہو وہاں نہ تالوں کی کثرت کی ضرورت رہتی ہے اور نہ خوف کا ماحول۔",
            introEn = "Where trustworthiness thrives, locks and suspicion fade away and public life flourishes.",
            explanationUr = "امانت صرف کسی کے رکھے ہوئے پیسوں کا نام نہیں، بلکہ ہر وہ چیز جو آپ کے سپرد کی جائے—چاہے وہ کسی کا راز ہو، دفتر کے کام کا وقت ہو، ادھار لی ہوئی کتاب ہو، یا گلی، اسکول اور ہسپتال کا سرکاری سامان ہو—سب امانت ہیں۔ قرآن حکم دیتا ہے کہ امانتیں ان کے اہل لوگوں کو واپس لوٹاؤ۔ سرکاری بجلی یا پانی ضائع کرنا، عوامی بس کی سیٹ پھاڑنا، یا کام کے وقت میں ذاتی مشاغل میں لگ جانا بھی امانت میں خیانت ہے۔",
            explanationEn = "Amanah (trust) covers far more than money left for safekeeping. Someone's private secret, your paid working hours, a borrowed book, a public park bench, and public utilities are all trusts. The Quran commands returning trusts faithfully to their rightful owners. Wasting workplace resources, damaging public property, or leaking someone's confidence all break trust.",
            quranArabic = "إِنَّ اللَّهَ يَأْمُرُكُمْ أَن تُؤَدُّوا الْأَمَانَاتِ إِلَىٰ أَهْلِهَا",
            quranTranslationUr = "بے شک اللہ تمہیں حکم دیتا ہے کہ امانتیں ان کے حقداروں کے سپرد کرو۔",
            quranTranslationEn = "Indeed, Allah commands you to render trusts to whom they are due.",
            quranRefUr = "سورۃ النساء 4:58",
            quranRefEn = "Surah An-Nisa 4:58",
            hadithTextUr = "جس میں امانت داری نہیں، اس کا ایمان کامل نہیں، اور جس میں عہد کی پابندی نہیں، اس کا دین کامل نہیں۔",
            hadithTextEn = "There is no complete faith for one who has no trustworthiness, and no complete religion for one who does not keep promises.",
            hadithRefUr = "مسند احمد، حدیث 12383 / شعب الایمان للبیہقی (مستند مفہوم)",
            hadithRefEn = "Musnad Ahmad, Hadith 12383 / Bayhaqi (Verified meaning; classical source)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول کے ڈیسک، لائبریری کی کتاب اور کھیل کے سامان کو نقصان نہ پہنچانا اور کسی دوست کا راز راز رکھنا۔",
            teenExampleEn = "Caring for school desks and library books, and keeping a friend's private secret safe.",
            youngAdultExampleUr = "ادھار لی ہوئی رقم یا چیز وقت پر واپس کرنا اور دفتر/انٹرن شپ کے وقت میں پورا کام کرنا۔",
            youngAdultExampleEn = "Returning borrowed items on time and giving full focus during paid internship or work hours.",
            adultExampleUr = "گلی، مسجد اور دفتر کی بجلی و پانی بلا ضرورت کھلا نہ چھوڑنا اور عوامی املاک کی حفاظت کرنا۔",
            adultExampleEn = "Turning off unnecessary lights and taps at work or public buildings and protecting shared community property.",
            keyLessonsUr = listOf(
                "امانت مال کے علاوہ راز، وقت، عہدے اور عوامی اثاثوں پر بھی لاگو ہوتی ہے۔",
                "کسی کا راز افشا کرنا بھی امانت میں خیانت ہے۔",
                "امانت داری ایمان اور دین کی مضبوط بنیاد ہے۔"
            ),
            keyLessonsEn = listOf(
                "Trust covers money, secrets, work hours, authority, and public spaces.",
                "Breaking someone's confidence is a breach of trust.",
                "Faithfulness to trusts and promises defines reliable character."
            ),
            practicalActivityUr = "چیک کریں کہ آپ کے پاس کسی کی کوئی کتاب، پیسے، قلم یا ادھار چیز تو نہیں پڑی؟ آج اسے لوٹانے کا انتظام کریں۔",
            practicalActivityEn = "Check if you still have any borrowed item or small debt to return, and arrange to return it promptly.",
            reflectionPromptUr = "کیا میں عوامی چیزوں (سڑک، پارک، بجلی، دفتر) کی اتنی ہی حفاظت کرتا ہوں جتنی اپنے ذاتی سامان کی؟",
            reflectionPromptEn = "Do I care for public and workplace property with the same respect as my own belongings?",
            goodDeedChallengeUr = "آج کسی عوامی جگہ (مسجد، پارک، اسکول یا گلی) میں غیر ضروری چلتی لائٹ یا نل بند کر کے وسائل بچائیں۔",
            goodDeedChallengeEn = "Save shared resources today by turning off an unused light or tap in a public or shared space.",
            quiz = listOf(
                QuizQuestion("d25q1", "سورۃ النساء (4:58) میں کس چیز کی ادائیگی کا حکم ہے؟", "What does Surah An-Nisa (4:58) command us to render?", listOf("صرف ٹیکس", "امانتیں ان کے حقداروں کو", "صرف تحفے", "سفر"), listOf("Taxes only", "Trusts to whom they are due", "Gifts only", "Travel"), 1, "امانت کی ادائیگی فرد اور ریاست دونوں پر لازم ہے۔", "Delivering trusts faithfully applies to citizens and leaders alike."),
                QuizQuestion("d25q2", "ذیل میں سے کون سی چیز 'امانت' میں شامل ہے؟", "Which of the following counts as a trust (Amanah)?", listOf("کسی کا راز اور مال", "دفتر کے کام کا وقت", "عوامی و سرکاری املاک", "مندرجہ بالا تمام"), listOf("Money and private secrets", "Paid working hours", "Public property", "All of the above"), 3, "ہر وہ شے یا ذمہ داری جو آپ کے سپرد ہو، امانت ہے۔", "Every entrusted item, secret, hour, and public asset is an Amanah."),
                QuizQuestion("d25q3", "اسکول یا پارک کے فرنیچر کو نقصان پہنچانا کیا شمار ہوتا ہے؟", "What is damaging school or park property?", listOf("تفریح", "عوامی امانت میں خیانت اور گناہ", "بچپنا", "جائز کام"), listOf("Harmless fun", "A breach of public trust and wrongdoing", "Normal behavior", "Acceptable"), 1, "مشترکہ املاک سب کا حق ہیں، ان کی حفاظت سب پر لازم ہے۔", "Shared public property belongs to everyone and must be protected."),
                QuizQuestion("d25q4", "اگر کوئی شخص آپ کو راز کی بات بتائے تو امانت کا تقاضا کیا ہے؟", "If someone shares a private matter in confidence, what does trust require?", listOf("دوستوں کو سنانا", "اسے محفوظ رکھنا جب تک کوئی سنگین نقصان نہ ہو", "سٹیٹس پر لگانا", "مذاق بنانا"), listOf("Tell friends", "Keep it confidential unless preventing serious harm", "Post it", "Joke about it"), 1, "مجلس کی بات اور راز امانت ہوتے ہیں۔", "Private confidences are trusts that must not be leaked."),
                QuizQuestion("d25q5", "حدیث میں امانت داری اور عہد کی پابندی کو کس سے جوڑا گیا ہے؟", "In the Hadith, trustworthiness and keeping promises are linked to what?", listOf("شہرت سے", "کامل ایمان اور دین سے", "دولت سے", "سیاست سے"), listOf("Fame", "Completeness of faith and religion", "Wealth", "Politics"), 1, "ایمان اور امانت لازم و ملزوم ہیں۔", "Trustworthiness is inseparable from authentic faith.")
            )
        ),
        CuratedLesson(
            dayNumber = 26,
            weekNumber = 4,
            categoryIds = listOf("community_service", "peace_tolerance"),
            titleUr = "بلا امتیاز انسانیت کی خدمت",
            titleEn = "Serving Humanity Without Discrimination",
            objectivesUr = listOf(
                "سمجھنا کہ رحمت اور خدمتِ خلق مذہب، رنگ یا زبان کی قید سے آزاد ہے۔",
                "بیماروں، مسافروں، معذور افراد اور آفات سے متاثرہ لوگوں کی مدد کرنا۔",
                "نیکی کو سماجی فلاحی منصوبوں کی شکل دینا۔"
            ),
            objectivesEn = listOf(
                "Understand that compassion and humanitarian service cross every religious and social boundary.",
                "Assist the sick, travelers, people with disabilities, and disaster-affected neighbors.",
                "Channel faith into inclusive civic and charitable service."
            ),
            introUr = "مخلوقِ خدا اللہ کا کنبہ ہے؛ جب انسان بغیر کسی تفریق کے کسی ضرورت مند کا سہارا بنتا ہے تو وہ رحمتِ الٰہی کا مظہر ہوتا ہے۔",
            introEn = "All creation is cared for by God; serving people in need without discrimination reflects true mercy.",
            explanationUr = "نبی کریم ﷺ نے ایک پیاسے کتے کو پانی پلانے والے کو بخشش کی بشارت دی، تو سوچیں کہ ایک مصیبت زدہ انسان—چاہے اس کا مذہب، زبان یا ملک کچھ بھی ہو—کی جان بچانے، علاج کرانے یا بھوک مٹانے کا اجر کتنا عظیم ہوگا۔ اسلام ہمیں سکھاتا ہے کہ ہنگامی حالات، سیلاب، بیماری، خون کے عطیے، شجرکاری اور صفائی مہمات میں بغیر کسی امتیاز کے آگے بڑھیں۔ خدمتِ خلق دلوں کی نفرت مٹا کر انسانیت کو یکجا کر دیتی ہے۔",
            explanationEn = "The Prophet ﷺ taught that someone was forgiven simply for giving water to a thirsty dog—how much greater, then, is the reward for feeding a hungry human being, donating blood, comforting the sick, or helping disaster victims regardless of faith, race, or background? Inclusive service—whether planting trees, cleaning streets, supporting disability access, or welcoming strangers—unites humanity in dignity.",
            quranArabic = "وَيُطْعِمُونَ الطَّعَامَ عَلَىٰ حُبِّهِ مِسْكِينًا وَيَتِيمًا وَأَسِيرًا",
            quranTranslationUr = "اور وہ اللہ کی محبت میں مسکین، یتیم اور قیدی کو کھانا کھلاتے ہیں۔",
            quranTranslationEn = "And they give food in spite of love for it to the needy, the orphan, and the captive.",
            quranRefUr = "سورۃ الدہر (الانسان) 76:8",
            quranRefEn = "Surah Al-Insan 76:8",
            hadithTextUr = "ہر جاندار (ترو تازہ جگر رکھنے والے) کے ساتھ احسان کرنے میں اجر و ثواب ہے۔",
            hadithTextEn = "In every living creature there is a reward for showing kindness.",
            hadithRefUr = "صحیح بخاری، حدیث 2363 / صحیح مسلم، حدیث 2244 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 2363 / Sahih Muslim, Hadith 2244 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول یا محلے کی صفائی و شجرکاری مہم میں حصہ لینا اور کسی خصوصی ضرورت والے ہم جماعت کا ساتھ دینا۔",
            teenExampleEn = "Joining a tree-planting or clean-campus drive and befriending a classmate with special needs.",
            youngAdultExampleUr = "خون کا عطیہ دینا، فلاحی ہیلپ لائن یا صاف پانی کے منصوبوں میں رضاکار بننا۔",
            youngAdultExampleEn = "Volunteering for blood drives, flood relief, literacy tutoring, or clean water initiatives.",
            adultExampleUr = "ہسپتال میں کسی انجان مریض کی رہنمائی یا مالی مدد کرنا اور ہر شہری کے ساتھ مساوی شفقت برتنا۔",
            adultExampleEn = "Helping an unfamiliar patient navigate a hospital or supporting community shelters regardless of background.",
            keyLessonsUr = listOf(
                "ہر زندہ مخلوق کے ساتھ رحمدلی میں اجر ہے۔",
                "خدمتِ خلق میں مذہب یا رنگ کی بنیاد پر تفریق نہیں ہونی چاہیے۔",
                "عملی فلاحی کام معاشرتی ہم آہنگی کی مضبوط کڑی ہیں۔"
            ),
            keyLessonsEn = listOf(
                "Kindness to every living creature brings spiritual reward.",
                "Humanitarian service never discriminates by faith, race, or status.",
                "Shared community service unites diverse neighborhoods."
            ),
            practicalActivityUr = "آج کسی پرندے/جانور کے لیے پانی کا پیالہ رکھیں یا کسی قریبی سماجی خدمت (صفائی، پودا لگانا، یا رضاکاری) میں حصہ لیں۔",
            practicalActivityEn = "Place fresh water for birds/animals today, plant a sapling, or take one step to join a local service effort.",
            reflectionPromptUr = "میں اپنے محلے یا شہر میں کون سی چھوٹی فلاحی خدمت شروع کر سکتا ہوں یا اس کا حصہ بن سکتا ہوں؟",
            reflectionPromptEn = "What small local service project in my street or city could I start or join?",
            goodDeedChallengeUr = "آج کسی اجنبی یا مسافر کو مسکرا کر راستہ بتائیں، پانی پیش کریں یا اس کی آسانی کا سبب بنیں۔",
            goodDeedChallengeEn = "Offer cold water, clear directions, or friendly help to a stranger or traveler today.",
            quiz = listOf(
                QuizQuestion("d26q1", "صحیح بخاری کی حدیث کے مطابق کس کے ساتھ احسان کرنے میں اجر ہے؟", "According to Sahih al-Bukhari, showing kindness to whom brings reward?", listOf("صرف اپنے دوستوں کے ساتھ", "ہر جاندار (بشمول انسانوں اور جانوروں) کے ساتھ", "صرف بڑوں کے ساتھ", "صرف رشتہ داروں کے ساتھ"), listOf("Only friends", "Every living creature", "Only elders", "Only relatives"), 1, "رحمت کا دائرہ تمام انسانوں اور جانداروں تک پھیلا ہوا ہے۔", "Compassion extends to all people and living creatures."),
                QuizQuestion("d26q2", "سورۃ الدہر (76:8) میں نیک لوگ کس کس کو کھانا کھلاتے ہیں؟", "Whom do the righteous feed in Surah Al-Insan (76:8)?", listOf("صرف امیر مہمانوں کو", "مسکین، یتیم اور قیدی کو", "صرف اپنے خاندان کو", "صرف ہم خیال لوگوں کو"), listOf("Wealthy guests", "The needy, the orphan, and the captive", "Family only", "Same-group peers"), 1, "اس آیت میں غیر مسلم قیدی کو بھی بلا امتیاز کھانا کھلانے کی تعریف ہے۔", "Even captives of different beliefs were fed with compassion."),
                QuizQuestion("d26q3", "خدمتِ خلق میں کون سا اصول اختیار کرنا چاہیے؟", "What principle should guide community service?", listOf("تفاخر اور سیاست", "بلا امتیاز سب کی مدد اور عاجزی", "صرف اپنے گروپ کی مدد", "تشہیر"), listOf("Pride and politics", "Humility and helping all without discrimination", "Only one's own group", "Self-promotion"), 1, "انسانیت کی خدمت خالصتاً اللہ کی رضا اور بھلائی کے لیے ہوتی ہے۔", "True service seeks Allah's pleasure and universal human good."),
                QuizQuestion("d26q4", "شجرکاری اور ماحولیات کی حفاظت اسلام کی نظر میں کیا ہے؟", "How are tree planting and environmental care viewed in Islam?", listOf("بے کار کام", "صدقہ جاریہ اور زمین کی امانت", "صرف کسانوں کا کام", "وقت کا ضیاع"), listOf("Pointless", "Ongoing charity (Sadaqah Jariyah) and stewardship", "Farmers' job only", "Waste of time"), 1, "جو درخت لگائے اور اس سے انسان یا پرندہ کھائے، وہ صدقہ ہے۔", "Planting trees that shade or feed creation counts as ongoing charity."),
                QuizQuestion("d26q5", "رضاکارانہ خدمت (Volunteering) نوجوانوں میں کیا پیدا کرتی ہے؟", "What does community volunteering cultivate in youth?", listOf("غرور", "ہمدردی، ذمہ داری اور سماجی اتحاد", "سستی", "تھکاوٹ"), listOf("Arrogance", "Empathy, leadership, and social unity", "Laziness", "Bitterness"), 1, "مل کر خدمت کرنے سے نوجوان مثبت شہری بنتے ہیں۔", "Shared service builds compassionate, active citizens.")
            )
        ),
        CuratedLesson(
            dayNumber = 27,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "youth_development", "islamic_character"),
            titleUr = "سوشل میڈیا کا ذمہ دارانہ استعمال",
            titleEn = "Responsible Use of Social Media",
            objectivesUr = listOf(
                "اسکرین اور کی بورڈ پر بھی اللہ کے سامنے جوابدہی کا شعور بیدار کرنا۔",
                "جھوٹی خبروں، تضحیک، بے حیائی اور وقت کے ضیاع سے بچنا۔",
                "سوشل میڈیا کو علم، خیر، حوصلہ افزائی اور تعمیر کے لیے استعمال کرنا۔"
            ),
            objectivesEn = listOf(
                "Remember moral accountability for every post, comment, and share online.",
                "Avoid misinformation, cyberbullying, immodesty, and endless scrolling.",
                "Use digital platforms to share verified knowledge, kindness, and encouragement."
            ),
            introUr = "موبائل اسکرین کے پیچھے بیٹھے ہوئے بھی ہمارے الفاظ، تبصرے اور شیئر کیے گئے کلپس ہمارے نامۂ اعمال میں لکھے جا رہے ہیں۔",
            introEn = "Behind every screen, our posts, comments, and forwards leave real marks on people's hearts and our moral record.",
            explanationUr = "سوشل میڈیا ایک طاقتور آلہ ہے؛ اس سے خیر بھی پھیلایا جا سکتا ہے اور فتنہ بھی۔ قرآن نے ہمیں اصول دیا ہے کہ جب کوئی غیر مصدقہ خبر آئے تو اس کی تحقیق کر لو، مبادا کسی قوم یا فرد کو نادانی میں نقصان پہنچا دو اور پھر پچھتانا پڑے۔ آن لائن گمنامی کی آڑ میں کسی کا مذاق اڑانا (trolling)، کسی کی ذاتی تصویر لیک کرنا، بغیر ثبوت الزام لگانا، یا نفرت پھیلانا اخلاقی جرم ہے۔ اپنا وقت محدود کریں، اچھی اور تعمیری چیزیں شیئر کریں، اور سچ کی تصدیق کا اصول اپنائیں۔",
            explanationEn = "Social media magnifies whatever we feed into it—wisdom or harm. The Quran gives us the golden digital rule: whenever unverified news arrives, investigate and verify before reacting or forwarding, lest you harm innocent people in ignorance and regret it. Online anonymity never excuses cyberbullying, mocking strangers, leaking private photos, or spreading outrage. Set healthy screen limits and let your digital footprint reflect kindness and truth.",
            quranArabic = "يَا أَيُّهَا الَّذِينَ آمَنُوا إِن جَاءَكُمْ فَاسِقٌ بِنَبَإٍ فَتَبَيَّنُوا أَن تُصِيبُوا قَوْمًا بِجَهَالَةٍ",
            quranTranslationUr = "اے ایمان والو! اگر تمہارے پاس کوئی غیر معتبر شخص کوئی خبر لے کر آئے تو اچھی طرح تحقیق کر لیا کرو، مبادا تم نادانی میں کسی قوم کو نقصان پہنچا دو۔",
            quranTranslationEn = "O you who believe, if an untrustworthy person brings you news, verify it carefully, lest you harm a people out of ignorance.",
            quranRefUr = "سورۃ الحجرات 49:6",
            quranRefEn = "Surah Al-Hujurat 49:6",
            hadithTextUr = "انسان جو بھی بات زبان سے نکالتا ہے، اس کے پاس ایک نگران فرشتہ لکھنے کے لیے تیار رہتا ہے۔",
            hadithTextEn = "Not a word does a person utter except that beside them is an observer ready to record it.",
            hadithRefUr = "سورۃ ق 50:18 (قرآنی حوالہ، مستند) اور صحیح بخاری، حدیث 6474 (زبان کی حفاظت)",
            hadithRefEn = "Surah Qaf 50:18 (Quranic reference) & Sahih al-Bukhari, Hadith 6474 (Guarding speech)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "کلاس گروپ یا گیم چیٹ میں کسی کی تضحیک کرنے والے میمز نہ بنانا اور روزانہ سونے سے ایک گھنٹہ پہلے فون بند کر دینا۔",
            teenExampleEn = "Refusing to share embarrassing memes in class chats and turning off screens an hour before bed.",
            youngAdultExampleUr = "کسی وائرل کلپ پر فوراً غصہ بھرے کمنٹ کرنے سے پہلے اصل حقیقت چیک کرنا اور تعمیری مواد بنانا۔",
            youngAdultExampleEn = "Fact-checking viral outrage clips before commenting or sharing, and posting beneficial insights.",
            adultExampleUr = "واٹس ایپ پر بغیر تصدیق کے طبی نسخے، جھوٹی خبریں یا فرقہ وارانہ پیغامات فارورڈ نہ کرنا۔",
            adultExampleEn = "Stopping the spread of unverified WhatsApp rumors, fake remedies, and divisive forwards.",
            keyLessonsUr = listOf(
                "ہر غیر مصدقہ خبر کو شیئر کرنے سے پہلے تحقیق کرنا قرآنی فرض ہے۔",
                "کمنٹ اور میسج بھی بولے ہوئے لفظ کی طرح قابلِ احتساب ہیں۔",
                "ڈیجیٹل دنیا میں بھی حیا، سچائی اور وقار کی حفاظت ضروری ہے۔"
            ),
            keyLessonsEn = listOf(
                "Verifying news before sharing is a direct Quranic duty.",
                "Typed comments carry the same moral weight as spoken words.",
                "Respect, privacy, and honesty apply fully in digital spaces."
            ),
            practicalActivityUr = "آج سوشل میڈیا پر کم از کم ایک مثبت، حوصلہ افزا یا علمی بات شیئر کریں، اور کسی بھی مشکوک پوسٹ کو فارورڈ کرنے سے رک جائیں۔",
            practicalActivityEn = "Share one uplifting or educational insight online today, and pause to fact-check anything sensational.",
            reflectionPromptUr = "اگر میرے پچھلے ایک ماہ کے تمام سوشل میڈیا کمنٹس اور شیئرز دنیا کے سامنے رکھے جائیں تو کیا مجھے ان پر فخر ہوگا؟",
            reflectionPromptEn = "If my last month of comments and shares were read aloud publicly, would I feel proud of them?",
            goodDeedChallengeUr = "آج کسی کے مثبت کام یا تخلیقی کوشش پر اچھا اور حوصلہ بڑھانے والا تبصرہ لکھیں۔",
            goodDeedChallengeEn = "Leave a sincere, encouraging comment on someone's positive work or effort today.",
            quiz = listOf(
                QuizQuestion("d27q1", "سورۃ الحجرات (49:6) سوشل میڈیا کے دور میں ہمیں کون سا اہم اصول دیتی ہے؟", "What vital digital principle does Surah Al-Hujurat (49:6) teach?", listOf("فوراً ہر خبر فارورڈ کر دیں", "کوئی خبر پھیلانے سے پہلے اچھی طرح تحقیق و تصدیق کر لیں", "صرف تصاویر دیکھیں", "کمنٹس بند کر دیں"), listOf("Forward immediately", "Verify news carefully before reacting or sharing", "View photos only", "Disable comments"), 1, "بغیر تحقیق خبر پھیلانا معاشرتی نقصان کا باعث بنتا ہے۔", "Verification protects innocent people from rumor harm."),
                QuizQuestion("d27q2", "آن لائن گمنامی (anonymous account) سے اخلاقی ذمہ داری پر کیا فرق پڑتا ہے؟", "Does an anonymous online account reduce moral accountability?", listOf("جی ہاں، کوئی نہیں دیکھ رہا", "کوئی فرق نہیں پڑتا، اللہ ہر لفظ اور کلک سے باخبر ہے", "صرف بڑوں پر لاگو ہے", "مذاق کی اجازت ہے"), listOf("Yes", "Not at all; Allah records every word and action", "Applies only to adults", "Mocking is allowed"), 1, "انسان کی ذمہ داری اسکرین کے پیچھے بھی ویسی ہی رہتی ہے۔", "Moral accountability remains identical online and offline."),
                QuizQuestion("d27q3", "سائبر بُلینگ (Cyberbullying) سے کیا مراد ہے؟", "What is cyberbullying?", listOf("آن لائن تعلیم دینا", "انٹرنیٹ پر کسی کا مذاق اڑانا، دھمکانا یا ذلیل کرنا", "صفائی مہم", "کتب کا مطالعہ"), listOf("Online teaching", "Mocking, harassing, or shaming someone digitally", "Cleanup drive", "Reading books"), 1, "ڈیجیٹل ایذا رسانی بھی زبان و ہاتھ کے ظلم کی ایک شکل ہے۔", "Digital harassment is a harmful form of cruelty."),
                QuizQuestion("d27q4", "سوشل میڈیا کے مثبت استعمال کی مثال کیا ہے؟", "What is a positive use of social media?", listOf("جھوٹی افواہ پھیلانا", "علم، ہنر، نیکی اور تعمیری پیغامات عام کرنا", "دوسروں کا وقت ضائع کرنا", "ذاتی تصویریں چرانا"), listOf("Spreading rumors", "Sharing verified knowledge, skills, and encouragement", "Wasting time", "Stealing photos"), 1, "ٹیکنالوجی کا اچھا استعمال صدقہ جاریہ بن سکتا ہے۔", "Beneficial digital content can be ongoing charity."),
                QuizQuestion("d27q5", "زیادہ اسکرین ٹائم کا ذہن اور خاندان پر کیا اثر ہوتا ہے؟", "How does excessive mindless scrolling affect mind and family?", listOf("توجہ بڑھتی ہے", "وقت ضائع ہوتا ہے اور گھر والوں سے دوری بڑھتی ہے", "نیند بہتر ہوتی ہے", "صبر بڑھتا ہے"), listOf("Focus improves", "It wastes time and distances us from family", "Sleep improves", "Patience rises"), 1, "فون کے استعمال میں توازن صحت اور رشتوں کو بچاتا ہے۔", "Balanced screen habits protect sleep, focus, and family warmth.")
            )
        ),
        CuratedLesson(
            dayNumber = 28,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "community_service"),
            titleUr = "معاشرے کا ایک مثبت رکن بننا",
            titleEn = "Becoming a Positive Member of Society",
            objectivesUr = listOf(
                "شکایت کرنے والے شہری کے بجائے حل دینے والا ذمہ دار شہری بننا۔",
                "قانون کی پاسداری، ٹریفک نظم و ضبط، صفائی اور ماحولیات کا خیال رکھنا۔",
                "اچھائی کا حکم اور برائی سے حکمت و نرمی کے ساتھ روکنے کا کردار ادا کرنا۔"
            ),
            objectivesEn = listOf(
                "Shift from passive complaining to constructive, solution-minded citizenship.",
                "Respect civic order: traffic rules, cleanliness, queues, and environment.",
                "Encourage good and discourage harm with wisdom and gentle example."
            ),
            introUr = "معاشرہ صرف تب بدلتا ہے جب ہم خود وہ مثبت تبدیلی بن جائیں جس کا ہم دوسروں سے انتظار کرتے ہیں۔",
            introEn = "Society transforms when we become the very integrity, courtesy, and care we wish to see around us.",
            explanationUr = "ہم اکثر نظام، ٹریفک، گندگی اور معاشرتی بگاڑ پر گھنٹوں تنقید کرتے ہیں، مگر خود سگنل توڑنے، سڑک پر ریپر پھینکنے یا باری توڑنے میں ہچکچاتے نہیں۔ قرآن کریم اس امت کی پہچان یہ بتاتا ہے کہ یہ لوگ بھلائی کا حکم دیتے ہیں اور برائی سے روکتے ہیں۔ اچھا شہری وہ ہے جو کسی کے نہ دیکھنے پر بھی ٹریفک قانون کا احترام کرے، صفائی کو نصف ایمان سمجھ کر عمل کرے، درخت لگائے، ٹیکس اور بل ایمانداری سے ادا کرے، اور اپنے محلے کو رہنے کے لیے بہتر جگہ بنائے۔",
            explanationEn = "It is easy to spend hours criticizing traffic chaos, litter, and declining standards while ignoring a red light or tossing a wrapper ourselves. The Quran describes a healthy community as one that encourages goodness and turns away from harm. Positive citizenship means obeying civic laws even when no officer is watching, keeping streets clean because cleanliness is part of faith, conserving water, honoring queues, and leading small improvements in your neighborhood.",
            quranArabic = "كُنتُمْ خَيْرَ أُمَّةٍ أُخْرِجَتْ لِلنَّاسِ تَأْمُرُونَ بِالْمَعْرُوفِ وَتَنْهَوْنَ عَنِ الْمُنكَرِ",
            quranTranslationUr = "تم بہترین امت ہو جسے لوگوں کی بھلائی کے لیے نکالا گیا ہے؛ تم نیکی کا حکم دیتے ہو اور برائی سے روکتے ہو۔",
            quranTranslationEn = "You are the best community brought forth for mankind: you enjoin what is right and forbid what is wrong.",
            quranRefUr = "سورۃ آل عمران 3:110",
            quranRefEn = "Surah Ali 'Imran 3:110",
            hadithTextUr = "صفائی نصف ایمان ہے۔",
            hadithTextEn = "Cleanliness is half of faith.",
            hadithRefUr = "صحیح مسلم، حدیث 223 (مستند)",
            hadithRefEn = "Sahih Muslim, Hadith 223 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "کچرا ہمیشہ کوڑے دان میں ڈالنا اور اسکول کی دیواروں یا بینچوں کو صاف ستھرا رکھنا۔",
            teenExampleEn = "Always putting litter in bins and keeping school walls, desks, and playgrounds clean.",
            youngAdultExampleUr = "موٹر سائیکل یا گاڑی چلاتے ہوئے ہیلمٹ، سیٹ بیلٹ اور ٹریفک اشاروں کی مکمل پابندی کرنا۔",
            youngAdultExampleEn = "Wearing a helmet or seatbelt, obeying speed limits, and respecting pedestrian crossings.",
            adultExampleUr = "محلے کی کمیٹی، اسکول والدین میٹنگ یا فلاحی سرگرمی میں تعمیری تجاویز اور وقت دینا۔",
            adultExampleEn = "Contributing constructive time to neighborhood committees, school boards, or local safety efforts.",
            keyLessonsUr = listOf(
                "بھلائی کی علامت دوسروں کے لیے نفع اور اصلاح کا ذریعہ بننا ہے۔",
                "صفائی، نظم و ضبط اور قانون کی پابندی ایمان و اخلاق کا حصہ ہیں۔",
                "شکایت کم اور عملی مثال زیادہ بن کر معاشرہ سنوارا جاتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "A noble community exists to bring goodness to all humanity.",
                "Cleanliness and civic discipline reflect living faith.",
                "Leading by quiet personal example accomplishes more than endless complaints."
            ),
            practicalActivityUr = "آج ٹریفک، صفائی، قطار اور وقت کی پابندی میں مکمل احتیاط برتیں اور اپنی جیب یا بیگ میں کچرا کوڑے دان تک سنبھال کر رکھیں۔",
            practicalActivityEn = "Practice strict civic discipline today: obey every traffic/queue rule and hold any wrapper until you reach a bin.",
            reflectionPromptUr = "وہ کون سی ایک شہری عادت ہے جسے میں اپنا کر اپنے محلے یا شہر کے لیے اچھی مثال بن سکتا ہوں؟",
            reflectionPromptEn = "Which single civic habit can I adopt permanently to set a positive example in my community?",
            goodDeedChallengeUr = "آج کسی عوامی مقام سے ایک دو فالتو کاغذ یا پلاسٹک کی بوتل اٹھا کر کوڑے دان میں ڈالیں۔",
            goodDeedChallengeEn = "Pick up a stray piece of litter from a shared walkway today and place it in a bin.",
            quiz = listOf(
                QuizQuestion("d28q1", "سورۃ آل عمران (3:110) کے مطابق بہترین امت کو کس مقصد کے لیے نکالا گیا؟", "For whom was the best community brought forth according to Surah Ali 'Imran (3:110)?", listOf("صرف اپنے فائدے کے لیے", "لوگوں (انسانیت) کی بھلائی، نیکی کے فروغ اور برائی کی روک تھام کے لیے", "تکبر کرنے کے لیے", "الگ رہنے کے لیے"), listOf("Only for self-interest", "For the good of humanity, enjoining right and forbidding wrong", "To boast", "To stay isolated"), 1, "امت کا مشن پوری انسانیت کو خیر پہنچانا ہے۔", "The mission is bringing goodness to all people."),
                QuizQuestion("d28q2", "صحیح مسلم میں صفائی کو کیا قرار دیا گیا ہے؟", "How is cleanliness described in Sahih Muslim?", listOf("معمولی شوق", "نصف ایمان", "صرف تہوار کا کام", "اختیاری بات"), listOf("A hobby", "Half of faith", "Festival-only duty", "Optional"), 1, "جسمانی اور ماحولیاتی صفائی ایمان کا لازمی حصہ ہے۔", "Both personal and environmental cleanliness are half of faith."),
                QuizQuestion("d28q3", "ٹریفک قوانین اور قطار کا احترام کیوں ضروری ہے؟", "Why are traffic laws and queue discipline important?", listOf("صرف چالان سے بچنے کے لیے", "دوسروں کی جان، وقت اور حق کے تحفظ کے لیے", "وقتی دکھاوے کے لیے", "ضروری نہیں"), listOf("Only to avoid fines", "To protect everyone's life, time, and fairness", "For show", "Not important"), 1, "شہری قوانین کی پابندی دوسروں کو تکلیف سے بچاتی ہے۔", "Civic rules protect life and uphold fairness."),
                QuizQuestion("d28q4", "مثبت شہری بننے کی پہلی شرط کیا ہے؟", "What is the first step to becoming a positive citizen?", listOf("صرف حکومت کو برا کہنا", "خود ان اصولوں پر عمل شروع کرنا جو ہم دوسروں سے چاہتے ہیں", "ملک چھوڑ دینا", "بحث کرتے رہنا"), listOf("Only blaming leaders", "Practicing the integrity we wish to see in others", "Leaving", "Arguing endlessly"), 1, "تبدیلی اپنے قدموں سے شروع ہوتی ہے۔", "Reform begins with our own daily conduct."),
                QuizQuestion("d28q5", "نیکی کا حکم دینے اور برائی سے روکنے کا درست انداز کیا ہے؟", "What is the right manner for encouraging good?", listOf("سختی اور بے عزتی سے", "حکمت، نرمی اور اپنے اچھے عمل سے", "طنز کر کے", "زبردستی سے"), listOf("Harshly", "With wisdom, gentleness, and personal example", "Sarcasm", "Force"), 1, "نرم نصیحت اور ذاتی مثال دلوں کو قائل کرتی ہے۔", "Gentle wisdom and personal example inspire lasting change.")
            )
        ),
        CuratedLesson(
            dayNumber = 29,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "self_improvement"),
            titleUr = "معاشرتی اصلاح کے لیے میرا ذاتی عہد",
            titleEn = "My Personal Commitment to Social Reform",
            objectivesUr = listOf(
                "30 دن کے سفر سے حاصل شدہ اصولوں کو ایک ذاتی 'منشورِ زندگی' میں ڈھالنا۔",
                "گھر، تعلیم/کام اور معاشرے کے لیے تین واضح طویل مدتی عہد تحریر کرنا۔",
                "نیکی کے تسلسل کے لیے دعا، صحبتِ صالح اور خود احتسابی کو ساتھ رکھنا۔"
            ),
            objectivesEn = listOf(
                "Distill the 30-day program into a personal Charter of Goodness.",
                "Write three concrete long-term commitments for self, family, and community.",
                "Maintain consistency through prayer, good company, and periodic self-review."
            ),
            introUr = "علم اس وقت تک مکمل نہیں ہوتا جب تک انسان اسے اپنے مستقبل کا واضح عہد اور لائحہ عمل نہ بنا لے۔",
            introEn = "Learning matures when transformed into a clear, written personal commitment for the months ahead.",
            explanationUr = "کل اس پروگرام کا تیسواں اور آخری دن ہے، لہٰذا آج ٹھہر کر اپنا ذاتی عہد نامہ تیار کرنے کا دن ہے۔ اصلاحِ معاشرہ کسی ایک دن کے جذبے سے نہیں بلکہ ان چھوٹے چھوٹے عہدوں سے ہوتی ہے جنہیں ہم سال بھر نبھاتے ہیں۔ چاہے وہ سچ بولنے کا عہد ہو، والدین و اہلِ خانہ کو وقت دینے کا عہد ہو، رشوت و غیبت سے دور رہنے کا عہد ہو، یا ہر ہفتے کسی ایک ضرورت مند کی مدد کرنے کا عہد—اپنے عہد تحریر کریں اور اللہ سے استقامت کی دعا مانگیں۔",
            explanationEn = "Tomorrow marks Day 30 and the final assessment of this cycle, making today the ideal moment to craft your personal commitment. Real social reform does not come from brief emotional speeches—it comes from quiet promises kept month after month: speaking truth, giving parents and family gentle care, rejecting gossip and bribery, and serving neighbors without bias. Put your commitments in writing and ask Allah for steadfastness.",
            quranArabic = "إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ",
            quranTranslationUr = "بے شک اللہ کسی قوم کی حالت نہیں بدلتا جب تک وہ خود اپنی حالت (اور عادات) کو نہ بدلیں۔",
            quranTranslationEn = "Indeed, Allah will not change the condition of a people until they change what is in themselves.",
            quranRefUr = "سورۃ الرعد 13:11",
            quranRefEn = "Surah Ar-Ra'd 13:11",
            hadithTextUr = "مومن وہ ہے جس سے لوگ اپنے جان و مال کے بارے میں مامون (مطمئن) رہیں۔",
            hadithTextEn = "The believer is one whom people trust with their lives and their property.",
            hadithRefUr = "جامع ترمذی، حدیث 2627 / سنن نسائی، حدیث 4995 (مستند)",
            hadithRefEn = "Jami' at-Tirmidhi, Hadith 2627 / Sunan an-Nasa'i, Hadith 4995 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اپنے کمرے یا ڈائری میں 3 سنہری عہد لکھنا: روزانہ سچ، والدین کا ادب، اور محفوظ سوشل میڈیا۔",
            teenExampleEn = "Writing three simple pledges in your notebook: daily honesty, honoring parents, and kind digital habits.",
            youngAdultExampleUr = "دوستوں کا ایک چھوٹا مثبت حلقہ بنانا جو مطالعے، اخلاق اور خدمتِ خلق میں ایک دوسرے کی حوصلہ افزائی کرے۔",
            youngAdultExampleEn = "Building a circle of supportive peers who encourage integrity, study, and community service.",
            adultExampleUr = "اپنے گھر کا ماہانہ خیر و فلاح کا بجٹ اور خاندانی اخلاقی ماحول برقرار رکھنے کا عہد لکھنا۔",
            adultExampleEn = "Establishing a monthly family charity habit and a calm, consultative culture at home.",
            keyLessonsUr = listOf(
                "قومی و معاشرتی تبدیلی انفرادی تبدیلی سے مشروط ہے۔",
                "اصل مومن وہ ہے جس سے لوگوں کی جان اور مال محفوظ ہوں۔",
                "تحریری عہد اور اچھی صحبت استقامت میں مدد دیتے ہیں۔"
            ),
            keyLessonsEn = listOf(
                "Collective transformation begins with inner personal change.",
                "A believer is someone people can fully trust with life and property.",
                "Written commitments and good companions keep resolve alive."
            ),
            practicalActivityUr = "آج نیچے دیے گئے ریفلیکشن باکس میں اپنے تین تحریری عہد درج کریں: (1) اپنی ذات کے لیے، (2) خاندان کے لیے، (3) معاشرے کے لیے۔",
            practicalActivityEn = "Write three clear pledges in today's reflection box: (1) for yourself, (2) for your family, and (3) for your community.",
            reflectionPromptUr = "پیغامِ خیر کے 30 دنوں کے بعد میرا ذاتی عہدِ اصلاح کیا ہے؟",
            reflectionPromptEn = "After 29 days of Paigham-e-Khair, what is my written personal commitment?",
            goodDeedChallengeUr = "آج اپنے عہد کی شروعات کسی قریبی شخص کے ساتھ غیر متوقع مہربانی کر کے کریں۔",
            goodDeedChallengeEn = "Launch your commitment today with an unexpected act of kindness toward someone near you.",
            quiz = listOf(
                QuizQuestion("d29q1", "سورۃ الرعد (13:11) کے مطابق کسی قوم کی حالت کب بدلتی ہے؟", "According to Surah Ar-Ra'd (13:11), when does Allah change a people's condition?", listOf("جب وہ صرف انتظار کریں", "جب وہ خود اپنے اندر تبدیلی اور اصلاح لائیں", "جب موسم بدلے", "جب دوسرے بدل جائیں"), listOf("When they just wait", "When they change what is within themselves", "When seasons change", "When outsiders change"), 1, "معاشرتی انقلاب کی شرط ہر فرد کی اپنی اصلاح ہے۔", "Social renewal starts with inner personal change."),
                QuizQuestion("d29q2", "حدیث میں مومن کی کیا پہچان بیان ہوئی ہے؟", "How does the Hadith define a true believer?", listOf("جس سے لوگ ڈریں", "جس سے لوگ اپنے جان و مال کے بارے میں مطمئن و محفوظ ہوں", "جو صرف باتیں کرے", "جو تنہا رہے"), listOf("Someone people fear", "Someone people trust with their lives and wealth", "Someone who only talks", "Someone isolated"), 1, "قابلِ اعتماد ہونا ایمان کا جوہر ہے۔", "Being completely trustworthy with lives and property defines faith."),
                QuizQuestion("d29q3", "اچھے عہد پر قائم رہنے میں سب سے زیادہ مددگار کیا چیز ہے؟", "What helps most in staying steady on good commitments?", listOf("تکبر", "اچھی صحبت، دعا اور باقاعدہ جائزہ", "لوگوں سے چھپنا", "سستی"), listOf("Pride", "Good company, prayer, and regular self-review", "Hiding", "Laziness"), 1, "صالح دوست اور دعا استقامت عطا کرتے ہیں۔", "Good companions and prayer keep resolve strong."),
                QuizQuestion("d29q4", "ذاتی عہد کن تین دائروں پر مشتمل ہونا چاہیے؟", "Which three circles should a balanced commitment cover?", listOf("صرف کھیل", "ذات، خاندان اور معاشرہ", "صرف پیسہ", "صرف سفر"), listOf("Sports only", "Self, family, and society", "Money only", "Travel only"), 1, "یہی تینوں دائرے پیغامِ خیر کا بنیادی مشن ہیں۔", "Self, family, and society form the core mission of Paigham-e-Khair."),
                QuizQuestion("d29q5", "عمل میں استقامت کے لیے کیسا ہدف بہتر ہے؟", "What kind of goal supports lifelong consistency?", listOf("ناممکن بڑا ہدف", "واضح، قابلِ عمل اور مستقل عادت", "بے ترتیب کام", "صرف ایک دن کا جوش"), listOf("An impossible goal", "Clear, practical, and sustainable daily/weekly habits", "Random bursts", "One-day excitement"), 1, "مستقل معمولی عادتیں ہی عظیم نتائج لاتی ہیں۔", "Sustainable habits produce lasting transformation.")
            )
        ),
        CuratedLesson(
            dayNumber = 30,
            weekNumber = 4,
            categoryIds = listOf("social_reform", "quizzes_assessments", "my_progress"),
            titleUr = "حتمی جائزہ اور تکمیل کا سرٹیفکیٹ",
            titleEn = "Final Assessment and Certificate of Completion",
            objectivesUr = listOf(
                "30 روزہ مکمل نصاب (اصلاحِ نفس، خاندان، اتحاد، اور معاشرتی تعمیر) کا جامع امتحان مکمل کرنا۔",
                "یہ سمجھنا کہ تکمیل سرٹیفکیٹ سیکھنے کے سفر کی سند ہے، کوئی مذہبی فتویٰ یا پیشہ ورانہ سند نہیں۔",
                "روزانہ نیکی اور سیکھے ہوئے اخلاق کو پوری زندگی جاری رکھنے کا عزم کرنا۔"
            ),
            objectivesEn = listOf(
                "Complete the comprehensive assessment across all four weeks of the 30-day curriculum.",
                "Understand that the completion certificate honors personal study—not religious authority or professional licensing.",
                "Carry forward daily good deeds and ethical leadership as a lifelong journey."
            ),
            introUr = "مبارک ہو! آپ پیغامِ خیر کے 30 روزہ تربیتی سفر کی آخری منزل پر پہنچ چکے ہیں۔ اب یہ علم آپ کی زندگی کا چراغ بننے کے لیے تیار ہے۔",
            introEn = "Congratulations on reaching Day 30 of Paigham-e-Khair! Today celebrates completing the structured course and beginning a lifelong practice.",
            explanationUr = "اس 30 روزہ سفر میں آپ نے چار اہم مراحل طے کیے: پہلے ہفتے میں اصلاحِ نفس (نیت، محاسبہ، سچائی، غیبت سے بچاؤ، غصے پر قابو، صبر)، دوسرے ہفتے میں خاندانی اور سماجی ذمہ داریاں (والدین، میاں بیوی، اولاد، صلہ رحمی، پڑوسی، انسانوں کا احترام)، تیسرے ہفتے میں اتحاد و امن (اخوت، اختلافِ رائے کا ادب، انتہا پسندی سے بچاؤ، معافی، تشدد کا انکار، پرامن حل)، اور چوتھے ہفتے میں بہتر معاشرے کی تعمیر (رشوت سے انکار، یتیموں کی مدد، عدل، امانت، خدمتِ خلق، ذمہ دار سوشل میڈیا)۔ جب آپ تمام 30 دن مکمل کر لیں تو 'میری پیش رفت' میں آپ کا تکمیل سرٹیفکیٹ کھل جائے گا۔ یاد رہے کہ یہ سرٹیفکیٹ صرف کورس مکمل کرنے کی حوصلہ افزائی ہے، کسی دینی منصب یا فتویٰ دینے کی سند نہیں۔",
            explanationEn = "Over 30 days, you journeyed through four pillars: (1) Self Improvement, (2) Family and Social Responsibilities, (3) Unity, Peace, and Brotherhood, and (4) Building a Better Society. Completing all 30 lessons unlocks your Course Completion Certificate in 'My Progress'. Please note clearly: this certificate recognizes completion of an educational self-development course, not religious authority or formal scholarly qualification. Keep learning, keep serving, and stay humble.",
            quranArabic = "إِنَّ أَحْسَنَ الْحَدِيثِ كِتَابُ اللَّهِ ... وَافْعَلُوا الْخَيْرَ لَعَلَّكُمْ تُفْلِحُونَ",
            quranTranslationUr = "اور بھلائی کے کام کرتے رہو تاکہ تم کامیاب ہو جاؤ۔",
            quranTranslationEn = "And do good that you may succeed.",
            quranRefUr = "سورۃ الحج 22:77",
            quranRefEn = "Surah Al-Hajj 22:77",
            hadithTextUr = "خیر کی رہنمائی کرنے والا شخص اس نیکی کے کرنے والے کی طرح اجر پاتا ہے۔",
            hadithTextEn = "The one who guides to something good has a reward similar to the one who does it.",
            hadithRefUr = "صحیح مسلم، حدیث 1893 (مستند)",
            hadithRefEn = "Sahih Muslim, Hadith 1893 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اپنے والدین کو 30 روزہ کورس مکمل کرنے کی خوشخبری سنانا اور روزانہ نیکی کی عادت جاری رکھنا۔",
            teenExampleEn = "Sharing your 30-day completion milestone with your parents and continuing your daily good deed streak.",
            youngAdultExampleUr = "اس تعمیری پیغام کو دوستوں تک شائستگی سے پہنچانا اور رضاکارانہ سرگرمی جاری رکھنا۔",
            youngAdultExampleEn = "Encouraging friends toward positive character growth and continuing community service.",
            adultExampleUr = "اپنے خاندان کے ساتھ اس کورس کی اہم باتوں کا مذاکرہ جاری رکھنا اور عملی نمونہ بنے رہنا۔",
            adultExampleEn = "Keeping weekly family discussions alive around these values and modeling them every day.",
            keyLessonsUr = listOf(
                "نیکی کرتے رہنا دنیا اور آخرت کی حقیقی کامیابی ہے۔",
                "بھلائی کی طرف رہنمائی کرنے والا بھی عمل کرنے والے جتنا اجر پاتا ہے۔",
                "30 دن کا اختتام اصل عمل کی شروعات ہے۔"
            ),
            keyLessonsEn = listOf(
                "Consistent doing of good leads to lasting success.",
                "Guiding others toward goodness multiplies your own reward.",
                "Day 30 is not the end—it is the launchpad for lifelong character."
            ),
            practicalActivityUr = "آج کا حتمی کوئز مکمل کریں، اس سبق کو مکمل نشان زد کریں، اور 'میری پیش رفت' سیکشن میں جا کر اپنا تکمیل سرٹیفکیٹ دیکھیں۔",
            practicalActivityEn = "Complete today's final quiz, mark Day 30 complete, and open 'My Progress' to view your completion certificate.",
            reflectionPromptUr = "30 دن پہلے کے مقابلے میں آج میں خود کو، اپنے خاندان کو اور معاشرے کو کس نئی نظر سے دیکھتا ہوں؟",
            reflectionPromptEn = "Compared to 30 days ago, how differently do I view myself, my family, and my community today?",
            goodDeedChallengeUr = "آج 30ویں دن پر کسی کے ساتھ کوئی خاص نیکی کریں اور پیغامِ خیر کے مشن پر قائم رہنے کی دعا کریں۔",
            goodDeedChallengeEn = "Celebrate Day 30 by performing a heartfelt good deed for someone and praying for steadfastness.",
            quiz = listOf(
                QuizQuestion("d30q1", "سورۃ الحج (22:77) میں کامیابی کا راستہ کیا بتایا گیا ہے؟", "What path to success is stated in Surah Al-Hajj (22:77)?", listOf("صرف آرام کرنا", "بھلائی کے کام کرتے رہنا (وافعلوا الخیر)", "دوسروں پر تنقید", "مال جمع کرنا"), listOf("Resting only", "Doing good consistently", "Criticizing others", "Hoarding wealth"), 1, "مسلسل خیر اور نیکی انسان کو فلاح عطا کرتی ہے۔", "Consistent goodness leads to true flourishing."),
                QuizQuestion("d30q2", "صحیح مسلم کے مطابق بھلائی کی طرف رہنمائی کرنے والے کو کیا ملتا ہے؟", "What does the guide to good receive according to Sahih Muslim?", listOf("کچھ نہیں", "عمل کرنے والے کے برابر اجر", "کم اجر", "صرف شہرت"), listOf("Nothing", "A reward similar to the one who performs it", "Less reward", "Only fame"), 1, "اچھی بات اور نیکی سکھانا صدقہ جاریہ کی طرح اجر بڑھاتا ہے۔", "Inspiring others toward goodness multiplies reward."),
                QuizQuestion("d30q3", "پیغامِ خیر کا بنیادی نعرہ (Tagline) کیا ہے؟", "What is the core mission tagline of Paigham-e-Khair?", listOf("خود کو بدلیں، اپنے خاندان کو سنواریں، اور ایک بہتر معاشرہ تعمیر کریں", "صرف امتحان پاس کریں", "صرف اکیلے رہیں", "صرف بحث کریں"), listOf("Transform yourself, improve your family, build a better society", "Pass exams only", "Live alone", "Debate endlessly"), 0, "تینوں دائروں—فرد، خاندان اور معاشرہ—کی ہم آہنگ تعمیر ہمارا مقصد ہے۔", "Self, family, and society grow together in harmony."),
                QuizQuestion("d30q4", "اس پروگرام کا سرٹیفکیٹ کس چیز کی نمائندگی کرتا ہے؟", "What does the completion certificate represent?", listOf("مفتی یا عالم ہونے کی سند", "30 روزہ تعلیمی و اخلاقی کورس مکمل کرنے کی حوصلہ افزا سند", "سرکاری لائسنس", "عدالتی اختیار"), listOf("Religious or Mufti authority", "Completion of the 30-day educational self-development course", "Government license", "Judicial power"), 1, "یہ صرف کورس کی تکمیل کا اعزاز ہے، کسی دینی عہدے یا پیشہ ورانہ اہلیت کا دعویٰ نہیں۔", "It recognizes course completion only, never religious authority or professional qualification."),
                QuizQuestion("d30q5", "تیسویں دن کے بعد بہترین طرزِ عمل کیا ہے؟", "What is the best step after completing Day 30?", listOf("سب نیکی چھوڑ دینا", "روزانہ نیکی، سچائی، صبر اور خدمتِ خلق کو زندگی بھر جاری رکھنا", "دوسروں کو کم تر سمجھنا", "خود کو مکمل سمجھ لینا"), listOf("Stop practicing", "Continue daily good deeds, honesty, patience, and service for life", "Look down on others", "Assume perfection"), 1, "اخلاق و اصلاح کی مشق سانس کے آخری دم تک جاری رہتی ہے۔", "Character growth is a lifelong journey of humility and service.")
            )
        )
    )
}

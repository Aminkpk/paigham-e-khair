package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties

enum class AgeGroup(
    val code: String,
    val labelUr: String,
    val labelEn: String,
    val rangeUr: String,
    val rangeEn: String,
    val descriptionUr: String,
    val descriptionEn: String
) {
    TEEN(
        code = "TEEN",
        labelUr = "نوجوان (13 تا 17 سال)",
        labelEn = "Teenagers (13–17)",
        rangeUr = "13–17 سال",
        rangeEn = "Ages 13–17",
        descriptionUr = "اسکول، دوستی، والدین کے ادب اور محفوظ ڈیجیٹل زندگی کی تربیت (اضافی حفاظتی فیچرز کے ساتھ)۔",
        descriptionEn = "School life, friendships, respecting parents, and safe digital habits with extra safety protections."
    ),
    YOUNG_ADULT(
        code = "YOUNG_ADULT",
        labelUr = "نوجوان بالغ (18 تا 25 سال)",
        labelEn = "Young Adults (18–25)",
        rangeUr = "18–25 سال",
        rangeEn = "Ages 18–25",
        descriptionUr = "تعلیم، پیشہ ورانہ امانت، کردار سازی، ازدواجی تیاری اور سماجی ذمہ داری۔",
        descriptionEn = "Higher education, career integrity, character growth, marriage readiness, and civic leadership."
    ),
    ADULT(
        code = "ADULT",
        labelUr = "بالغ افراد (26 سال اور زائد)",
        labelEn = "Adults (26+)",
        rangeUr = "26+ سال",
        rangeEn = "Ages 26+",
        descriptionUr = "خاندانی ہم آہنگی، بچوں کی تربیت، دیانت داری، پڑوسیوں کے حقوق اور معاشرتی اصلاح۔",
        descriptionEn = "Family harmony, raising children, workplace honesty, neighborhood care, and social reform."
    );

    companion object {
        fun fromCode(code: String): AgeGroup = entries.firstOrNull { it.code == code } ?: ADULT
    }
}

enum class AppLanguage(val code: String) {
    URDU("ur"),
    ENGLISH("en");

    val isUrdu: Boolean get() = this == URDU

    companion object {
        fun fromCode(code: String): AppLanguage = if (code == "en") ENGLISH else URDU
    }
}

enum class DashboardSectionId {
    TODAYS_LESSON,
    SELF_IMPROVEMENT,
    ISLAMIC_CHARACTER,
    YOUTH_DEVELOPMENT,
    FAMILY_LIFE,
    UNITY_BROTHERHOOD,
    PEACE_TOLERANCE,
    SOCIAL_REFORM,
    COMMUNITY_SERVICE,
    DAILY_GOOD_DEED,
    QUIZZES_ASSESSMENTS,
    MY_PROGRESS,
    SAVED_LESSONS,
    ABOUT_GUIDANCE
}

data class DashboardSectionItem(
    val id: DashboardSectionId,
    val titleUr: String,
    val titleEn: String,
    val subtitleUr: String,
    val subtitleEn: String,
    val categoryFilter: String? = null
)

@IgnoreExtraProperties
data class FirestoreUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val ageGroup: String = AgeGroup.ADULT.code,
    val language: String = AppLanguage.URDU.code,
    val onboardingCompleted: Boolean = false,
    val dailyReminderEnabled: Boolean = true,
    val teenSafeMode: Boolean = false,
    val blockedUserIds: List<String> = emptyList(),
    val completedDaysCount: Long = 0L,
    val totalGoodDeedsCount: Long = 0L,
    val currentStreak: Long = 0L,
    val lastActivityDate: String = "",
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
) {
    val ageGroupEnum: AgeGroup get() = AgeGroup.fromCode(ageGroup)
    val languageEnum: AppLanguage get() = AppLanguage.fromCode(language)
}

@IgnoreExtraProperties
data class LessonProgress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val lessonDay: Long = 1L,
    val completed: Boolean = false,
    val bookmarked: Boolean = false,
    val activityCompleted: Boolean = false,
    val reflectionText: String = "",
    val bestQuizScore: Long = 0L,
    val quizAttempts: Long = 0L,
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GoodDeedLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val deedKey: String = "",
    val titleUrdu: String = "",
    val titleEnglish: String = "",
    val category: String = "",
    val note: String = "",
    val dateKey: String = "",
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AdminLesson(
    @DocumentId val id: String = "",
    val dayNumber: Long = 1L,
    val weekNumber: Long = 1L,
    val categoryId: String = "self_improvement",
    val titleUrdu: String = "",
    val titleEnglish: String = "",
    val summaryUrdu: String = "",
    val explanationUrdu: String = "",
    val explanationEnglish: String = "",
    val quranRef: String = "",
    val quranArabic: String = "",
    val quranTranslationUrdu: String = "",
    val hadithRef: String = "",
    val hadithTextUrdu: String = "",
    val verificationStatus: String = "VERIFIED",
    val practicalActivityUrdu: String = "",
    val goodDeedChallengeUrdu: String = "",
    val audioUrl: String = "",
    val videoUrl: String = "",
    val published: Boolean = true,
    val updatedBy: String = "",
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Announcement(
    @DocumentId val id: String = "",
    val titleUrdu: String = "",
    val titleEnglish: String = "",
    val bodyUrdu: String = "",
    val bodyEnglish: String = "",
    val active: Boolean = true,
    val authorUid: String = "",
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CustomGoodDeed(
    @DocumentId val id: String = "",
    val titleUrdu: String = "",
    val titleEnglish: String = "",
    val category: String = "",
    val active: Boolean = true,
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommunityPost(
    @DocumentId val id: String = "",
    val authorUid: String = "",
    val authorDisplayName: String = "",
    val authorAgeGroup: String = AgeGroup.ADULT.code,
    val topic: String = "POSITIVE_DISCUSSION",
    val content: String = "",
    val status: String = "APPROVED",
    val helpfulCount: Long = 0L,
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ContentReport(
    @DocumentId val id: String = "",
    val reporterUid: String = "",
    val targetType: String = "COMMUNITY_POST",
    val targetId: String = "",
    val reason: String = "",
    val status: String = "OPEN",
    val adminNote: String = "",
    @com.google.firebase.firestore.ServerTimestamp val createdAt: Timestamp? = null,
    @com.google.firebase.firestore.ServerTimestamp val updatedAt: Timestamp? = null
)

data class QuizQuestion(
    val id: String,
    val questionUr: String,
    val questionEn: String,
    val optionsUr: List<String>,
    val optionsEn: List<String>,
    val correctIndex: Int,
    val explanationUr: String,
    val explanationEn: String
)

data class CuratedLesson(
    val dayNumber: Int,
    val weekNumber: Int,
    val categoryIds: List<String>,
    val titleUr: String,
    val titleEn: String,
    val objectivesUr: List<String>,
    val objectivesEn: List<String>,
    val introUr: String,
    val introEn: String,
    val explanationUr: String,
    val explanationEn: String,
    val quranArabic: String,
    val quranTranslationUr: String,
    val quranTranslationEn: String,
    val quranRefUr: String,
    val quranRefEn: String,
    val hadithTextUr: String,
    val hadithTextEn: String,
    val hadithRefUr: String,
    val hadithRefEn: String,
    val verificationStatus: String = "VERIFIED",
    val teenExampleUr: String,
    val teenExampleEn: String,
    val youngAdultExampleUr: String,
    val youngAdultExampleEn: String,
    val adultExampleUr: String,
    val adultExampleEn: String,
    val keyLessonsUr: List<String>,
    val keyLessonsEn: List<String>,
    val practicalActivityUr: String,
    val practicalActivityEn: String,
    val reflectionPromptUr: String,
    val reflectionPromptEn: String,
    val goodDeedChallengeUr: String,
    val goodDeedChallengeEn: String,
    val quiz: List<QuizQuestion>,
    val audioUrl: String = "",
    val videoUrl: String = "",
    val isAdminOverridden: Boolean = false
) {
    fun exampleFor(ageGroup: AgeGroup, isUrdu: Boolean): String = when (ageGroup) {
        AgeGroup.TEEN -> if (isUrdu) teenExampleUr else teenExampleEn
        AgeGroup.YOUNG_ADULT -> if (isUrdu) youngAdultExampleUr else youngAdultExampleEn
        AgeGroup.ADULT -> if (isUrdu) adultExampleUr else adultExampleEn
    }
}

data class GoodDeedTemplate(
    val key: String,
    val titleUr: String,
    val titleEn: String,
    val categoryUr: String,
    val categoryEn: String
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

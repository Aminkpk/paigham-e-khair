package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.AdminLesson
import com.example.data.model.AgeGroup
import com.example.data.model.Announcement
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityPost
import com.example.data.model.ContentReport
import com.example.data.model.CustomGoodDeed
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.GoodDeedLog
import com.example.data.model.LessonProgress
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PaighamRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        createConfiguredFirestore(context),
        Firebase.auth
    )

    companion object {
        private const val ADMIN_BOOTSTRAP_EMAIL = "kpkricecompny@gmail.com"

        fun createConfiguredFirestore(context: Context): FirebaseFirestore {
            val dbId = context.applicationContext.getString(R.string.firestore_database_id)
            val instance = FirebaseFirestore.getInstance(dbId)
            try {
                instance.firestoreSettings = FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                    .build()
            } catch (_: IllegalStateException) {
                // Settings already applied on existing singleton instance
            }
            return instance
        }

        fun todayDateKey(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun isBootstrapAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified && user.email == ADMIN_BOOTSTRAP_EMAIL
    }

    suspend fun checkIsAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        if (user.isEmailVerified && user.email == ADMIN_BOOTSTRAP_EMAIL) return true
        return try {
            val doc = db.collection("admins").document(user.uid).get().await()
            doc.exists()
        } catch (_: Exception) {
            false
        }
    }

    private fun <T> Flow<T>.logFirestoreErrors(
        operationType: OperationType,
        path: String,
        scopedUid: String? = null
    ): Flow<T> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && (scopedUid == null || auth.currentUser?.uid == scopedUid)) {
            handleFirestoreError(exceptionToLog, operationType, path, auth)
        }
        throw error
    }

    // ---------------- User Profile ----------------

    fun observeUserProfile(uid: String): Flow<FirestoreUserProfile?> = flow {
        val docRef = db.collection("users").document(uid)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            FirestoreUserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .logFirestoreErrors(OperationType.GET, docRef.path, uid)
        )
    }

    suspend fun getUserProfile(uid: String): FirestoreUserProfile? {
        val docRef = db.collection("users").document(uid)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                snap.toObject(
                    FirestoreUserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            } else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            throw e
        }
    }

    suspend fun saveOnboardingProfile(
        displayName: String,
        ageGroup: AgeGroup,
        language: AppLanguage
    ) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val existing = getUserProfile(uid)
        val safeName = displayName.trim().ifBlank { "Learner" }.take(80)

        try {
            if (existing == null) {
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "ageGroup" to ageGroup.code,
                    "language" to language.code,
                    "onboardingCompleted" to true,
                    "dailyReminderEnabled" to true,
                    "teenSafeMode" to (ageGroup == AgeGroup.TEEN),
                    "blockedUserIds" to emptyList<String>(),
                    "completedDaysCount" to 0L,
                    "totalGoodDeedsCount" to 0L,
                    "currentStreak" to 0L,
                    "lastActivityDate" to todayDateKey(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val update = mapOf(
                    "displayName" to safeName,
                    "ageGroup" to ageGroup.code,
                    "language" to language.code,
                    "onboardingCompleted" to true,
                    "teenSafeMode" to (ageGroup == AgeGroup.TEEN),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(update).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            throw e
        }
    }

    suspend fun updateLanguage(language: AppLanguage) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        try {
            docRef.update(
                mapOf(
                    "language" to language.code,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun updateAgeGroup(ageGroup: AgeGroup) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        try {
            docRef.update(
                mapOf(
                    "ageGroup" to ageGroup.code,
                    "teenSafeMode" to (ageGroup == AgeGroup.TEEN),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun blockCommunityUser(targetUid: String) {
        val uid = requireUserId()
        if (targetUid == uid || targetUid.isBlank()) return
        val docRef = db.collection("users").document(uid)
        try {
            val profile = getUserProfile(uid) ?: return
            val updatedList = (profile.blockedUserIds + targetUid).distinct().take(50)
            docRef.update(
                mapOf(
                    "blockedUserIds" to updatedList,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    // ---------------- Lesson Progress ----------------

    fun observeLessonProgress(uid: String): Flow<List<LessonProgress>> = flow {
        val colRef = db.collection("users").document(uid).collection("lessonProgress")
        emitAll(
            colRef.snapshots()
                .map { snap ->
                    snap.toObjects(
                        LessonProgress::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .logFirestoreErrors(OperationType.LIST, colRef.path, uid)
        )
    }

    suspend fun saveLessonProgress(
        lessonDay: Int,
        completed: Boolean? = null,
        bookmarked: Boolean? = null,
        activityCompleted: Boolean? = null,
        reflectionText: String? = null,
        quizScore: Int? = null
    ) {
        val uid = requireUserId()
        val docId = "day_$lessonDay"
        val docRef = db.collection("users").document(uid)
            .collection("lessonProgress").document(docId)

        try {
            val snap = docRef.get().await()
            val existing = if (snap.exists()) {
                snap.toObject(LessonProgress::class.java)
            } else null

            val finalCompleted = completed ?: existing?.completed ?: false
            val finalBookmarked = bookmarked ?: existing?.bookmarked ?: false
            val finalActivity = activityCompleted ?: existing?.activityCompleted ?: false
            val finalReflection = (reflectionText ?: existing?.reflectionText ?: "").take(2000)
            val prevBest = existing?.bestQuizScore?.toInt() ?: 0
            val finalBestScore = if (quizScore != null) maxOf(prevBest, quizScore.coerceIn(0, 100)) else prevBest
            val finalAttempts = (existing?.quizAttempts ?: 0L) + (if (quizScore != null) 1L else 0L)

            if (existing == null) {
                val payload = mapOf(
                    "userId" to uid,
                    "lessonDay" to lessonDay.toLong(),
                    "completed" to finalCompleted,
                    "bookmarked" to finalBookmarked,
                    "activityCompleted" to finalActivity,
                    "reflectionText" to finalReflection,
                    "bestQuizScore" to finalBestScore.toLong(),
                    "quizAttempts" to finalAttempts,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val update = mapOf(
                    "completed" to finalCompleted,
                    "bookmarked" to finalBookmarked,
                    "activityCompleted" to finalActivity,
                    "reflectionText" to finalReflection,
                    "bestQuizScore" to finalBestScore.toLong(),
                    "quizAttempts" to finalAttempts,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(update).await()
            }

            syncUserSummaryStats(uid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            throw e
        }
    }

    private suspend fun syncUserSummaryStats(uid: String) {
        val userRef = db.collection("users").document(uid)
        val userSnap = userRef.get().await()
        if (!userSnap.exists()) return
        val progressSnap = userRef.collection("lessonProgress").get().await()
        val deedsSnap = userRef.collection("goodDeeds").get().await()

        val completedCount = progressSnap.documents.count { it.getBoolean("completed") == true }.toLong()
        val deedsCount = deedsSnap.size().toLong()
        val profile = userSnap.toObject(FirestoreUserProfile::class.java)
        val today = todayDateKey()
        val newStreak = if (profile != null && profile.lastActivityDate == today) {
            maxOf(1L, profile.currentStreak)
        } else {
            (profile?.currentStreak ?: 0L) + 1L
        }

        userRef.update(
            mapOf(
                "completedDaysCount" to completedCount,
                "totalGoodDeedsCount" to deedsCount,
                "currentStreak" to newStreak.coerceAtMost(365L),
                "lastActivityDate" to today,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    // ---------------- Daily Good Deeds ----------------

    fun observeGoodDeedLogs(uid: String): Flow<List<GoodDeedLog>> = flow {
        val colRef = db.collection("users").document(uid).collection("goodDeeds")
        emitAll(
            colRef.snapshots()
                .map { snap ->
                    snap.toObjects(
                        GoodDeedLog::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logFirestoreErrors(OperationType.LIST, colRef.path, uid)
        )
    }

    suspend fun logGoodDeed(
        deedKey: String,
        titleUrdu: String,
        titleEnglish: String,
        category: String,
        note: String = ""
    ) {
        val uid = requireUserId()
        val docId = "deed_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("users").document(uid)
            .collection("goodDeeds").document(docId)

        val payload = mapOf(
            "userId" to uid,
            "deedKey" to deedKey.take(100).ifBlank { "custom" },
            "titleUrdu" to titleUrdu.trim().take(200).ifBlank { "نیکی" },
            "titleEnglish" to titleEnglish.trim().take(200).ifBlank { "Good Deed" },
            "category" to category.trim().take(80).ifBlank { "character" },
            "note" to note.trim().take(500),
            "dateKey" to todayDateKey(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            syncUserSummaryStats(uid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    // ---------------- Published Content & Announcements ----------------

    fun observePublishedAdminLessons(): Flow<List<AdminLesson>> = flow {
        val path = "lessons"
        emitAll(
            db.collection(path)
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        AdminLesson::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    fun observeActiveAnnouncements(): Flow<List<Announcement>> = flow {
        val path = "announcements"
        emitAll(
            db.collection(path)
                .whereEqualTo("active", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        Announcement::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    fun observeActiveCustomGoodDeeds(): Flow<List<CustomGoodDeed>> = flow {
        val path = "customGoodDeeds"
        emitAll(
            db.collection(path)
                .whereEqualTo("active", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CustomGoodDeed::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    // ---------------- Community & Safety ----------------

    fun observeApprovedCommunityPosts(): Flow<List<CommunityPost>> = flow {
        val path = "communityPosts"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", "APPROVED")
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        CommunityPost::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    suspend fun createCommunityPost(
        authorDisplayName: String,
        authorAgeGroup: AgeGroup,
        topic: String,
        content: String
    ) {
        val uid = requireUserId()
        require(authorAgeGroup != AgeGroup.TEEN) {
            "Teen accounts operate in Safe Guided Mode and cannot publish open community posts."
        }
        val docId = "post_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("communityPosts").document(docId)
        val payload = mapOf(
            "authorUid" to uid,
            "authorDisplayName" to authorDisplayName.trim().take(80).ifBlank { "Learner" },
            "authorAgeGroup" to authorAgeGroup.code,
            "topic" to topic,
            "content" to content.trim().take(1000),
            "status" to "APPROVED",
            "helpfulCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun markPostHelpful(postId: String) {
        requireUserId()
        val docRef = db.collection("communityPosts").document(postId)
        try {
            docRef.update(
                mapOf(
                    "helpfulCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun submitReport(
        targetType: String,
        targetId: String,
        reason: String
    ) {
        val uid = requireUserId()
        val docId = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("contentReports").document(docId)
        val payload = mapOf(
            "reporterUid" to uid,
            "targetType" to targetType,
            "targetId" to targetId.take(128).ifBlank { "general" },
            "reason" to reason.trim().take(500),
            "status" to "OPEN",
            "adminNote" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    // ---------------- Admin Operations ----------------

    fun observeAllUsersForAdmin(): Flow<List<FirestoreUserProfile>> = flow {
        val path = "users"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        FirestoreUserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    fun observeAllReportsForAdmin(): Flow<List<ContentReport>> = flow {
        val path = "contentReports"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(
                        ContentReport::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logFirestoreErrors(OperationType.LIST, path)
        )
    }

    suspend fun publishAnnouncement(
        titleUrdu: String,
        titleEnglish: String,
        bodyUrdu: String,
        bodyEnglish: String
    ) {
        val uid = requireUserId()
        val docId = "ann_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("announcements").document(docId)
        val payload = mapOf(
            "titleUrdu" to titleUrdu.trim().take(200),
            "titleEnglish" to titleEnglish.trim().take(200),
            "bodyUrdu" to bodyUrdu.trim().take(2000),
            "bodyEnglish" to bodyEnglish.trim().take(2000),
            "active" to true,
            "authorUid" to uid,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun saveAdminLesson(lesson: AdminLesson) {
        val uid = requireUserId()
        val docId = lesson.id.ifBlank { "day_${lesson.dayNumber}" }
        val docRef = db.collection("lessons").document(docId)
        val existingSnap = docRef.get().await()

        try {
            if (!existingSnap.exists()) {
                val payload = mapOf(
                    "dayNumber" to lesson.dayNumber,
                    "weekNumber" to lesson.weekNumber,
                    "categoryId" to lesson.categoryId.take(60),
                    "titleUrdu" to lesson.titleUrdu.take(200),
                    "titleEnglish" to lesson.titleEnglish.take(200),
                    "summaryUrdu" to lesson.summaryUrdu.take(500),
                    "explanationUrdu" to lesson.explanationUrdu.take(8000),
                    "explanationEnglish" to lesson.explanationEnglish.take(8000),
                    "quranRef" to lesson.quranRef.take(300),
                    "quranArabic" to lesson.quranArabic.take(1500),
                    "quranTranslationUrdu" to lesson.quranTranslationUrdu.take(1500),
                    "hadithRef" to lesson.hadithRef.take(300),
                    "hadithTextUrdu" to lesson.hadithTextUrdu.take(1500),
                    "verificationStatus" to lesson.verificationStatus,
                    "practicalActivityUrdu" to lesson.practicalActivityUrdu.take(1000),
                    "goodDeedChallengeUrdu" to lesson.goodDeedChallengeUrdu.take(500),
                    "audioUrl" to lesson.audioUrl.take(500),
                    "videoUrl" to lesson.videoUrl.take(500),
                    "published" to lesson.published,
                    "updatedBy" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val update = mapOf(
                    "dayNumber" to lesson.dayNumber,
                    "weekNumber" to lesson.weekNumber,
                    "categoryId" to lesson.categoryId.take(60),
                    "titleUrdu" to lesson.titleUrdu.take(200),
                    "titleEnglish" to lesson.titleEnglish.take(200),
                    "summaryUrdu" to lesson.summaryUrdu.take(500),
                    "explanationUrdu" to lesson.explanationUrdu.take(8000),
                    "explanationEnglish" to lesson.explanationEnglish.take(8000),
                    "quranRef" to lesson.quranRef.take(300),
                    "quranArabic" to lesson.quranArabic.take(1500),
                    "quranTranslationUrdu" to lesson.quranTranslationUrdu.take(1500),
                    "hadithRef" to lesson.hadithRef.take(300),
                    "hadithTextUrdu" to lesson.hadithTextUrdu.take(1500),
                    "verificationStatus" to lesson.verificationStatus,
                    "practicalActivityUrdu" to lesson.practicalActivityUrdu.take(1000),
                    "goodDeedChallengeUrdu" to lesson.goodDeedChallengeUrdu.take(500),
                    "audioUrl" to lesson.audioUrl.take(500),
                    "videoUrl" to lesson.videoUrl.take(500),
                    "published" to lesson.published,
                    "updatedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(update).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            throw e
        }
    }

    suspend fun addCustomGoodDeed(titleUrdu: String, titleEnglish: String, category: String) {
        requireUserId()
        val docId = "cgd_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("customGoodDeeds").document(docId)
        val payload = mapOf(
            "titleUrdu" to titleUrdu.trim().take(200),
            "titleEnglish" to titleEnglish.trim().take(200),
            "category" to category.trim().take(80).ifBlank { "service" },
            "active" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun reviewContentReport(reportId: String, newStatus: String, adminNote: String) {
        requireUserId()
        val docRef = db.collection("contentReports").document(reportId)
        try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "adminNote" to adminNote.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun moderateCommunityPost(postId: String, newStatus: String) {
        requireUserId()
        val docRef = db.collection("communityPosts").document(postId)
        try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun deleteAnnouncement(announcementId: String) {
        requireUserId()
        val docRef = db.collection("announcements").document(announcementId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            throw e
        }
    }

    // ---------------- Account & Data Deletion ----------------

    suspend fun deleteAllUserData() {
        val uid = requireUserId()
        val userRef = db.collection("users").document(uid)
        try {
            val progressDocs = userRef.collection("lessonProgress").get().await()
            for (doc in progressDocs.documents) {
                doc.reference.delete().await()
            }
            val deedDocs = userRef.collection("goodDeeds").get().await()
            for (doc in deedDocs.documents) {
                doc.reference.delete().await()
            }
            userRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, userRef.path, auth)
            throw e
        }
    }
}

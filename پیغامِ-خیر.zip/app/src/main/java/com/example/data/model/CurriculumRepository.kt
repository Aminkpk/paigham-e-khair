package com.example.data.model

object CurriculumRepository {

    val baseLessons: List<CuratedLesson> by lazy {
        (CurriculumWeek1.lessons +
            CurriculumWeek2.lessons +
            CurriculumWeek3.lessons +
            CurriculumWeek4.lessons).sortedBy { it.dayNumber }
    }

    fun mergeWithAdminLessons(adminLessons: List<AdminLesson>): List<CuratedLesson> {
        if (adminLessons.isEmpty()) return baseLessons
        val overrideByDay = adminLessons.filter { it.published }.associateBy { it.dayNumber.toInt() }
        val merged = baseLessons.map { base ->
            val admin = overrideByDay[base.dayNumber]
            if (admin == null) {
                base
            } else {
                base.copy(
                    titleUr = admin.titleUrdu.ifBlank { base.titleUr },
                    titleEn = admin.titleEnglish.ifBlank { base.titleEn },
                    introUr = admin.summaryUrdu.ifBlank { base.introUr },
                    explanationUr = admin.explanationUrdu.ifBlank { base.explanationUr },
                    explanationEn = admin.explanationEnglish.ifBlank { base.explanationEn },
                    quranArabic = admin.quranArabic.ifBlank { base.quranArabic },
                    quranRefUr = admin.quranRef.ifBlank { base.quranRefUr },
                    quranTranslationUr = admin.quranTranslationUrdu.ifBlank { base.quranTranslationUr },
                    hadithRefUr = admin.hadithRef.ifBlank { base.hadithRefUr },
                    hadithTextUr = admin.hadithTextUrdu.ifBlank { base.hadithTextUr },
                    verificationStatus = admin.verificationStatus.ifBlank { base.verificationStatus },
                    practicalActivityUr = admin.practicalActivityUrdu.ifBlank { base.practicalActivityUr },
                    goodDeedChallengeUr = admin.goodDeedChallengeUrdu.ifBlank { base.goodDeedChallengeUr },
                    audioUrl = admin.audioUrl,
                    videoUrl = admin.videoUrl,
                    isAdminOverridden = true
                )
            }
        }
        val extraDays = overrideByDay.filterKeys { day -> baseLessons.none { it.dayNumber == day } }
            .values
            .sortedBy { it.dayNumber }
            .map { admin ->
                CuratedLesson(
                    dayNumber = admin.dayNumber.toInt(),
                    weekNumber = admin.weekNumber.toInt().coerceAtLeast(1),
                    categoryIds = listOf(admin.categoryId.ifBlank { "self_improvement" }),
                    titleUr = admin.titleUrdu,
                    titleEn = admin.titleEnglish.ifBlank { admin.titleUrdu },
                    objectivesUr = listOf(admin.summaryUrdu),
                    objectivesEn = listOf(admin.summaryUrdu),
                    introUr = admin.summaryUrdu,
                    introEn = admin.summaryUrdu,
                    explanationUr = admin.explanationUrdu,
                    explanationEn = admin.explanationEnglish.ifBlank { admin.explanationUrdu },
                    quranArabic = admin.quranArabic,
                    quranTranslationUr = admin.quranTranslationUrdu,
                    quranTranslationEn = admin.quranTranslationUrdu,
                    quranRefUr = admin.quranRef,
                    quranRefEn = admin.quranRef,
                    hadithTextUr = admin.hadithTextUrdu,
                    hadithTextEn = admin.hadithTextUrdu,
                    hadithRefUr = admin.hadithRef,
                    hadithRefEn = admin.hadithRef,
                    verificationStatus = admin.verificationStatus,
                    teenExampleUr = admin.summaryUrdu,
                    teenExampleEn = admin.summaryUrdu,
                    youngAdultExampleUr = admin.summaryUrdu,
                    youngAdultExampleEn = admin.summaryUrdu,
                    adultExampleUr = admin.summaryUrdu,
                    adultExampleEn = admin.summaryUrdu,
                    keyLessonsUr = listOf(admin.summaryUrdu),
                    keyLessonsEn = listOf(admin.summaryUrdu),
                    practicalActivityUr = admin.practicalActivityUrdu,
                    practicalActivityEn = admin.practicalActivityUrdu,
                    reflectionPromptUr = admin.summaryUrdu,
                    reflectionPromptEn = admin.summaryUrdu,
                    goodDeedChallengeUr = admin.goodDeedChallengeUrdu,
                    goodDeedChallengeEn = admin.goodDeedChallengeUrdu,
                    quiz = emptyList(),
                    audioUrl = admin.audioUrl,
                    videoUrl = admin.videoUrl,
                    isAdminOverridden = true
                )
            }
        return merged + extraDays
    }

    val dashboardSections: List<DashboardSectionItem> = listOf(
        DashboardSectionItem(
            id = DashboardSectionId.TODAYS_LESSON,
            titleUr = "آج کا سبق",
            titleEn = "Today's Lesson",
            subtitleUr = "اپنے موجودہ دن کا سبق پڑھیں",
            subtitleEn = "Open your active day's lesson"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.SELF_IMPROVEMENT,
            titleUr = "اصلاحِ نفس",
            titleEn = "Self Improvement",
            subtitleUr = "نیت، محاسبہ اور باطنی پاکیزگی",
            subtitleEn = "Intention, accountability & growth",
            categoryFilter = "self_improvement"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.ISLAMIC_CHARACTER,
            titleUr = "اسلامی اخلاق",
            titleEn = "Islamic Character",
            subtitleUr = "سچائی، امانت اور زبان کی حفاظت",
            subtitleEn = "Honesty, trust & noble speech",
            categoryFilter = "islamic_character"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.YOUTH_DEVELOPMENT,
            titleUr = "نوجوانوں کی تربیت",
            titleEn = "Youth Development",
            subtitleUr = "کردار، تعلیم اور محفوظ ڈیجیٹل عادات",
            subtitleEn = "Guidance for teens & young adults",
            categoryFilter = "youth_development"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.FAMILY_LIFE,
            titleUr = "خاندانی زندگی",
            titleEn = "Family Life",
            subtitleUr = "والدین، میاں بیوی، اولاد اور صلہ رحمی",
            subtitleEn = "Parents, marriage, kids & kinship",
            categoryFilter = "family_life"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.UNITY_BROTHERHOOD,
            titleUr = "اتحاد و بھائی چارہ",
            titleEn = "Unity & Brotherhood",
            subtitleUr = "اخوت، احترام اور تفرقے سے بچاؤ",
            subtitleEn = "Brotherhood & overcoming bias",
            categoryFilter = "unity_brotherhood"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.PEACE_TOLERANCE,
            titleUr = "امن و برداشت",
            titleEn = "Peace & Tolerance",
            subtitleUr = "معافی، صلح اور تشدد کا انکار",
            subtitleEn = "Patience, forgiveness & peace",
            categoryFilter = "peace_tolerance"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.SOCIAL_REFORM,
            titleUr = "معاشرتی اصلاح",
            titleEn = "Social Reform",
            subtitleUr = "عدل، امانت اور بدعنوانی سے انکار",
            subtitleEn = "Justice, integrity & civic ethics",
            categoryFilter = "social_reform"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.COMMUNITY_SERVICE,
            titleUr = "خدمتِ خلق",
            titleEn = "Community Service",
            subtitleUr = "یتیموں، پڑوسیوں اور انسانیت کی مدد",
            subtitleEn = "Serving humanity & unity hub",
            categoryFilter = "community_service"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.DAILY_GOOD_DEED,
            titleUr = "روزانہ نیکی",
            titleEn = "Daily Good Deed",
            subtitleUr = "روزمرہ خیر کے عملی کام اور ریکارڈ",
            subtitleEn = "Practice & log daily kindness"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.QUIZZES_ASSESSMENTS,
            titleUr = "کوئز اور امتحان",
            titleEn = "Quizzes & Exams",
            subtitleUr = "30 اسباق کے 150 معروضی سوالات",
            subtitleEn = "Test your learning across 30 days"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.MY_PROGRESS,
            titleUr = "میری پیش رفت",
            titleEn = "My Progress",
            subtitleUr = "کارکردگی، سلسلہ اور سرٹیفکیٹ",
            subtitleEn = "Scores, streak & completion certificate"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.SAVED_LESSONS,
            titleUr = "محفوظ اسباق",
            titleEn = "Saved Lessons",
            subtitleUr = "بک مارک شدہ پسندیدہ اسباق",
            subtitleEn = "Your bookmarked lessons"
        ),
        DashboardSectionItem(
            id = DashboardSectionId.ABOUT_GUIDANCE,
            titleUr = "ہماری رہنمائی",
            titleEn = "About & Guidance",
            subtitleUr = "مشن، حوالہ جات، پرائیویسی اور ایڈمن",
            subtitleEn = "Mission, privacy, offline & admin"
        )
    )

    val builtInGoodDeeds: List<GoodDeedTemplate> = listOf(
        GoodDeedTemplate("speak_kindly", "کسی سے نرم لہجے اور محبت سے بات کرنا", "Speak kindly to someone", "اخلاق", "Character"),
        GoodDeedTemplate("help_in_need", "کسی ضرورت مند کی خاموشی سے مدد کرنا", "Help a person in need quietly", "خدمتِ خلق", "Service"),
        GoodDeedTemplate("reconcile_two", "دو ناراض لوگوں میں صلح کرانے کی کوشش کرنا", "Help reconcile two people peacefully", "امن و اتحاد", "Peace"),
        GoodDeedTemplate("respect_parents", "والدین یا بزرگوں کی خدمت اور ادب کرنا", "Respect and serve parents or elders", "خاندان", "Family"),
        GoodDeedTemplate("forgive_someone", "کسی کی غلطی دل سے معاف کر دینا", "Forgive someone sincerely", "درگزر", "Forgiveness"),
        GoodDeedTemplate("avoid_rumors", "بغیر تصدیق کسی خبر یا افواہ کو آگے نہ پھیلانا", "Refuse to spread unverified rumors", "دیانت", "Truthfulness"),
        GoodDeedTemplate("visit_elderly", "کسی بزرگ یا بیمار کی عیادت اور حوصلہ افزائی کرنا", "Visit or support an elderly or sick person", "ہمدردی", "Compassion"),
        GoodDeedTemplate("help_neighbor", "پڑوسی کے کام آنا یا کھانا شیئر کرنا", "Help a neighbor or share food", "محلہ", "Neighborhood")
    )
}

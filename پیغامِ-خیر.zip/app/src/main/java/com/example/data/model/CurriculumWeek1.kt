package com.example.data.model

object CurriculumWeek1 {
    val lessons: List<CuratedLesson> = listOf(
        CuratedLesson(
            dayNumber = 1,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "islamic_character"),
            titleUr = "زندگی کا مقصد دریافت کرنا",
            titleEn = "Discovering the Purpose of Life",
            objectivesUr = listOf(
                "انسان کی تخلیق کے بنیادی مقصد اور اللہ کی بندگی کا شعور حاصل کرنا۔",
                "عبادت کو صرف رسومات کے بجائے پورے طرزِ زندگی سے جوڑنا۔",
                "اپنی روزمرہ مصروفیات میں نیت کی درستگی کا عملی آغاز کرنا۔"
            ),
            objectivesEn = listOf(
                "Understand the core purpose of human creation and mindful devotion to Allah.",
                "Connect worship to everyday character, honesty, and service rather than rituals alone.",
                "Practice setting sincere intentions in daily routines."
            ),
            introUr = "ہر باشعور انسان کے دل میں کبھی نہ کبھی یہ سوال ضرور ابھرتا ہے کہ میں اس دنیا میں کیوں آیا ہوں اور میری زندگی کی اصل منزل کیا ہے۔",
            introEn = "Every thoughtful person eventually asks: why am I here, and what gives my life lasting meaning?",
            explanationUr = "اسلام انسان کو بے مقصد مخلوق نہیں سمجھتا۔ قرآن کریم واضح فرماتا ہے کہ انسان کی تخلیق ایک عظیم امانت، ذمہ داری اور اللہ تعالیٰ کی معرفت و اطاعت کے لیے ہوئی ہے۔ عبادت کا مفہوم صرف نماز اور روزے تک محدود نہیں، بلکہ جب آپ سچ بولتے ہیں، والدین کی خدمت کرتے ہیں، علم حاصل کرتے ہیں، یا کسی کمزور کی مدد کرتے ہیں اور آپ کی نیت اللہ کی رضا ہو، تو آپ کا ہر عمل عبادت بن جاتا ہے۔ زندگی کا مقصد جاننے سے انسان بے چینی، حسد اور سطحی دوڑ سے نکل کر سکونِ قلب اور بامقصد خدمت کی راہ پر آ جاتا ہے۔",
            explanationEn = "Islam teaches that human life is deeply purposeful. We are created to know Allah, live with moral accountability, and bring goodness to creation. Worship is not confined to prayer mats; honest work, kindness to parents, fair dealing, and seeking beneficial knowledge all become acts of worship when done with sincere intention. Knowing your purpose frees the heart from aimless anxiety and grounds every hour in dignity.",
            quranArabic = "وَمَا خَلَقْتُ الْجِنَّ وَالْإِنسَ إِلَّا لِيَعْبُدُونِ",
            quranTranslationUr = "اور میں نے جنوں اور انسانوں کو صرف اس لیے پیدا کیا ہے کہ وہ میری بندگی کریں۔",
            quranTranslationEn = "And I did not create the jinn and mankind except to worship Me.",
            quranRefUr = "سورۃ الذاریات 51:56",
            quranRefEn = "Surah Adh-Dhariyat 51:56",
            hadithTextUr = "اعمال کا دارومدار نیتوں پر ہے، اور ہر شخص کو وہی ملے گا جس کی اس نے نیت کی۔",
            hadithTextEn = "Actions are judged by intentions, and every person will have what they intended.",
            hadithRefUr = "صحیح بخاری، حدیث 1 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 1 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول یا کالج کی پڑھائی کرتے وقت یہ نیت کرنا کہ میں علم حاصل کر کے اپنے والدین کا سہارا بنوں گا اور معاشرے کی خدمت کروں گا۔",
            teenExampleEn = "Studying at school with the intention of honoring your parents and gaining skills to serve people responsibly.",
            youngAdultExampleUr = "کیریئر یا یونیورسٹی میں کامیابی کی دوڑ کے ساتھ روزانہ 10 منٹ اپنی نیت، نماز اور اخلاقی سمت کا جائزہ لینا۔",
            youngAdultExampleEn = "Balancing university or early career goals by taking 10 quiet minutes daily to renew your intention and moral direction.",
            adultExampleUr = "دفتر یا کاروبار کے آغاز پر یہ عہد کرنا کہ رزقِ حلال کمانا اور اہلِ خانہ کی کفالت اللہ کی خوشنودی کے لیے ہے۔",
            adultExampleEn = "Starting your workday with the conscious intention that earning lawful income and caring for family is an act of devotion.",
            keyLessonsUr = listOf(
                "زندگی بے مقصد نہیں بلکہ ایک باعزت امانت ہے۔",
                "خالص نیت عام دنیاوی کاموں کو بھی عبادت بنا دیتی ہے۔",
                "مقصد کا شعور دل کو اطمینان اور سمت عطا کرتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Life is a purposeful trust, not an accident.",
                "Sincere intention transforms ordinary daily duties into worship.",
                "Clarity of purpose brings inner calm and steady direction."
            ),
            practicalActivityUr = "آج صبح یا شام پرسکون ماحول میں کاغذ پر اپنے 3 بڑے زندگی کے اہداف لکھیں اور ہر ایک کے سامنے اس کی اچھی نیت تحریر کریں۔",
            practicalActivityEn = "Write down three important life goals today and beside each one write a sincere, service-oriented intention.",
            reflectionPromptUr = "آج کے دن میرا کون سا عمل محض عادت تھا جسے میں اب اچھی نیت کے ساتھ عبادت بنا سکتا ہوں؟",
            reflectionPromptEn = "Which daily habit today can I elevate into worship simply by renewing my intention?",
            goodDeedChallengeUr = "آج اپنے کسی ایک کام کا آغاز بسم اللہ اور خالص نیت کے ساتھ کریں اور کسی گھر والے کو خوشی دیں۔",
            goodDeedChallengeEn = "Begin one key task today with Bismillah and pure intention, and bring joy to a family member.",
            quiz = listOf(
                QuizQuestion("d1q1", "سورۃ الذاریات (51:56) کے مطابق انسان کی تخلیق کا بنیادی مقصد کیا ہے؟", "According to Surah Adh-Dhariyat (51:56), what is the primary purpose of human creation?", listOf("صرف دولت جمع کرنا", "اللہ تعالیٰ کی بندگی اور معرفت", "دوسروں پر برتری حاصل کرنا", "بے مقصد زندگی گزارنا"), listOf("Accumulating wealth only", "Worshipping and knowing Allah", "Dominating others", "Living without responsibility"), 1, "قرآن کریم بندگی اور اللہ سے تعلق کو زندگی کا محور قرار دیتا ہے۔", "The Quran centers human purpose on devotion and connection with Allah."),
                QuizQuestion("d1q2", "صحیح بخاری کی پہلی حدیث کے مطابق اعمال کا دارومدار کس چیز پر ہے؟", "According to the first Hadith in Sahih al-Bukhari, what determines the value of actions?", listOf("شہرت", "نیت", "دولت", "رفتار"), listOf("Fame", "Intention", "Wealth", "Speed"), 1, "نیت کی پاکیزگی عمل کو قبولیت بخشتی ہے۔", "Sincere intention gives actions their spiritual value."),
                QuizQuestion("d1q3", "اسلام میں عبادت کا دائرہ کہاں تک پھیلا ہوا ہے؟", "How broad is the concept of worship in Islam?", listOf("صرف مسجد تک", "صرف رمضان تک", "نیتِ خیر کے ساتھ پوری زندگی کے جائز اعمال تک", "صرف بڑھاپے تک"), listOf("Only inside a mosque", "Only during Ramadan", "All lawful daily actions done with sincere intention", "Only in old age"), 2, "حلال رزق، تعلیم، اور خدمتِ خلق بھی اچھی نیت سے عبادت ہیں۔", "Lawful work, learning, and helping others become worship with good intention."),
                QuizQuestion("d1q4", "زندگی کا واضح مقصد سمجھنے سے انسان کو کیا فائدہ ہوتا ہے؟", "What benefit comes from understanding life's purpose?", listOf("تکبر بڑھتا ہے", "سکونِ قلب اور درست سمت ملتی ہے", "ذمہ داری ختم ہو جاتی ہے", "لوگوں سے دوری ہوتی ہے"), listOf("Arrogance increases", "Inner peace and clear direction", "Responsibilities disappear", "Isolation from society"), 1, "بامقصد زندگی بے چینی کم کرتی ہے اور کردار کو مضبوط بناتی ہے۔", "Purpose reduces aimless anxiety and strengthens character."),
                QuizQuestion("d1q5", "آج کی عملی سرگرمی کس بات کی مشق کراتی ہے؟", "What does today's practical activity train us to do?", listOf("بغیر سوچے کام کرنا", "اہداف کو اچھی نیت سے جوڑنا", "دوسروں پر تنقید کرنا", "وقت ضائع کرنا"), listOf("Act without thinking", "Connect personal goals with sincere intention", "Criticize others", "Waste time"), 1, "اہداف کے ساتھ نیت جوڑنے سے عمل میں برکت اور توازن آتا ہے۔", "Aligning goals with pure intention brings balance and sincerity.")
            )
        ),
        CuratedLesson(
            dayNumber = 2,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "islamic_character"),
            titleUr = "خود احتسابی اور ذاتی ذمہ داری",
            titleEn = "Self-Accountability and Personal Responsibility",
            objectivesUr = listOf(
                "اپنی غلطیوں کا الزام دوسروں پر ڈالنے کے بجائے خود احتسابی سیکھنا۔",
                "وقت اور صلاحیتوں کے درست استعمال کا احساس بیدار کرنا۔",
                "روزانہ رات سونے سے پہلے 5 منٹ اپنا محاسبہ کرنے کی عادت ڈالنا۔"
            ),
            objectivesEn = listOf(
                "Practice honest self-reflection instead of blaming others.",
                "Appreciate accountability for time, words, and abilities.",
                "Build a nightly five-minute habit of self-review."
            ),
            introUr = "ترقی کا پہلا زینہ یہ ہے کہ انسان دوسروں کی خامیاں گننے کے بجائے اپنے گریبان میں جھانکے۔",
            introEn = "True personal growth begins when we inspect our own habits before pointing out the flaws of others.",
            explanationUr = "جب معاشرے میں ہر فرد اپنی ذمہ داری دوسروں یا حالات پر ڈال دے تو اصلاح رک جاتی ہے۔ اسلام ہمیں سکھاتا ہے کہ کل قیامت کے دن ہر انسان سے اس کے اپنے اعمال، وقت، علم اور معاملات کے بارے میں پوچھا جائے گا۔ خود احتسابی کا مطلب مایوسی یا خود کو کوسنا نہیں، بلکہ ایمانداری سے یہ دیکھنا ہے کہ آج مجھ سے کیا اچھا ہوا اور کہاں بہتری کی گنجائش ہے۔ جو شخص روزانہ اپنا محاسبہ کرتا ہے، وہ کل کو آج سے بہتر بنا لیتا ہے۔",
            explanationEn = "When everyone blames circumstances or other people, reform stalls. Islam teaches individual accountability: every person answers for their own choices, time, and treatment of others. Self-accountability does not mean harsh self-hatred; it means calm honesty—recognizing what went well today and repairing what fell short so tomorrow is wiser and kinder.",
            quranArabic = "يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَلْتَنظُرْ نَفْسٌ مَّا قَدَّمَتْ لِغَدٍ",
            quranTranslationUr = "اے ایمان والو! اللہ سے ڈرو اور ہر شخص کو دیکھنا چاہیے کہ اس نے کل (آخرت) کے لیے آگے کیا بھیجا ہے۔",
            quranTranslationEn = "O you who believe, be mindful of Allah, and let every soul look to what it has sent forth for tomorrow.",
            quranRefUr = "سورۃ الحشر 59:18",
            quranRefEn = "Surah Al-Hashr 59:18",
            hadithTextUr = "عقل مند وہ ہے جو اپنے نفس کا محاسبہ کرے اور موت کے بعد کی زندگی کے لیے عمل کرے۔",
            hadithTextEn = "The wise person is the one who holds themselves accountable and works for what comes after death.",
            hadithRefUr = "جامع ترمذی، حدیث 2459 (حوالہ درج: حسن / علمی مراجعت کے ساتھ مستند روایت)",
            hadithRefEn = "Jami' at-Tirmidhi, Hadith 2459 (Reported as Hasan; classical source cited)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "امتحان میں نمبر کم آنے پر استاد یا دوست کو الزام دینے کے بجائے اپنے مطالعے کے وقت کا جائزہ لینا۔",
            teenExampleEn = "Reviewing your own study routine after a low grade instead of blaming teachers or friends.",
            youngAdultExampleUr = "سوشل میڈیا پر ضائع ہونے والے وقت کا حساب لگانا اور روزانہ ایک گھنٹہ تعمیری سیکھنے کے لیے مختص کرنا۔",
            youngAdultExampleEn = "Auditing screen time honestly and reclaiming an hour daily for meaningful learning or skill-building.",
            adultExampleUr = "گھریلو یا دفتری تنازعے میں پہلے یہ سوچنا کہ میری اپنی کوتاہی یا لہجے کا کتنا حصہ تھا۔",
            adultExampleEn = "In a family or workplace disagreement, asking first what part your own tone or oversight played.",
            keyLessonsUr = listOf(
                "تبدیلی دوسروں سے نہیں بلکہ میری اپنی ذات سے شروع ہوتی ہے۔",
                "روزانہ مختصر محاسبہ بڑی غلطیوں سے بچاتا ہے۔",
                "خود احتسابی کا مقصد مایوسی نہیں بلکہ مثبت اصلاح ہے۔"
            ),
            keyLessonsEn = listOf(
                "Meaningful change starts with oneself, not others.",
                "Brief daily self-review prevents small mistakes from becoming habits.",
                "Accountability leads to hopeful improvement, never despair."
            ),
            practicalActivityUr = "آج سونے سے قبل 5 منٹ کا وقت نکالیں: ایک نیکی لکھیں جس پر شکر ادا کریں اور ایک عادت لکھیں جسے کل بہتر بنانا ہے۔",
            practicalActivityEn = "Spend 5 quiet minutes before sleep listing one good action you are grateful for and one habit to improve tomorrow.",
            reflectionPromptUr = "آج وہ کون سا لمحہ تھا جب میں بہانے کے بجائے ذمہ داری قبول کر سکتا تھا؟",
            reflectionPromptEn = "Which moment today offered me a chance to take responsibility instead of making an excuse?",
            goodDeedChallengeUr = "اگر آج آپ سے کسی کے ساتھ کوئی کوتاہی ہو تو دل سے معذرت کر کے معاملہ درست کریں۔",
            goodDeedChallengeEn = "If you made a mistake with someone today, apologize sincerely and make it right.",
            quiz = listOf(
                QuizQuestion("d2q1", "سورۃ الحشر (59:18) انسان کو کس بات کی دعوت دیتی ہے؟", "What does Surah Al-Hashr (59:18) invite believers to do?", listOf("دوسروں کی ٹوہ میں رہنا", "اپنے کل کے لیے اعمال کا جائزہ لینا", "ماضی پر افسوس کرتے رہنا", "ذمہ داری چھوڑ دینا"), listOf("Inspect others' faults", "Examine what one has sent ahead for tomorrow", "Remain stuck in regret", "Abandon effort"), 1, "آیت ہمیں تقویٰ اور اپنے اعمال کے مستقبل کے نتیجے پر غور کا حکم دیتی ہے۔", "The verse calls us to mindfulness of Allah and personal self-evaluation."),
                QuizQuestion("d2q2", "حدیث میں عقل مند کسے کہا گیا ہے؟", "Whom does the Hadith describe as wise?", listOf("جو دوسروں پر تنقید کرے", "جو اپنے نفس کا محاسبہ کرے", "جو ہمیشہ جیتے", "جو بحث کرے"), listOf("One who criticizes others", "One who holds themselves accountable", "One who always wins arguments", "One who avoids work"), 1, "عقل مندی اپنے نفس کی نگرانی اور بامقصد عمل میں ہے۔", "Wisdom lies in self-accountability and purposeful action."),
                QuizQuestion("d2q3", "خود احتسابی کا درست رویہ کیا ہے؟", "What is the healthy attitude of self-accountability?", listOf("مایوس ہو کر بیٹھ جانا", "ایمانداری سے جائزہ لے کر اصلاح کرنا", "غلطی چھپانا", "دوسروں کو الزام دینا"), listOf("Giving up in despair", "Honest evaluation followed by steady improvement", "Hiding mistakes", "Blaming others"), 1, "محاسبہ بہتری کی امید اور عملی قدم کا نام ہے۔", "Self-review is meant to inspire sincere repair and growth."),
                QuizQuestion("d2q4", "معاشرتی اصلاح کب رک جاتی ہے؟", "When does social reform stall?", listOf("جب لوگ مل کر کام کریں", "جب ہر فرد اپنی ذمہ داری دوسروں پر ڈال دے", "جب نوجوان علم سیکھیں", "جب سچ بولا جائے"), listOf("When people cooperate", "When everyone shifts responsibility onto others", "When youth learn", "When truth is spoken"), 1, "ذاتی ذمہ داری قبول کیے بغیر کوئی معاشرہ نہیں سنور سکتا۔", "A society cannot thrive when individuals refuse personal responsibility."),
                QuizQuestion("d2q5", "آج کی رات سونے سے پہلے کیا عملی مشق تجویز کی گئی ہے؟", "What nightly habit is recommended in today's activity?", listOf("فون پر خبریں دیکھنا", "5 منٹ اپنا محاسبہ اور شکر گزاری", "دوسروں کی شکایت لکھنا", "دیر تک جاگنا"), listOf("Scrolling news", "5 minutes of gratitude and self-review", "Listing others' flaws", "Staying up late"), 1, "مختصر روزانہ محاسبہ کردار کو سنوارتا ہے۔", "A brief nightly review keeps personal growth consistent.")
            )
        ),
        CuratedLesson(
            dayNumber = 3,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "islamic_character"),
            titleUr = "سچائی اور دیانت داری",
            titleEn = "Truthfulness and Honesty",
            objectivesUr = listOf(
                "قول و فعل میں سچائی اور امانت کی اہمیت سمجھنا۔",
                "چھوٹے فائدے کے لیے جھوٹ یا دھوکے سے بچنے کا عزم کرنا۔",
                "اعتماد اور دیانت کو کامیابی کی بنیاد بنانا۔"
            ),
            objectivesEn = listOf(
                "Understand the centrality of truthfulness (Sidq) in speech and action.",
                "Resist small dishonest shortcuts for temporary gain.",
                "Build trustworthiness as the foundation of personal and social success."
            ),
            introUr = "سچائی کردار کی وہ روشنی ہے جس کے بغیر نہ فرد پر اعتماد کیا جا سکتا ہے اور نہ کوئی معاشرہ مضبوط ہو سکتا ہے۔",
            introEn = "Truthfulness is the moral light without which neither personal dignity nor social trust can stand.",
            explanationUr = "رسول اکرم ﷺ کو نبوت سے پہلے بھی لوگ 'الصادق' اور 'الامین' کے لقب سے پکارتے تھے۔ اسلام میں سچائی صرف زبان تک محدود نہیں بلکہ لین دین، وعدے، کام کے وقت، امتحان اور رشتوں میں بھی دیانت داری لازم ہے۔ بعض اوقات انسان مشکل سے بچنے یا فوری فائدے کے لیے چھوٹا سا جھوٹ بول دیتا ہے، مگر جھوٹ دل کا سکون چھین لیتا ہے اور اعتماد توڑ دیتا ہے۔ سچ شروع میں کٹھن لگ سکتا ہے لیکن انجام میں عزت، برکت اور اطمینان لاتا ہے۔",
            explanationEn = "Even before Prophethood, the Prophet Muhammad ﷺ was known across Makkah as As-Sadiq (the Truthful) and Al-Amin (the Trustworthy). In Islam, truthfulness extends beyond words into exams, commerce, promises, and digital life. A small lie may feel convenient for a moment, yet it erodes inner peace and public trust. Truthfulness brings lasting honor and blessing.",
            quranArabic = "يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَقُولُوا قَوْلًا سَدِيدًا",
            quranTranslationUr = "اے ایمان والو! اللہ سے ڈرو اور سیدھی اور سچی بات کہا کرو۔",
            quranTranslationEn = "O you who believe, be mindful of Allah and speak words of straightforward truth.",
            quranRefUr = "سورۃ الاحزاب 33:70",
            quranRefEn = "Surah Al-Ahzab 33:70",
            hadithTextUr = "بے شک سچائی نیکی کی طرف لے جاتی ہے اور نیکی جنت کی طرف لے جاتی ہے۔",
            hadithTextEn = "Indeed, truthfulness leads to righteousness, and righteousness leads to Paradise.",
            hadithRefUr = "صحیح بخاری، حدیث 6094 / صحیح مسلم، حدیث 2607 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6094 / Sahih Muslim, Hadith 2607 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول کے ٹیسٹ یا اسائنمنٹ میں نقل نہ کرنا اور والدین کو اپنے اصل نمبر ایمانداری سے بتانا۔",
            teenExampleEn = "Refusing to cheat on a test or assignment and sharing your real results honestly with parents.",
            youngAdultExampleUr = "سی وی (CV) یا انٹرویو میں اپنی مہارتوں کو بڑھا چڑھا کر پیش نہ کرنا اور وقتِ مقررہ پر پورا کام کرنا۔",
            youngAdultExampleEn = "Keeping your resume and internship hours completely honest without exaggerating skills.",
            adultExampleUr = "کاروبار میں چیز کا اصل عیب گاہک کو بتانا اور ناپ تول یا معیار میں کمی نہ کرنا۔",
            adultExampleEn = "Disclosing product defects honestly in trade and delivering full quality as promised.",
            keyLessonsUr = listOf(
                "سچائی نیکی اور جنت کا راستہ ہے۔",
                "دیانت داری صرف الفاظ نہیں بلکہ پورے لین دین میں ہوتی ہے۔",
                "وقتی نقصان کے خوف سے سچ نہ چھوڑیں؛ اعتماد سب سے بڑا سرمایہ ہے۔"
            ),
            keyLessonsEn = listOf(
                "Truthfulness guides toward righteousness and peace.",
                "Honesty applies to deeds, promises, and transactions—not just speech.",
                "Never trade lasting trust for a brief, dishonest advantage."
            ),
            practicalActivityUr = "آج کے پورے دن میں ہر گفتگو میں مبالغہ آرائی اور ادھورے سچ سے بچیں اور اپنے کیے ہوئے ہر وعدے کو پورا کریں۔",
            practicalActivityEn = "Avoid exaggeration and half-truths in every conversation today, and fulfill every small promise you make.",
            reflectionPromptUr = "کیا کوئی ایسا معاملہ یا وعدہ ہے جہاں مجھے آج سچ اور شفافیت اپنانے کی ضرورت ہے؟",
            reflectionPromptEn = "Is there a promise or situation in my life right now that needs greater honesty and transparency?",
            goodDeedChallengeUr = "آج کسی شخص کا کوئی بقایا حق، وعدہ یا امانت پوری دیانت سے ادا کریں۔",
            goodDeedChallengeEn = "Fulfill a pending promise, return a borrowed item, or settle a small obligation honestly today.",
            quiz = listOf(
                QuizQuestion("d3q1", "رسول اکرم ﷺ کو نبوت سے قبل کن القابات سے جانا جاتا تھا؟", "By what titles was the Prophet ﷺ known before Prophethood?", listOf("تاجر اور سیاح", "الصادق اور الامین", "شاعر اور خطیب", "سردار اور سپہ سالار"), listOf("Merchant and Traveler", "Al-Sadiq (Truthful) and Al-Amin (Trustworthy)", "Poet and Orator", "Chief and Commander"), 1, "آپ ﷺ کی سچائی اور امانت ہر خاص و عام میں مسلم تھی۔", "His truthfulness and trustworthiness were universally recognized."),
                QuizQuestion("d3q2", "سورۃ الاحزاب (33:70) میں کس بات کا حکم دیا گیا ہے؟", "What does Surah Al-Ahzab (33:70) command?", listOf("خاموش رہنے کا", "سیدھی اور سچی بات کہنے کا", "زیادہ بولنے کا", "بحث جیتنے کا"), listOf("Remaining silent always", "Speaking straight and truthful words", "Speaking excessively", "Winning debates"), 1, "قولِ سدید یعنی سیدھی، سچی اور درست بات کہنا ایمان کا تقاضا ہے۔", "Speaking straightforward truth is a direct Quranic command."),
                QuizQuestion("d3q3", "صحیح بخاری و مسلم کی حدیث کے مطابق سچائی کس چیز کی طرف لے جاتی ہے؟", "According to the Hadith, where does truthfulness lead?", listOf("نقصان کی طرف", "نیکی اور جنت کی طرف", "تنہائی کی طرف", "کمزوری کی طرف"), listOf("Loss", "Righteousness and Paradise", "Isolation", "Weakness"), 1, "سچائی نیکی کی کنجی اور جنت کا راستہ ہے۔", "Truthfulness leads to righteousness and Paradise."),
                QuizQuestion("d3q4", "کاروبار یا ملازمت میں دیانت داری کی مثال کیا ہے؟", "What is an example of honesty in work or trade?", listOf("عیب چھپانا", "وقتِ مقررہ اور معیار پورا کرنا", "غلط بل بنانا", "جھوٹا وعدہ کرنا"), listOf("Hiding defects", "Honoring agreed time and quality", "Inflating invoices", "Making false promises"), 1, "کام اور مال میں شفافیت دیانت کا عملی مظہر ہے۔", "Transparency and fulfilling commitments reflect true honesty."),
                QuizQuestion("d3q5", "جھوٹ کا سب سے بڑا نقصان کیا ہے؟", "What is a major harm of lying?", listOf("اعتماد ٹوٹتا ہے اور دل کا سکون جاتا ہے", "دوست بڑھتے ہیں", "رزق میں برکت آتی ہے", "عزت بڑھتی ہے"), listOf("It breaks trust and destroys inner peace", "It increases loyal friends", "It brings blessing", "It raises respect"), 0, "جھوٹ رشتوں اور دل کے اطمینان کو کھوکھلا کر دیتا ہے۔", "Dishonesty erodes trust and peace of heart.")
            )
        ),
        CuratedLesson(
            dayNumber = 4,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "islamic_character", "peace_tolerance"),
            titleUr = "جھوٹ، غیبت اور جھوٹے الزامات سے بچنا",
            titleEn = "Avoiding Lies, Backbiting and False Accusations",
            objectivesUr = listOf(
                "غیبت، چغلی اور بہتان کے معاشرتی نقصانات کو سمجھنا۔",
                "کسی غیر موجود شخص کے بارے میں بری بات کہنے اور سننے سے رکنا۔",
                "مصدقہ خبر کے بغیر کوئی بات آگے نہ پھیلانے کی عادت بنانا۔"
            ),
            objectivesEn = listOf(
                "Recognize the spiritual and social harm of backbiting, gossip, and slander.",
                "Refrain from speaking ill of or listening to attacks on absent people.",
                "Verify information before repeating or sharing it."
            ),
            introUr = "زبان کا غلط استعمال دلوں میں نفرت کے بیج بوتا اور ہنستے بستے گھروں اور دوستیوں کو توڑ دیتا ہے۔",
            introEn = "Careless speech plants resentment and fractures families, friendships, and entire communities.",
            explanationUr = "غیبت یہ ہے کہ آپ اپنے بھائی یا بہن کی غیر موجودگی میں ایسی بات کہیں جو اسے ناپسند ہو، چاہے وہ بات اس میں موجود ہی ہو۔ اور اگر وہ بات اس میں نہ ہو تو یہ 'بہتان' یعنی جھوٹا الزام ہے جو اور بھی بڑا گناہ ہے۔ قرآن کریم نے غیبت کو اپنے مردہ بھائی کا گوشت کھانے سے تشبیہ دی ہے تاکہ انسان اس کی قباحت محسوس کرے۔ آج کے دور میں واٹس ایپ، سوشل میڈیا اور محفلوں میں بغیر تصدیق بات آگے پھیلانا بہت عام ہو گیا ہے۔ مومن کی شان یہ ہے کہ وہ زبان اور انگلیوں کو دوسروں کی عزت بچانے کے لیے استعمال کرے، نہ کہ اچھالنے کے لیے۔",
            explanationEn = "Backbiting (Ghibah) is mentioning something about an absent person that they would dislike—even if it is true. If it is untrue, it becomes slander (Buhtan), an even graver wrong. The Quran compares backbiting to eating the flesh of one's deceased brother to awaken deep moral repulsion. In our digital era, forwarding unverified rumors causes immense harm. A person of faith guards both tongue and keyboard.",
            quranArabic = "وَلَا يَغْتَب بَّعْضُكُم بَعْضًا",
            quranTranslationUr = "اور تم میں سے کوئی کسی کی غیبت نہ کرے۔",
            quranTranslationEn = "And do not backbite one another.",
            quranRefUr = "سورۃ الحجرات 49:12",
            quranRefEn = "Surah Al-Hujurat 49:12",
            hadithTextUr = "آدمی کے جھوٹا ہونے کے لیے یہی کافی ہے کہ وہ ہر سنی سنائی بات بغیر تحقیق آگے بیان کر دے۔",
            hadithTextEn = "It is enough falsehood for a person to pass on everything they hear without verifying it.",
            hadithRefUr = "صحیح مسلم، مقدمہ، حدیث 5 (مستند)",
            hadithRefEn = "Sahih Muslim, Introduction, Hadith 5 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول یا گروپ چیٹ میں کسی ہم جماعت کا مذاق اڑانے یا افواہ فارورڈ کرنے کے بجائے موضوع بدل دینا۔",
            teenExampleEn = "Changing the topic or stepping away when classmates mock someone or spread rumors in a group chat.",
            youngAdultExampleUr = "یونیورسٹی یا سوشل میڈیا پر کسی کی ذاتی زندگی پر تبصرہ کرنے کے بجائے تحقیق شدہ اور مثبت بات شیئر کرنا۔",
            youngAdultExampleEn = "Refusing to share unverified gossip online and focusing discussions on ideas rather than personal attacks.",
            adultExampleUr = "خاندانی محفل میں جب کسی رشتہ دار کی برائی شروع ہو تو نرمی سے کہنا: 'اللہ ان کے لیے آسانی فرمائے، ہمیں ان کے حق میں دعا کرنی چاہیے'۔",
            adultExampleEn = "Gently redirecting family gatherings away from criticizing an absent relative by wishing them well instead.",
            keyLessonsUr = listOf(
                "غیبت اور جھوٹا الزام دلوں اور رشتوں کو تباہ کر دیتے ہیں۔",
                "بغیر تحقیق کے بات آگے پھیلانا جھوٹ میں شامل ہے۔",
                "کسی کی غیر موجودگی میں اس کی عزت کا دفاع کرنا بڑا اخلاق ہے۔"
            ),
            keyLessonsEn = listOf(
                "Backbiting and slander destroy trust and brotherhood.",
                "Repeating unverified rumors counts as spreading falsehood.",
                "Defending someone's dignity in their absence is noble character."
            ),
            practicalActivityUr = "آج کے دن اگر کسی محفل یا چیٹ میں کسی تیسرے شخص کی برائی شروع ہو تو گفتگو کو نرمی سے مثبت رخ دیں یا خاموشی سے کنارہ کر لیں۔",
            practicalActivityEn = "If anyone speaks negatively about an absent person today, gently steer the conversation to something positive or excuse yourself.",
            reflectionPromptUr = "کیا میں کبھی مذاق یا تبصرے کے نام پر غیبت میں شریک ہو جاتا ہوں؟ میں اسے کیسے روک سکتا ہوں؟",
            reflectionPromptEn = "Do I sometimes slip into backbiting disguised as casual chat or humor? How can I stop it?",
            goodDeedChallengeUr = "آج کسی ایسے شخص کی اچھی صفت کا ذکر کریں جس کے بارے میں لوگ عام طور پر تنقید کرتے ہیں۔",
            goodDeedChallengeEn = "Mention a genuine good quality of someone whom people around you often criticize.",
            quiz = listOf(
                QuizQuestion("d4q1", "غیبت کی درست تعریف کیا ہے؟", "What is the accurate definition of backbiting (Ghibah)?", listOf("منہ پر تعریف کرنا", "غیر موجودگی میں ایسی سچی بات کہنا جو اسے ناگوار گزرے", "نصیحت کرنا", "سلام کرنا"), listOf("Praising someone openly", "Mentioning something about an absent person they dislike", "Giving kind advice privately", "Greeting warmly"), 1, "غیبت سچی بات ہونے کے باوجود غیر موجود شخص کو ناگوار گزرنے والا تذکرہ ہے۔", "Ghibah is mentioning a flaw in someone's absence that they would dislike."),
                QuizQuestion("d4q2", "اگر کسی پر ایسی برائی کا الزام لگایا جائے جو اس میں نہ ہو تو اسے کیا کہتے ہیں؟", "What is it called if the accusation against someone is untrue?", listOf("نصیحت", "بہتان (جھوٹا الزام)", "مزاح", "مشورہ"), listOf("Advice", "Slander / False Accusation (Buhtan)", "Humor", "Counsel"), 1, "ناحق الزام لگانا بہتان اور سخت گناہ ہے۔", "Attributing an untrue fault to someone is slander (Buhtan)."),
                QuizQuestion("d4q3", "صحیح مسلم کے مطابق آدمی کے جھوٹا ہونے کے لیے کیا کافی ہے؟", "According to Sahih Muslim, what is enough to make a person a liar?", listOf("کم بولنا", "ہر سنی سنائی بات بغیر تحقیق آگے بیان کر دینا", "سوچ کر بولنا", "معافی مانگنا"), listOf("Speaking little", "Passing on everything heard without verification", "Thinking before speaking", "Apologizing"), 1, "بغیر تصدیق خبر یا افواہ پھیلانا جھوٹ کا ذریعہ بن جاتا ہے۔", "Sharing unverified claims makes one a carrier of falsehood."),
                QuizQuestion("d4q4", "سورۃ الحجرات (49:12) میں غیبت سے کس طرح منع کیا گیا ہے؟", "How does Surah Al-Hujurat (49:12) discourage backbiting?", listOf("اسے معمولی بات کہا", "اسے مردہ بھائی کا گوشت کھانے جیسا ناپسندیدہ قرار دیا", "صرف بڑوں کو منع کیا", "صرف رات کو منع کیا"), listOf("Called it minor", "Compared it to eating one's dead brother's flesh", "Restricted it to elders only", "Restricted it at night"), 1, "یہ مثال دل میں غیبت سے فطری نفرت پیدا کرنے کے لیے دی گئی ہے۔", "The vivid comparison teaches how deeply harmful backbiting is."),
                QuizQuestion("d4q5", "محفل میں غیبت روکنے کا بہترین طریقہ کیا ہے؟", "What is the best way to stop backbiting in a gathering?", listOf("خود بھی شریک ہو جانا", "نرمی سے موضوع بدل دینا یا اس شخص کی اچھائی بیان کرنا", "زور سے چیخنا", "افواہ لکھ لینا"), listOf("Join in silently", "Gently redirect the topic or mention their good qualities", "Shout angrily", "Record the rumor"), 1, "حکمت اور نرمی سے گفتگو کا رخ موڑنا سب سے مؤثر ہے۔", "Redirecting warmly and defending the absent person ends gossip gracefully.")
            )
        ),
        CuratedLesson(
            dayNumber = 5,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "islamic_character", "peace_tolerance"),
            titleUr = "غصے پر قابو پانا",
            titleEn = "Controlling Anger",
            objectivesUr = listOf(
                "طاقت کی اصل تعریف: جسمانی زور نہیں بلکہ غصے کے وقت خود پر قابو۔",
                "غصہ کم کرنے کے نبوی طریقے (اعوذ باللہ، خاموشی، حالت بدلنا، وضو) سیکھنا۔",
                "فیصلے اور جواب دینے سے پہلے 10 سیکنڈ توقف کرنے کی مشق کرنا۔"
            ),
            objectivesEn = listOf(
                "Learn that true strength is self-restraint during anger, not physical force.",
                "Apply Prophetic tools to calm anger: pause, seek refuge in Allah, sit down, or make wudu.",
                "Practice a 10-second pause before reacting in heated moments."
            ),
            introUr = "غصہ ایک لمحے کا شعلہ ہے جو سالوں کی محنت اور مضبوط رشتوں کو لمحوں میں جلا کر راکھ کر سکتا ہے۔",
            introEn = "Anger is a brief spark that can burn down years of trust and affection in seconds.",
            explanationUr = "ایک صحابی نے نبی کریم ﷺ سے مختصر اور جامع نصیحت مانگی تو آپ ﷺ نے فرمایا: 'غصہ نہ کرو' اور کئی بار یہی نصیحت دہرائی۔ غصہ انسانی فطرت میں موجود ہے، لیکن کامیاب انسان وہ ہے جو غصے کو اپنے اوپر سوار نہ ہونے دے۔ جب غصہ آئے تو فوراً سخت لفظ کہنے یا ہاتھ اٹھانے کے بجائے رک جائیں، خاموش رہیں، کھڑے ہیں تو بیٹھ جائیں، تعوذ پڑھیں اور پانی پی لیں یا وضو کر لیں۔ چند لمحوں کا صبر انسان کو عمر بھر کے پچھتاوے سے بچا لیتا ہے۔",
            explanationEn = "When a companion asked the Prophet ﷺ for concise life advice, he replied repeatedly: 'Do not get angry.' Feeling frustrated is human, but true strength lies in refusing to let anger dictate our words or hands. Prophetic wisdom teaches practical calming steps: stay silent, pause, change posture (sit down if standing), seek Allah's protection from rage, and cool off with water or wudu. Ten seconds of restraint prevent years of regret.",
            quranArabic = "وَالْكَاظِمِينَ الْغَيْظَ وَالْعَافِينَ عَنِ النَّاسِ ۗ وَاللَّهُ يُحِبُّ الْمُحْسِنِينَ",
            quranTranslationUr = "اور جو غصے کو پی جاتے ہیں اور لوگوں کو معاف کر دیتے ہیں، اور اللہ نیکی کرنے والوں سے محبت کرتا ہے۔",
            quranTranslationEn = "Those who restrain anger and pardon people—and Allah loves the doers of good.",
            quranRefUr = "سورۃ آل عمران 3:134",
            quranRefEn = "Surah Ali 'Imran 3:134",
            hadithTextUr = "پہلوان وہ نہیں جو کشتی میں کسی کو پچھاڑ دے، بلکہ اصل طاقتور وہ ہے جو غصے کے وقت اپنے آپ پر قابو رکھے۔",
            hadithTextEn = "The strong person is not the one who throws others down in wrestling; rather, the truly strong person controls themselves when angry.",
            hadithRefUr = "صحیح بخاری، حدیث 6114 / صحیح مسلم، حدیث 2609 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6114 / Sahih Muslim, Hadith 2609 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "کھیل یا آن لائن گیم میں ہارنے یا کسی دوست کے چڑانے پر فوراً گالی یا جھگڑے کے بجائے گہرا سانس لینا اور رک جانا۔",
            teenExampleEn = "Taking a slow breath and stepping back instead of snapping or insulting back when teased or losing a game.",
            youngAdultExampleUr = "ٹریفک جام یا گروپ پروجیکٹ میں کسی کی سستی پر چیخنے کے بجائے پرسکون لہجے میں حل کی بات کرنا۔",
            youngAdultExampleEn = "Responding calmly during traffic delays or team miscommunication instead of firing off an angry message.",
            adultExampleUr = "بچوں کی شرارت یا کام کی تھکن کے وقت فوراً ڈانٹنے کے بجائے چند سیکنڈ خاموش رہ کر پانی پینا اور نرمی سے سمجھانا۔",
            adultExampleEn = "Pausing for water and calm breathing after a tiring workday before addressing a child's mistake.",
            keyLessonsUr = listOf(
                "اصل بہادری غصے کے لمحے میں خود پر قابو رکھنا ہے۔",
                "غصے کی حالت میں بولے گئے الفاظ گہرے زخم دیتے ہیں۔",
                "خاموشی، حالت بدلنا اور وضو غصے کا بہترین علاج ہیں۔"
            ),
            keyLessonsEn = listOf(
                "True strength is mastering oneself under provocation.",
                "Words spoken in rage leave deep wounds long after anger fades.",
                "Silence, pausing, sitting down, and water quickly cool anger."
            ),
            practicalActivityUr = "آج جب بھی کسی بات پر جھنجھلاہٹ یا غصہ آئے تو جواب دینے سے پہلے آہستہ سے دل میں 10 تک گنتی گنیں اور 'أعوذ بالله من الشيطان الرجيم' پڑھیں۔",
            practicalActivityEn = "Whenever you feel irritated today, pause silently, count slowly to 10, and breathe before replying.",
            reflectionPromptUr = "مجھے سب سے زیادہ غصہ کس صورتحال میں آتا ہے اور میں اس کے لیے پہلے سے کیا تیاری کر سکتا ہوں؟",
            reflectionPromptEn = "What triggers my anger most often, and what calm habit can I prepare in advance?",
            goodDeedChallengeUr = "آج کسی ایسی بات کو مسکرا کر ٹال دیں جس پر عام طور پر آپ غصہ کر بیٹھتے ہیں۔",
            goodDeedChallengeEn = "Respond with calm patience today to a small annoyance that would usually irritate you.",
            quiz = listOf(
                QuizQuestion("d5q1", "حدیث نبوی ﷺ کے مطابق اصل طاقتور کون ہے؟", "According to the Hadith, who is truly strong?", listOf("جو کشتی جیتے", "جو غصے کے وقت اپنے نفس پر قابو رکھے", "جو اونچی آواز میں بولے", "جو کبھی معاف نہ کرے"), listOf("One who wins wrestling matches", "One who controls themselves when angry", "One who shouts loudest", "One who never forgives"), 1, "خود پر قابو رکھنا جسمانی طاقت سے بڑا کمال ہے۔", "Self-mastery in anger is greater than physical strength."),
                QuizQuestion("d5q2", "سورۃ آل عمران (3:134) میں غصہ پینے والوں کے بارے میں کیا فرمایا گیا؟", "What does Surah Ali 'Imran (3:134) say about those who restrain anger?", listOf("وہ کمزور ہیں", "اللہ ایسے نیکی کرنے والوں سے محبت کرتا ہے", "وہ نقصان میں ہیں", "انہیں بدلہ لینا چاہیے"), listOf("They are weak", "Allah loves those who do good", "They lose dignity", "They must retaliate"), 1, "غصہ ضبط کرنا اور درگزر کرنا اللہ کے محبوب بندوں کی صفت ہے۔", "Restraining anger and pardoning others are qualities Allah loves."),
                QuizQuestion("d5q3", "غصہ آنے پر کون سا عملی قدم مددگار ہوتا ہے؟", "Which practical step helps calm anger?", listOf("فوراً سخت میسج بھیجنا", "خاموش ہو جانا، بیٹھ جانا یا وضو کرنا", "آواز بلند کرنا", "دروازہ زور سے بند کرنا"), listOf("Sending an angry text right away", "Pausing in silence, sitting down, or making wudu", "Raising your voice", "Slamming a door"), 1, "حالت بدلنا اور ٹھنڈا پانی غصے کی شدت کم کر دیتا ہے۔", "Pausing, changing posture, and cooling down break the cycle of rage."),
                QuizQuestion("d5q4", "ایک صحابی کی مختصر نصیحت کی درخواست پر نبی کریم ﷺ نے کیا فرمایا؟", "What advice did the Prophet ﷺ repeat when asked for brief guidance?", listOf("زیادہ سفر کرو", "غصہ نہ کرو", "کم سویا کرو", "خاموش رہو"), listOf("Travel often", "Do not get angry", "Sleep less", "Never speak"), 1, "غصہ پر قابو پا لینے سے بے شمار اخلاقی برائیاں خود رک جاتی ہیں۔", "Avoiding anger prevents countless harms in speech and behavior."),
                QuizQuestion("d5q5", "غصے میں فیصلہ کرنے کا کیا نقصان ہوتا ہے؟", "What happens when decisions are made in anger?", listOf("فیصلہ بہتر ہوتا ہے", "پچھتاوے اور رشتوں کے ٹوٹنے کا خطرہ بڑھتا ہے", "وقت بچتا ہے", "انصاف بڑھتا ہے"), listOf("Decisions improve", "High risk of regret and broken relationships", "Time is saved", "Justice increases"), 1, "عقل اور انصاف سکون کے ماحول میں بہتر کام کرتے ہیں۔", "Wisdom and fairness require a calm heart.")
            )
        ),
        CuratedLesson(
            dayNumber = 6,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "peace_tolerance", "islamic_character"),
            titleUr = "صبر، برداشت اور درگزر",
            titleEn = "Patience, Tolerance and Forgiveness",
            objectivesUr = listOf(
                "صبر کا صحیح مفہوم: بے بسی نہیں بلکہ ثابت قدمی اور حوصلہ۔",
                "مختلف مزاج اور رائے رکھنے والوں کو برداشت کرنے کا ہنر سیکھنا۔",
                "دل کا بوجھ ہلکا کرنے کے لیے معاف کرنے کی برکت کو اپنانا۔"
            ),
            objectivesEn = listOf(
                "Understand patience (Sabr) as steady resilience rather than passive weakness.",
                "Practice tolerance toward people with different temperaments and viewpoints.",
                "Embrace forgiveness to free the heart from bitterness."
            ),
            introUr = "انسانوں کے ساتھ مل جل کر رہنے کے لیے صبر، حوصلہ اور معاف کرنے کا دل سب سے بڑی طاقت ہے۔",
            introEn = "Living peacefully with other imperfect human beings requires patience, forbearance, and a forgiving heart.",
            explanationUr = "اکثر لوگ صبر کو کمزوری سمجھ لیتے ہیں، حالانکہ صبر کا مطلب مشکل حالات میں ہمت نہ ہارنا، حق پر قائم رہنا اور تکلیف پہنچنے پر توازن نہ کھونا ہے۔ اسی طرح برداشت کا مطلب یہ ہے کہ ہر شخص آپ کے مزاج کے مطابق نہیں ہوگا؛ گھروں اور معاشروں میں امن تبھی رہتا ہے جب ہم دوسروں کی چھوٹی چھوٹی غلطیوں کو نظر انداز کرنا سیکھیں۔ معاف کر دینا سامنے والے سے زیادہ خود اپنے دل کو سکون دیتا ہے کیونکہ کینہ اور بدلے کی آگ سب سے پہلے انسان کے اپنے سکون کو جلاتی ہے۔",
            explanationEn = "Patience (Sabr) is often mistaken for helplessness, yet in Islamic character it means steadfastness, composure under pressure, and staying principled when tested. Tolerance recognizes that not everyone shares our temperament or pace. Forgiveness heals the forgiver's own heart even before it mends a relationship, releasing us from the heavy burden of resentment.",
            quranArabic = "فَاصْفَحِ الصَّفْحَ الْجَمِيلَ",
            quranTranslationUr = "پس آپ خوبصورت طریقے سے درگزر فرمائیں۔",
            quranTranslationEn = "So pardon them with gracious forgiveness.",
            quranRefUr = "سورۃ الحجر 15:85",
            quranRefEn = "Surah Al-Hijr 15:85",
            hadithTextUr = "صدقہ دینے سے مال کم نہیں ہوتا، اور معاف کرنے سے اللہ بندے کی عزت ہی بڑھاتا ہے۔",
            hadithTextEn = "Charity does not decrease wealth, and Allah only increases the honor of a servant who forgives.",
            hadithRefUr = "صحیح مسلم، حدیث 2588 (مستند)",
            hadithRefEn = "Sahih Muslim, Hadith 2588 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اگر کوئی دوست انجانے میں غلطی کرے یا گروپ میں غلط فہمی ہو جائے تو طعنہ دینے کے بجائے بات صاف کر کے معاف کر دینا۔",
            teenExampleEn = "Clearing up a misunderstanding with a classmate kindly instead of holding a grudge.",
            youngAdultExampleUr = "مشترکہ ہاسٹل یا کام کی جگہ پر ساتھیوں کی مختلف عادات کو صبر و تہذیب سے برداشت کرنا۔",
            youngAdultExampleEn = "Showing patience with roommates' or coworkers' differing habits while keeping respectful boundaries.",
            adultExampleUr = "کسی پرانی خاندانی ناراضگی کو دل میں پالنے کے بجائے پہل کر کے سلام کرنا اور معاف کر دینا۔",
            adultExampleEn = "Letting go of a long-standing family grudge and taking the first step with a warm greeting.",
            keyLessonsUr = listOf(
                "صبر ثابت قدمی اور حوصلے کا نام ہے، بزدلی کا نہیں۔",
                "معاف کرنے سے عزت کم نہیں ہوتی بلکہ اللہ عزت بڑھاتا ہے۔",
                "کینہ چھوڑ کر دل کو ہلکا اور پرسکون رکھا جا سکتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Patience is disciplined strength and resilience.",
                "Forgiveness raises dignity rather than diminishing it.",
                "Letting go of grudges brings immediate emotional peace."
            ),
            practicalActivityUr = "آج کسی ایسے شخص کے حق میں دل سے خیر کی دعا کریں جس سے ماضی میں آپ کو کوئی رنج پہنچا ہو۔",
            practicalActivityEn = "Make a sincere prayer for the well-being of someone who upset or disappointed you in the past.",
            reflectionPromptUr = "وہ کون سی چھوٹی ناراضگی ہے جسے اگر میں آج معاف کر دوں تو میرا دل ہلکا ہو جائے گا؟",
            reflectionPromptEn = "Which small grievance could I release today to feel lighter and more at peace?",
            goodDeedChallengeUr = "آج گھر یا کام کی جگہ پر کسی کی چھوٹی غلطی پر شکایت کرنے کے بجائے محبت سے درگزر کریں۔",
            goodDeedChallengeEn = "Overlook a minor mistake by someone at home or work today with kindness.",
            quiz = listOf(
                QuizQuestion("d6q1", "صحیح مسلم کی حدیث کے مطابق معاف کرنے سے بندے کا کیا بڑھتا ہے؟", "According to Sahih Muslim, what does Allah increase for one who forgives?", listOf("نقصان", "عزت", "خوف", "کمزوری"), listOf("Loss", "Honor and dignity", "Fear", "Weakness"), 1, "معاف کرنا بندے کو اللہ اور لوگوں کی نظر میں باعزت بناتا ہے۔", "Forgiveness increases honor and spiritual stature."),
                QuizQuestion("d6q2", "صبر کا اصل مفہوم کیا ہے؟", "What is the true meaning of Sabr (patience)?", listOf("کچھ نہ کرنا", "مشکل میں ہمت، توازن اور حق پر جمے رہنا", "غصہ دل میں رکھنا", "کمزور پڑ جانا"), listOf("Doing nothing", "Steadfastness, composure, and perseverance", "Hiding rage", "Giving up"), 1, "صبر شعوری ثابت قدمی اور مثبت حوصلے کا نام ہے۔", "Sabr is active resilience and moral steadiness."),
                QuizQuestion("d6q3", "سورۃ الحجر (15:85) میں کس قسم کے درگزر کا ذکر ہے؟", "What kind of forgiveness does Surah Al-Hijr (15:85) encourage?", listOf("طاقنہ دے کر معافی", "خوبصورت درگزر (الصفح الجميل)", "مجبوری کی معافی", "بدلے کے بعد معافی"), listOf("Grudging pardon", "Gracious, dignified forgiveness", "Forced apology", "Delayed revenge"), 1, "الصفح الجميل یعنی بغیر طعنے اور تلخی کے وقار سے معاف کرنا۔", "Al-Safh al-Jamil means pardoning gracefully without bitterness."),
                QuizQuestion("d6q4", "کینہ اور پرانی ناراضگی پالنے کا سب سے پہلا نقصان کسے ہوتا ہے؟", "Who suffers first when someone holds onto bitterness?", listOf("پڑوسی کو", "خود اپنے دل اور سکون کو", "معاشرے سے باہر لوگوں کو", "کسی کو نہیں"), listOf("Neighbors", "One's own heart and peace of mind", "Strangers", "No one"), 1, "تلخی سب سے پہلے دل کے اندر کا اطمینان چھینتی ہے۔", "Resentment harms the holder's own heart first."),
                QuizQuestion("d6q5", "معاشرے میں برداشت کیسے فروغ پاتی ہے؟", "How does tolerance grow in a community?", listOf("دوسروں کو ہر وقت ٹوک کر", "چھوٹی غلطیوں کو نظر انداز کر کے اور حوصلے سے سن کر", "بات چیت بند کر کے", "صرف اپنی بات منوا کر"), listOf("Constantly correcting everyone", "Overlooking minor flaws and listening patiently", "Cutting off dialogue", "Forcing one's own view"), 1, "حوصلہ اور درگزر سماجی ہم آہنگی پیدا کرتے ہیں۔", "Forbearance and patient listening nurture harmony.")
            )
        ),
        CuratedLesson(
            dayNumber = 7,
            weekNumber = 1,
            categoryIds = listOf("self_improvement", "quizzes_assessments"),
            titleUr = "ہفتہ وار جائزہ اور عملی امتحان",
            titleEn = "Weekly Review and Practical Assessment",
            objectivesUr = listOf(
                "ہفتہ اول (اصلاحِ نفس) کے چھ اسباق کا جامع اعادہ کرنا۔",
                "اپنی ہفتہ وار نیکیوں، سچائی اور غصے پر قابو کا جائزہ لینا۔",
                "اگلے ہفتے (خاندانی زندگی) کے لیے عملی عزم طے کرنا۔"
            ),
            objectivesEn = listOf(
                "Review all six Week 1 lessons on Self Improvement.",
                "Assess personal habits around intention, honesty, speech, and anger control.",
                "Set practical commitments before entering Week 2 on Family Life."
            ),
            introUr = "سیکھنے کا اصل فائدہ تب ہوتا ہے جب انسان ٹھہر کر دیکھے کہ علم نے اس کے عمل میں کتنی تبدیلی پیدا کی۔",
            introEn = "Knowledge bears fruit when we pause to measure how deeply it has shaped our daily habits.",
            explanationUr = "ہفتہ اول میں ہم نے اپنی ذات یعنی اصلاحِ نفس پر توجہ دی: زندگی کا مقصد، خود احتسابی، سچائی، غیبت سے بچاؤ، غصے پر قابو، اور صبر و درگزر۔ آج کے دن کوئی نیا بھاری سبق نہیں بلکہ پچھلے چھ دنوں کا پرامن جائزہ ہے۔ سوچیں کہ ان چھ دنوں میں آپ کی زبان، نیت اور صبر میں کیا بہتری آئی؟ اگر کسی جگہ کمزوری رہی ہو تو مایوس نہ ہوں؛ نیکی ایک مسلسل سفر ہے اور ہر نیا دن آغاز کا موقع ہے۔",
            explanationEn = "In Week 1, we focused on inner self-development: purpose, self-accountability, truthfulness, guarding the tongue, controlling anger, and practicing patience and forgiveness. Today is a peaceful checkpoint to look back over the past six days. Celebrate steady small wins and gently recommit wherever you slipped—character building is a lifelong journey, and every sunrise renews your chance.",
            quranArabic = "قَدْ أَفْلَحَ مَن زَكَّاهَا",
            quranTranslationUr = "یقیناً کامیاب ہوا وہ شخص جس نے اپنے نفس کو پاکیزہ بنایا۔",
            quranTranslationEn = "He has succeeded who purifies his soul.",
            quranRefUr = "سورۃ الشمس 91:9",
            quranRefEn = "Surah Ash-Shams 91:9",
            hadithTextUr = "اللہ تعالیٰ کے نزدیک سب سے پسندیدہ عمل وہ ہے جو ہمیشہ کیا جائے، خواہ وہ تھوڑا ہی کیوں نہ ہو۔",
            hadithTextEn = "The most beloved deeds to Allah are those done consistently, even if they are small.",
            hadithRefUr = "صحیح بخاری، حدیث 6464 / صحیح مسلم، حدیث 783 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6464 / Sahih Muslim, Hadith 783 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اپنے ہفتے کا جائزہ لینا کہ میں نے کتنی بار سچ بولا، ہوم ورک ایمانداری سے کیا، اور غصے پر قابو پایا۔",
            teenExampleEn = "Checking how consistently you spoke truthfully, studied honestly, and stayed calm this week.",
            youngAdultExampleUr = "دوستوں یا سوشل میڈیا کے رویے میں آنے والی مثبت تبدیلی نوٹ کرنا اور اگلے ہفتے کا ایک ہدف طے کرنا۔",
            youngAdultExampleEn = "Noting positive shifts in your digital habits and friendships, and setting one clear goal for next week.",
            adultExampleUr = "گھر والوں سے پوچھنا کہ کیا اس ہفتے میرے لہجے اور صبر میں کوئی خوشگوار فرق محسوس ہوا؟",
            adultExampleEn = "Asking a spouse or close family member if they noticed calmer patience in your tone this week.",
            keyLessonsUr = listOf(
                "تھوڑا مگر مستقل عمل اللہ کے نزدیک زیادہ محبوب ہے۔",
                "نفس کی پاکیزگی اور اصلاحِ نفس کامیابی کی کنجی ہے۔",
                "جائزہ لینا مستقبل کی بہتری کو آسان بناتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Small, consistent good habits are most beloved to Allah.",
                "Purifying and refining one's character is the path to real success.",
                "Regular self-review keeps momentum steady."
            ),
            practicalActivityUr = "ہفتہ اول کی تمام 6 عادات (نیت، محاسبہ، سچ، زبان کی حفاظت، غصے پر قابو، صبر) کو 1 سے 5 تک خود نمبر دیں اور سب سے کم نمبر والی عادت پر اگلے ہفتے توجہ دیں۔",
            practicalActivityEn = "Rate yourself 1–5 on the six Week 1 habits (intention, accountability, honesty, speech, anger, patience) and focus on your lowest one next week.",
            reflectionPromptUr = "ہفتہ اول کے کن سبق نے میرے دل پر سب سے گہرا اثر ڈالا اور کیوں؟",
            reflectionPromptEn = "Which Week 1 lesson left the deepest mark on my heart, and why?",
            goodDeedChallengeUr = "آج ہفتے کے اختتام پر کسی ایک قریبی فرد کا شکریہ ادا کریں اور اس کے لیے دعا کریں۔",
            goodDeedChallengeEn = "Thank someone close to you today for their kindness and pray for their well-being.",
            quiz = listOf(
                QuizQuestion("d7q1", "سورۃ الشمس (91:9) کے مطابق کون شخص کامیاب ہوا؟", "According to Surah Ash-Shams (91:9), who truly succeeds?", listOf("جو سب سے زیادہ مشہور ہو", "جس نے اپنے نفس کو پاکیزہ بنایا", "جو سب سے زیادہ بولے", "جو مقابلہ جیتے"), listOf("The most famous", "The one who purifies their soul", "The loudest speaker", "The wealthiest"), 1, "تزکیۂ نفس یعنی اخلاق و کردار کو سنوارنا اصل فلاح ہے۔", "Purifying one's soul and character brings true success."),
                QuizQuestion("d7q2", "حدیث کے مطابق اللہ کے نزدیک سب سے پسندیدہ عمل کون سا ہے؟", "Which deeds are most beloved to Allah according to the Hadith?", listOf("ایک دن بہت زیادہ مشقت اور پھر چھوڑ دینا", "تھوڑا مگر مستقل (مداومت والا) عمل", "صرف دکھاوے کا عمل", "صرف مہینے میں ایک بار عمل"), listOf("Intense effort once then quitting", "Consistent deeds, even if small", "Showy deeds", "Once a year only"), 1, "مستقل مزاجی کردار کو پختہ بناتی ہے۔", "Consistency builds lasting transformation."),
                QuizQuestion("d7q3", "ہفتہ اول کا مرکزی موضوع کیا تھا؟", "What was the main theme of Week 1?", listOf("سیاسی بحث", "اصلاحِ نفس", "تجارت کے اصول", "سفر کے آداب"), listOf("Politics", "Self Improvement", "Trade laws", "Travel etiquette"), 1, "اصلاحِ نفس کے بغیر خاندان اور معاشرے کی اصلاح ممکن نہیں۔", "Self improvement lays the foundation for family and society."),
                QuizQuestion("d7q4", "اگر پچھلے ہفتے کسی عادت میں کمی رہ جائے تو کیا کرنا چاہیے؟", "What should you do if you fell short on a habit during Week 1?", listOf("کورس چھوڑ دینا چاہیے", "مایوس ہوئے بغیر نئے عزم سے دوبارہ کوشش کرنی چاہیے", "دوسروں کو الزام دینا چاہیے", "سب کو بھول جانا چاہیے"), listOf("Quit the program", "Renew intention without despair and keep trying", "Blame others", "Ignore the habit"), 1, "اسلام امید اور توبہ کے ساتھ مسلسل کوشش سکھاتا ہے۔", "Islam teaches hopeful renewal and perseverance."),
                QuizQuestion("d7q5", "غصے اور غیبت پر قابو پانے سے کس چیز کی حفاظت ہوتی ہے؟", "Controlling anger and avoiding backbiting protects what?", listOf("صرف وقت", "رشتوں کا اعتماد اور دل کا سکون", "صرف پیسہ", "کوئی فائدہ نہیں"), listOf("Only time", "Trust in relationships and peace of heart", "Only money", "Nothing"), 1, "اچھا اخلاق دلوں کو جوڑتا اور گھر کو پرسکون بناتا ہے۔", "Good character protects trust and inner peace.")
            )
        )
    )
}

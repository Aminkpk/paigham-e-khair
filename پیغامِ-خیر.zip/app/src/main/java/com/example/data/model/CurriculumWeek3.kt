package com.example.data.model

object CurriculumWeek3 {
    val lessons: List<CuratedLesson> = listOf(
        CuratedLesson(
            dayNumber = 15,
            weekNumber = 3,
            categoryIds = listOf("unity_brotherhood", "islamic_character"),
            titleUr = "اسلامی بھائی چارہ اور باہمی احترام",
            titleEn = "Islamic Brotherhood and Mutual Respect",
            objectivesUr = listOf(
                "ایمان، انسانیت اور اخوتِ اسلامی کے عالمگیر رشتے کو سمجھنا۔",
                "رنگ، زبان، علاقے اور معاشی حیثیت کی بنیاد پر تعصب ختم کرنا۔",
                "مسلمانوں اور تمام انسانوں کے ساتھ خیر خواہی اور احترام کا رشتہ بنانا۔"
            ),
            objectivesEn = listOf(
                "Understand the universal bond of Islamic brotherhood and shared humanity.",
                "Reject prejudice based on ethnicity, language, region, or social class.",
                "Practice goodwill, loyalty, and mutual honor in everyday interactions."
            ),
            introUr = "اسلام نے بکھرے ہوئے قبائل اور طبقات کو ایک ایسی محبت بھری برادری میں جوڑا جہاں عزت کا معیار صرف تقویٰ اور اچھا کردار ہے۔",
            introEn = "Islam united divided tribes and social classes into one caring brotherhood where honor rests solely on character and righteousness.",
            explanationUr = "قرآن کریم اعلان کرتا ہے کہ سب مومن آپس میں بھائی بھائی ہیں، اور تمام انسان ایک ہی ماں باپ (حضرت آدمؑ و حواؑ) کی اولاد ہیں۔ علاقے، زبان، برادری یا دولت کا غرور جاہلیت کی نشانی ہے جسے نبی کریم ﷺ نے خطبہ حجۃ الوداع میں ہمیشہ کے لیے مٹا دیا۔ بھائی چارے کا تقاضا یہ ہے کہ ہم ایک دوسرے کی خوشی میں خوش ہوں، مشکل میں سہارا بنیں، اور زبان یا مزاج کی تفریق کے بغیر ہر شخص کو عزت دیں۔",
            explanationEn = "The Quran declares that believers are brothers and sisters to one another, and reminds all humanity that we share one origin. Pride of lineage, ethnicity, language, or wealth was abolished in the Prophet's ﷺ Farewell Sermon: no one is superior to another except through integrity and righteousness. Brotherhood means standing beside others in difficulty, celebrating their success without envy, and treating every person with dignity.",
            quranArabic = "إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ فَأَصْلِحُوا بَيْنَ أَخَوَيْكُمْ",
            quranTranslationUr = "بے شک تمام اہلِ ایمان آپس میں بھائی بھائی ہیں، پس اپنے دو بھائیوں کے درمیان صلح کراؤ۔",
            quranTranslationEn = "The believers are indeed brothers, so make peace between your brothers.",
            quranRefUr = "سورۃ الحجرات 49:10",
            quranRefEn = "Surah Al-Hujurat 49:10",
            hadithTextUr = "تم میں سے کوئی اس وقت تک کامل مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہی پسند نہ کرے جو اپنے لیے پسند کرتا ہے۔",
            hadithTextEn = "None of you truly believes until they love for their brother or sister what they love for themselves.",
            hadithRefUr = "صحیح بخاری، حدیث 13 / صحیح مسلم، حدیث 45 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 13 / Sahih Muslim, Hadith 45 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول میں کسی مختلف زبان یا علاقے سے آنے والے طالب علم کو الگ تھلگ نہ چھوڑنا بلکہ دوستی سے شامل کرنا۔",
            teenExampleEn = "Welcoming a student from a different region or background into your lunch or study group.",
            youngAdultExampleUr = "کیمپس یا کام کی جگہ پر علاقائی یا لسانی گروہ بندی سے دور رہ کر سب کے ساتھ عادلانہ اور دوستانہ رویہ رکھنا۔",
            youngAdultExampleEn = "Refusing ethnic or regional cliques on campus or at work and treating all peers warmly.",
            adultExampleUr = "محلے یا دفتر میں کسی کی کامیابی پر حسد کے بجائے مبارکباد دینا اور مشکل وقت میں بلا تعصب مدد کرنا۔",
            adultExampleEn = "Congratulating colleagues or neighbors sincerely on their success without envy and helping anyone in need.",
            keyLessonsUr = listOf(
                "عزت کا معیار نسل یا دولت نہیں بلکہ تقویٰ اور اچھا اخلاق ہے۔",
                "مؤمن دوسرے کے لیے بھی وہی بھلائی چاہتا ہے جو خود اپنے لیے چاہتا ہے۔",
                "لسانی اور علاقائی تعصب اتحاد کی سب سے بڑی رکاوٹ ہے۔"
            ),
            keyLessonsEn = listOf(
                "Honor is measured by integrity and character, never race or wealth.",
                "True faith means wanting for others the same good we want for ourselves.",
                "Tribal, ethnic, and class prejudice weakens unity."
            ),
            practicalActivityUr = "آج کسی ایسے واقف کار یا ہم وطن کو خلوص سے سلام اور دعا کا پیغام بھیجیں جو مختلف پس منظر یا علاقے سے ہو۔",
            practicalActivityEn = "Warmly greet and check in with a colleague, classmate, or neighbor from a different background today.",
            reflectionPromptUr = "کیا میرے دل میں کسی زبان، علاقے یا طبقے کے بارے میں کوئی پوشیدہ تعصب موجود ہے؟",
            reflectionPromptEn = "Do I hold any unspoken bias toward a particular region, language, or social group?",
            goodDeedChallengeUr = "آج کسی ایسے شخص کے لیے صدقِ دل سے خیر کی دعا کریں جس سے آپ کی ملاقات کم ہوتی ہے۔",
            goodDeedChallengeEn = "Pray sincerely for the success and peace of someone outside your usual circle today.",
            quiz = listOf(
                QuizQuestion("d15q1", "سورۃ الحجرات (49:10) کے مطابق تمام اہلِ ایمان کا باہمی رشتہ کیا ہے؟", "How does Surah Al-Hujurat (49:10) describe the bond among believers?", listOf("تجارتی رشتہ", "آپس میں بھائی چارے کا رشتہ", "مقابلے کا رشتہ", "رسمی رشتہ"), listOf("Business partners", "Brothers and sisters in faith", "Rivals", "Distant acquaintances"), 1, "قرآن اخوت کو ایمان کا بنیادی رشتہ قرار دیتا ہے۔", "The Quran establishes brotherhood as a core spiritual bond."),
                QuizQuestion("d15q2", "صحیح بخاری و مسلم کے مطابق کامل ایمان کی نشانی کیا ہے؟", "According to Bukhari & Muslim, what is a sign of complete faith?", listOf("صرف اپنی فکر کرنا", "اپنے بھائی کے لیے بھی وہی پسند کرنا جو اپنے لیے پسند ہو", "زیادہ بحث کرنا", "اپنے قبیلے کی تعریف کرنا"), listOf("Thinking only of oneself", "Loving for your brother what you love for yourself", "Arguing often", "Praising one's tribe"), 1, "ایثار اور خیر خواہی ایمان کی علامت ہے۔", "Empathy and goodwill for others define true faith."),
                QuizQuestion("d15q3", "اسلام میں فضیلت و برتری کا اصل معیار کیا ہے؟", "What is the true measure of honor in Islam?", listOf("رنگ و نسل", "تقویٰ اور اچھا کردار", "دولت", "شہرت"), listOf("Race or lineage", "Righteousness (Taqwa) and character", "Wealth", "Fame"), 1, "قرآن (49:13) کے مطابق سب سے معزز وہ ہے جو سب سے زیادہ پرہیزگار ہو۔", "Surah Al-Hujurat (49:13) places honor solely in Taqwa."),
                QuizQuestion("d15q4", "علاقائی یا لسانی تعصب کا معاشرے پر کیا اثر پڑتا ہے؟", "How do ethnic or regional prejudices affect society?", listOf("اتحاد مضبوط ہوتا ہے", "دلوں میں دوری اور انتشار پیدا ہوتا ہے", "ترقی تیز ہوتی ہے", "امن بڑھتا ہے"), listOf("Unity grows", "They divide hearts and weaken harmony", "Progress speeds up", "Peace increases"), 1, "تعصب بھائی چارے کو کمزور کر دیتا ہے۔", "Prejudice fractures mutual trust and peace."),
                QuizQuestion("d15q5", "بھائی چارے کا عملی اظہار کیا ہے؟", "What is a practical expression of brotherhood?", listOf("کسی کی غلطی کا انتظار کرنا", "خوشی میں مبارکباد اور مشکل میں مدد کرنا", "طنز کرنا", "الگ رہنا"), listOf("Waiting for someone to fail", "Sharing joy and helping in hardship", "Mocking", "Staying distant"), 1, "عمل کے بغیر بھائی چارے کا دعویٰ ادھورا رہتا ہے۔", "Brotherhood becomes real through active kindness and support.")
            )
        ),
        CuratedLesson(
            dayNumber = 16,
            weekNumber = 3,
            categoryIds = listOf("unity_brotherhood", "peace_tolerance"),
            titleUr = "اختلافِ رائے کا احترام",
            titleEn = "Respecting Differences of Opinion",
            objectivesUr = listOf(
                "سمجھنا کہ فکری و اجتہادی اختلاف انسانی فطرت اور علم کی وسعت کا حصہ ہے۔",
                "اختلاف کو ذاتی دشمنی یا تکفیر و تحقیر میں بدلنے سے بچنا۔",
                "ادب، دلیل اور سننے کے حوصلے کے ساتھ مکالمہ کرنا۔"
            ),
            objectivesEn = listOf(
                "Understand that respectful differences of opinion are natural and part of scholarship.",
                "Prevent intellectual disagreements from turning into personal hostility or insults.",
                "Practice listening attentively and speaking with courtesy and evidence."
            ),
            introUr = "مضبوط اور مہذب معاشرہ وہ نہیں جہاں سب ایک جیسا سوچیں، بلکہ وہ ہے جہاں لوگ مختلف سوچ کے باوجود ایک دوسرے کا احترام کریں۔",
            introEn = "A mature society is not one where everyone thinks identically, but one where people disagree without losing respect.",
            explanationUr = "اسلامی تاریخ میں فقہا اور علما کے درمیان فروعی مسائل میں اختلافِ رائے ہمیشہ رہا، مگر انہوں نے ایک دوسرے کے پیچھے نمازیں پڑھیں، ایک دوسرے کے لیے دعا کی اور علم کا احترام برقرار رکھا۔ ہر بات میں اپنی رائے کو واحد حق سمجھنا اور مخالف رائے رکھنے والے کی نیت پر شک کرنا فتنہ پیدا کرتا ہے۔ جب ہم کسی سے اختلاف کریں تو پہلے اس کی پوری بات غور سے سنیں، مشترکہ نکات تلاش کریں، اور اپنی بات نرمی سے پیش کریں—نہ کہ طنز اور الزام کے ساتھ۔",
            explanationEn = "Throughout Islamic history, great scholars differed on secondary juristic questions, yet prayed behind one another, honored each other's sincerity, and exchanged ideas with humility. Trouble begins when we mistake our personal opinion for absolute truth and attack the intentions of those who disagree. Listening fairly, finding shared ground, and expressing views gently protect unity even during disagreement.",
            quranArabic = "ادْعُ إِلَىٰ سَبِيلِ رَبِّكَ بِالْحِكْمَةِ وَالْمَوْعِظَةِ الْحَسَنَةِ ۖ وَجَادِلْهُم بِالَّتِي هِيَ أَحْسَنُ",
            quranTranslationUr = "اپنے رب کے راستے کی طرف حکمت اور عمدہ نصیحت کے ساتھ بلائیے، اور ان سے بحث (مکالمہ) بہترین طریقے سے کیجیے۔",
            quranTranslationEn = "Invite to the way of your Lord with wisdom and good instruction, and argue with them in a way that is best.",
            quranRefUr = "سورۃ النحل 16:125",
            quranRefEn = "Surah An-Nahl 16:125",
            hadithTextUr = "آسانی پیدا کرو اور تنگی نہ ڈالو، خوشخبری سناؤ اور نفرت نہ پھیلاؤ۔",
            hadithTextEn = "Make things easy and do not make them difficult; give glad tidings and do not drive people away.",
            hadithRefUr = "صحیح بخاری، حدیث 69 / صحیح مسلم، حدیث 1734 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 69 / Sahih Muslim, Hadith 1734 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "دوستوں کے درمیان کھیل، پڑھائی یا کسی رائے پر اختلاف ہو تو مذاق اڑانے یا چیخنے کے بجائے باری باری بات سننا۔",
            teenExampleEn = "Taking turns listening when friends disagree on a class project or sport instead of shouting or mocking.",
            youngAdultExampleUr = "کیمپس یا آن لائن بحث میں مخالف رائے رکھنے والے کے الفاظ کا وقار سے جواب دینا اور ذاتی حملے سے بچنا۔",
            youngAdultExampleEn = "Addressing ideas rather than attacking individuals during campus or online discussions.",
            adultExampleUr = "گھریلو یا محلے کی کمیٹی کے مشورے میں اپنی بات منوانے کی ضد کے بجائے اجتماعی بھلائی کو ترجیح دینا۔",
            adultExampleEn = "Putting community harmony ahead of personal ego during family or neighborhood consultations.",
            keyLessonsUr = listOf(
                "گفتگو اور مکالمے میں بہترین اور شائستہ اسلوب اپنانا قرآنی حکم ہے۔",
                "رائے کا اختلاف دشمنی کا سبب نہیں بننا چاہیے۔",
                "نفرت پھیلانے کے بجائے آسانی اور خیر خواہی کی فضا بنانا سنت ہے۔"
            ),
            keyLessonsEn = listOf(
                "Wisdom and courteous dialogue are Quranic commands.",
                "Differences of opinion must never turn into hatred or hostility.",
                "Making things easy and welcoming rather than alienating is the Prophetic way."
            ),
            practicalActivityUr = "آج کسی گفتگو میں اگر سامنے والے کی رائے آپ سے مختلف ہو تو ٹوکے بغیر اس کی بات مکمل سنیں اور مشترکہ نکتے کی تائید کریں۔",
            practicalActivityEn = "In any disagreement today, let the other person finish speaking without interruption and affirm one point you agree on.",
            reflectionPromptUr = "بحث کے دوران میں کس حد تک سامنے والے کی بات سمجھنے کی کوشش کرتا ہوں بمقابلہ صرف جواب دینے کی جلدی کے؟",
            reflectionPromptEn = "During disagreements, do I listen to understand, or only wait for my turn to argue?",
            goodDeedChallengeUr = "آج کسی ایسے شخص سے شائستگی سے بات کریں جس سے آپ کے خیالات عموماً مختلف ہوتے ہیں۔",
            goodDeedChallengeEn = "Have a warm, respectful conversation today with someone who holds different views from yours.",
            quiz = listOf(
                QuizQuestion("d16q1", "سورۃ النحل (16:125) میں دعوت اور مکالمے کا کیا طریقہ بتایا گیا ہے؟", "What method of dialogue does Surah An-Nahl (16:125) prescribe?", listOf("سختی اور غصہ", "حکمت، عمدہ نصیحت اور بہترین اندازِ گفتگو", "مذاق اڑانا", "بائیکاٹ کرنا"), listOf("Harshness", "Wisdom, good instruction, and the best manner of dialogue", "Mockery", "Boycotting"), 1, "قرآن حکمت اور بہترین اسلوب کو مکالمے کی بنیاد بناتا ہے۔", "Wisdom and courteous dialogue are mandatory in Quranic guidance."),
                QuizQuestion("d16q2", "حدیث میں لوگوں سے پیش آنے کا کیا اصول بتایا گیا ہے؟", "What principle does the Hadith teach for dealing with people?", listOf("تنگی ڈالو", "آسانی پیدا کرو اور نفرت نہ پھیلاؤ", "ہر کسی پر تنقید کرو", "صرف اپنے گروہ سے ملو"), listOf("Create hardship", "Make things easy and do not alienate people", "Criticize everyone", "Stay isolated"), 1, "آسانی اور خوشخبری دلوں کو جوڑتی ہے۔", "Ease and encouragement win hearts and prevent alienation."),
                QuizQuestion("d16q3", "اختلافِ رائے کی صحت مند علامت کیا ہے؟", "What is a healthy sign during a difference of opinion?", listOf("ذاتی حملے کرنا", "دوسرے کی بات توجہ سے سننا اور عزت برقرار رکھنا", "نیتوں پر شک کرنا", "الزام لگانا"), listOf("Personal insults", "Listening carefully and preserving mutual dignity", "Judging intentions", "False accusations"), 1, "خیالات پر گفتگو ہو، انسان کی عزت پر حملہ نہ ہو۔", "Debate ideas respectfully without attacking human dignity."),
                QuizQuestion("d16q4", "اسلاف اور ائمہ کرام نے آپس کے علمی اختلافات کو کیسے نبھایا؟", "How did classical Islamic scholars handle juristic differences?", listOf("ایک دوسرے سے بول چال بند کر کے", "باہمی احترام، دعا اور ادب برقرار رکھ کر", "جھگڑے کر کے", "مساجد الگ کر کے"), listOf("Cutting off contact", "With mutual respect, prayer, and humility", "Fighting", "Splitting communities"), 1, "علمی وسعت ادب اور برداشت سکھاتی ہے۔", "True scholarship fosters humility and mutual respect."),
                QuizQuestion("d16q5", "اگر کسی گفتگو میں تلخی بڑھنے لگے تو بہتر قدم کیا ہے؟", "If a discussion begins turning bitter, what is the wisest step?", listOf("مزید طنز کرنا", "نرمی سے بحث روک کر احترام کے ساتھ موضوع بدل دینا", "آواز تیز کرنا", "گروپ میں شیئر کرنا"), listOf("Add sarcasm", "Calmly pause the debate and preserve goodwill", "Shout louder", "Post screenshots"), 1, "دل ٹوٹنے سے بچانا بحث جیتنے سے زیادہ قیمتی ہے۔", "Protecting hearts matters more than winning an argument.")
            )
        ),
        CuratedLesson(
            dayNumber = 17,
            weekNumber = 3,
            categoryIds = listOf("unity_brotherhood", "peace_tolerance"),
            titleUr = "فرقہ وارانہ نفرت اور مذہبی انتہا پسندی سے بچنا",
            titleEn = "Avoiding Sectarian Hatred and Religious Extremism",
            objectivesUr = listOf(
                "تفرقہ بازی کے قرآنی ممانعت اور امت کے اتحاد کی اہمیت سمجھنا۔",
                "دین میں توازن، اعتدال اور رحمت کو انتہا پسندی کے مقابلے میں پہچاننا۔",
                "نفرت انگیز نعروں، تکفیر بازی اور اشتعال انگیز مواد سے دور رہنا۔"
            ),
            objectivesEn = listOf(
                "Understand the clear Quranic prohibition against sectarianism and division.",
                "Recognize balance, mercy, and moderation as core traits of Islam against extremism.",
                "Reject divisive slogans, hateful labeling, and provocative content."
            ),
            introUr = "اسلام امن، رحمت اور اعتدال کا دین ہے؛ فرقہ واریت اور انتہا پسندی اس کی اصل روح کے منافی ہیں۔",
            introEn = "Islam is a faith of mercy, balance, and unity; sectarian hatred and extremism contradict its very essence.",
            explanationUr = "قرآن کریم صاف حکم دیتا ہے کہ سب مل کر اللہ کی رسی کو مضبوطی سے تھام لو اور تفرقے میں نہ پڑو۔ نبی کریم ﷺ نے دین میں غلو (حد سے تجاوز اور سختی) سے بار بار خبردار فرمایا کیونکہ اسی شدت نے پچھلی قوموں کو تباہ کیا۔ کسی مسلمان کو کافر قرار دینا (تکفیر)، مساجد یا عبادت گاہوں کے خلاف نفرت پھیلانا، یا کسی مسلک کی تضحیک کرنا معاشرے کو کمزور اور بدامن بناتا ہے۔ سچا دین دلوں میں اللہ کا خوف، مخلوق کے لیے رحمت اور تمام شہریوں کے لیے امن پیدا کرتا ہے۔",
            explanationEn = "The Quran commands believers to hold fast together to the rope of Allah and not be divided into warring sects. The Prophet ﷺ repeatedly warned against extremism and excess in religion, noting that extremism ruined earlier nations. Labeling others as unbelievers, mocking religious schools, or spreading sectarian hostility destroys peace and weakens society. Authentic Islam nurtures humility before Allah and mercy toward all creation.",
            quranArabic = "وَاعْتَصِمُوا بِحَبْلِ اللَّهِ جَمِيعًا وَلَا تَفَرَّقُوا",
            quranTranslationUr = "اور سب مل کر اللہ کی رسی (قرآن و دین) کو مضبوطی سے تھام لو اور تفرقے میں نہ پڑو۔",
            quranTranslationEn = "And hold firmly to the rope of Allah all together and do not become divided.",
            quranRefUr = "سورۃ آل عمران 3:103",
            quranRefEn = "Surah Ali 'Imran 3:103",
            hadithTextUr = "دین میں غلو (حد سے بڑھنے اور انتہا پسندی) سے بچو، کیونکہ تم سے پہلے لوگوں کو دین میں غلو ہی نے ہلاک کیا۔",
            hadithTextEn = "Beware of extremism in religion, for those before you were destroyed by nothing other than extremism in religion.",
            hadithRefUr = "سنن نسائی، حدیث 3057 / مسند احمد (مستند)",
            hadithRefEn = "Sunan an-Nasa'i, Hadith 3057 / Musnad Ahmad (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اگر آن لائن کوئی نفرت انگیز یا فرقہ وارانہ ویڈیو یا میم نظر آئے تو اسے لائک یا شیئر نہ کرنا بلکہ رپورٹ یا نظر انداز کرنا۔",
            teenExampleEn = "Refusing to like, laugh at, or share sectarian memes or hateful videos online, and reporting harmful posts.",
            youngAdultExampleUr = "دینی علم معتبر علما اور مستند کتابوں سے سیکھنا، نہ کہ سوشل میڈیا کے اشتعال انگیز کلپس سے۔",
            youngAdultExampleEn = "Seeking religious knowledge from balanced, credible scholarship rather than angry social media clips.",
            adultExampleUr = "اپنے بچوں اور محلے کے نوجوانوں کو تمام مکاتبِ فکر کے احترام اور قومی و سماجی اتحاد کی تربیت دینا۔",
            adultExampleEn = "Teaching children and neighborhood youth to respect fellow citizens across schools of thought and protect communal peace.",
            keyLessonsUr = listOf(
                "تفرقہ بازی قرآنی حکم کے خلاف اور امت کی کمزوری کا سبب ہے۔",
                "دین میں اعتدال اور توازن کامیابی کا راستہ ہے، غلو ہلاکت ہے۔",
                "نفرت انگیز مواد نہ خود پھیلائیں اور نہ دوسروں کی حوصلہ افزائی کریں۔"
            ),
            keyLessonsEn = listOf(
                "Sectarian division violates explicit Quranic guidance.",
                "Moderation and mercy represent true Islam; extremism leads to ruin.",
                "Never amplify sectarian insults or provocative misinformation."
            ),
            practicalActivityUr = "آج اپنے فون یا سوشل میڈیا فیڈ کا جائزہ لیں اور کسی بھی ایسے اکاؤنٹ یا گروپ کو چھوڑ دیں جو نفرت یا فرقہ واریت پھیلاتا ہو۔",
            practicalActivityEn = "Audit your social feeds today and unfollow or mute any page or group that spreads sectarian hostility.",
            reflectionPromptUr = "میں اپنے گھر اور حلقۂ احباب میں اتحاد اور اعتدال کی آواز کیسے بن سکتا ہوں؟",
            reflectionPromptEn = "How can I be a calm voice for unity and moderation among my friends and family?",
            goodDeedChallengeUr = "آج مسلمانوں اور تمام انسانوں کے درمیان امن، اتحاد اور باہمی محبت کے لیے دل سے دعا کریں۔",
            goodDeedChallengeEn = "Offer a sincere prayer today for unity, peace, and mutual compassion in society.",
            quiz = listOf(
                QuizQuestion("d17q1", "سورۃ آل عمران (3:103) میں امت کو کس بات کا حکم دیا گیا ہے؟", "What does Surah Ali 'Imran (3:103) command?", listOf("الگ الگ گروہ بنانے کا", "سب مل کر اللہ کی رسی تھامنے اور تفرقے سے بچنے کا", "صرف اپنے قبیلے کے ساتھ رہنے کا", "مقابلہ کرنے کا"), listOf("Forming rival groups", "Holding fast together to Allah's rope and avoiding division", "Staying isolated", "Competing bitterly"), 1, "اتحاد اور تفرقے سے گریز قرآن کا واضح پیغام ہے۔", "Unity and avoiding division are direct Quranic mandates."),
                QuizQuestion("d17q2", "حدیث میں کس چیز کو پچھلی قوموں کی ہلاکت کا سبب بتایا گیا؟", "What did the Hadith warn destroyed previous nations?", listOf("علم سیکھنا", "دین میں غلو (انتہا پسندی)", "نرمی کرنا", "تجارت کرنا"), listOf("Seeking knowledge", "Extremism and excess in religion", "Showing gentleness", "Honest trade"), 1, "دین میں اعتدال اور حکمت ہی درست راہ ہے۔", "Moderation protects faith; extremism corrupts it."),
                QuizQuestion("d17q3", "آن لائن فرقہ وارانہ یا نفرت انگیز مواد دیکھ کر ذمہ دارانہ ردعمل کیا ہے؟", "What is the responsible response to sectarian hate online?", listOf("آگے فارورڈ کرنا", "شیئر کرنے سے رکنا اور ضرورت پر رپورٹ کرنا", "گالی دے کر جواب دینا", "مذاق اڑانا"), listOf("Forwarding it", "Refusing to share and reporting harmful content", "Replying with insults", "Mocking"), 1, "نفرت کی زنجیر کو توڑنا ہر شہری کی ذمہ داری ہے۔", "Breaking the chain of hate protects everyone."),
                QuizQuestion("d17q4", "اسلام کی بنیادی صفت کیا ہے؟", "What is the foundational character of Islamic guidance?", listOf("انتقام", "رحمت، عدل اور اعتدال", "تشدد", "تعصب"), listOf("Revenge", "Mercy, justice, and balance", "Violence", "Prejudice"), 1, "رسول اکرم ﷺ کو تمام جہانوں کے لیے رحمت بنا کر بھیجا گیا۔", "The Prophet ﷺ was sent as a mercy to all worlds."),
                QuizQuestion("d17q5", "دینی معاملات میں معلومات حاصل کرنے کا محفوظ طریقہ کیا ہے؟", "What is the safest way to learn religious guidance?", listOf("بے نام اشتعال انگیز کلپس", "معتبر قرآن و سنت اور متوازن علما سے", "افواہوں سے", "سیاسی نعروں سے"), listOf("Anonymous angry clips", "Verified Quran, Sunnah, and balanced scholarship", "Rumors", "Partisan slogans"), 1, "تحقیق اور معتبر علم انتہا پسندی سے بچاتا ہے۔", "Sound, verified scholarship protects against extremism.")
            )
        ),
        CuratedLesson(
            dayNumber = 18,
            weekNumber = 3,
            categoryIds = listOf("peace_tolerance", "unity_brotherhood"),
            titleUr = "معافی اور صلح صفائی",
            titleEn = "Forgiveness and Reconciliation",
            objectivesUr = listOf(
                "بڑوں یا دوستوں کے درمیان صلح کرانے (اصلاحِ ذات البین) کی عظیم فضیلت جاننا۔",
                "خود بھی معاف کرنے اور ناراض افراد کو جوڑنے کا ہنر سیکھنا۔",
                "ناراضگی میں تین دن سے زیادہ قطع تعلقی سے بچنا۔"
            ),
            objectivesEn = listOf(
                "Learn the immense merit of reconciling people and healing broken ties.",
                "Develop practical skills for mediating calmly without taking unfair sides.",
                "Avoid prolonged estrangement beyond temporary cooling-off."
            ),
            introUr = "دو ٹوٹے ہوئے دلوں کو جوڑ دینا ان نیکیوں میں سے ہے جن کا اجر نفلی عبادتوں سے بھی بڑھ کر بیان ہوا ہے۔",
            introEn = "Reconciling two estranged people is praised in Islam as a deed of extraordinary spiritual weight.",
            explanationUr = "جب دو افراد، بھائیوں یا خاندانوں میں جھگڑا ہو جائے تو اکثر لوگ تماشا دیکھتے ہیں یا ایک کی بات دوسرے کو بتا کر آگ مزید بھڑکاتے ہیں۔ اسلام اس کے بالکل الٹ سکھاتا ہے: مومن آگ بجھانے والا ہوتا ہے، بھڑکانے والا نہیں۔ نبی کریم ﷺ نے فرمایا کہ لوگوں کے درمیان صلح کرا دینا نفل نماز، روزے اور صدقے کے درجے سے بھی افضل ہے۔ صلح کرانے کا طریقہ یہ ہے کہ دونوں کی بات امانت داری سے سنی جائے، غلط فہمیاں دور کی جائیں اور دلوں کو قریب لایا جائے۔",
            explanationEn = "When two friends or relatives fall out, spectators often fuel the fire by carrying harsh remarks back and forth. Islam teaches the exact opposite: a believer is a peacemaker, not an instigator. The Prophet ﷺ taught that reconciling people surpasses voluntary prayer, fasting, and charity in merit. True reconciliation listens fairly to both sides, clears misunderstandings, highlights shared care, and restores dignity without humiliation.",
            quranArabic = "فَمَنْ عَفَا وَأَصْلَحَ فَأَجْرُهُ عَلَى اللَّهِ",
            quranTranslationUr = "پھر جو کوئی معاف کر دے اور صلح (اصلاح) کر لے تو اس کا اجر اللہ کے ذمے ہے۔",
            quranTranslationEn = "Whoever pardons and makes reconciliation—their reward is with Allah.",
            quranRefUr = "سورۃ الشوریٰ 42:40",
            quranRefEn = "Surah Ash-Shura 42:40",
            hadithTextUr = "کسی مسلمان کے لیے جائز نہیں کہ اپنے بھائی سے تین دن سے زیادہ بول چال بند رکھے؛ ان دونوں میں بہتر وہ ہے جو سلام میں پہل کرے۔",
            hadithTextEn = "It is not lawful for a Muslim to sever ties with their brother for more than three days; the better of the two is the one who initiates the greeting.",
            hadithRefUr = "صحیح بخاری، حدیث 6077 / صحیح مسلم، حدیث 2560 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6077 / Sahih Muslim, Hadith 2560 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "جب دو دوست آپس میں ناراض ہوں تو چغلی کرنے کے بجائے دونوں کو ایک دوسرے کی اچھی بات یاد دلا کر صلح کرا دینا۔",
            teenExampleEn = "Helping two upset classmates cool down and clear a misunderstanding instead of taking sides or gossiping.",
            youngAdultExampleUr = "تین دن گزرنے سے پہلے کسی ناراض دوست کو خود سلام یا سادہ پیغام بھیج کر برف پگھلا دینا۔",
            youngAdultExampleEn = "Sending a simple, warm greeting before three days pass to heal a rift with a friend.",
            adultExampleUr = "خاندان یا دفتر کے دو ساتھیوں کے درمیان غیر جانبدار اور مخلص ثالث بن کر باوقار صلح کرانا۔",
            adultExampleEn = "Acting as a fair, discreet peacemaker to resolve a tension between relatives or coworkers.",
            keyLessonsUr = listOf(
                "معافی اور صلح کا اجر براہِ راست اللہ کے ذمے ہے۔",
                "تین دن سے زیادہ قطع تعلقی جائز نہیں؛ سلام میں پہل کرنے والا بہتر ہے۔",
                "دو لوگوں میں صلح کرانا بہت بڑی سماجی نیکی ہے۔"
            ),
            keyLessonsEn = listOf(
                "Pardoning and reconciling carry a direct reward from Allah.",
                "Never let estrangement drag beyond three days; initiating greeting is noblest.",
                "Peacemaking heals entire families and communities."
            ),
            practicalActivityUr = "آج کسی ایک پرانی ناراضگی کو ختم کرنے کے لیے سلام یا خیر خواہی کا پہلا قدم اٹھائیں، یا دو ناراض افراد کے درمیان صلح کی کوشش کریں۔",
            practicalActivityEn = "Take the first step to soften a strained tie with a kind greeting, or help two people reconcile peacefully.",
            reflectionPromptUr = "کیا میں کسی جھگڑے میں آگ بجھانے والا بنتا ہوں یا بے خبری میں بات بڑھا دیتا ہوں؟",
            reflectionPromptEn = "When conflict arises around me, do I act as a peacemaker or accidentally amplify tension?",
            goodDeedChallengeUr = "آج سلام میں پہل کریں—چاہے کسی ایسے فرد سے ہی کیوں نہ ہو جس سے کچھ سرد مہری چل رہی ہو۔",
            goodDeedChallengeEn = "Initiate a warm greeting today, especially with someone with whom things felt distant.",
            quiz = listOf(
                QuizQuestion("d18q1", "سورۃ الشوریٰ (42:40) کے مطابق معاف کر کے صلح کرنے والے کا اجر کس پر ہے؟", "According to Surah Ash-Shura (42:40), who rewards the one who pardons and reconciles?", listOf("صرف عدالت پر", "اللہ تعالیٰ کے ذمے", "معاشرے پر", "کسی پر نہیں"), listOf("Courts only", "Allah Himself", "Society", "No one"), 1, "معاف کر کے اصلاح کرنے والے کو اللہ خود عظیم اجر دیتا ہے۔", "Allah personally guarantees the reward for forgiveness and reconciliation."),
                QuizQuestion("d18q2", "دو ناراض افراد میں سے زیادہ بہتر کون ہے؟", "Between two estranged people, who is better according to the Hadith?", listOf("جو زیادہ ضد کرے", "جو سلام کرنے میں پہل کرے", "جو شکایت کرے", "جو سب کو بتائے"), listOf("The more stubborn one", "The one who initiates the greeting first", "The one who complains", "The one who gossips"), 1, "سلام میں پہل کرنا عاجزی اور اعلیٰ ظرفی کی نشانی ہے۔", "Initiating peace shows courage and nobility."),
                QuizQuestion("d18q3", "مسلمان کے لیے کتنے دن سے زیادہ قطع تعلقی (بول چال بند کرنا) منع ہے؟", "Beyond how many days is cutting off speaking terms forbidden?", listOf("30 دن", "3 دن", "1 سال", "7 دن"), listOf("30 days", "3 days", "1 year", "7 days"), 1, "تین دن کی حد انسان کو غصہ ٹھنڈا کر کے صلح کا موقع دیتی ہے۔", "The three-day limit gives space to cool down without letting bitterness harden."),
                QuizQuestion("d18q4", "صلح کرانے والے کا درست کردار کیا ہے؟", "What is the proper role of a peacemaker?", listOf("ایک کی برائی دوسرے کو بتانا", "دونوں کی بات انصاف سے سن کر دلوں کو قریب لانا", "ایک طرف کی حمایت کرنا", "الزام لگانا"), listOf("Repeating insults", "Listening fairly and bringing hearts together", "Taking unfair sides", "Blaming"), 1, "عدل اور خیر خواہی کامیاب صلح کی بنیاد ہیں۔", "Fairness and sincerity make reconciliation lasting."),
                QuizQuestion("d18q5", "دو لوگوں میں صلح کرانے کا درجہ حدیث میں کیسا بتایا گیا ہے؟", "How is reconciling people ranked in Hadith?", listOf("معمولی کام", "نفلی نماز، روزے اور صدقے سے بھی افضل درجے کا عمل", "وقت کا ضیاع", "صرف بڑوں کا کام"), listOf("Minor act", "Surpassing voluntary prayer, fasting, and charity in merit", "Waste of time", "Only for elders"), 1, "جامع ترمذی و ابو داؤد میں صلح کرانے کو عظیم عبادت قرار دیا گیا ہے۔", "Healing rifts is honored as one of the highest charitable deeds.")
            )
        ),
        CuratedLesson(
            dayNumber = 19,
            weekNumber = 3,
            categoryIds = listOf("peace_tolerance", "social_reform"),
            titleUr = "تشدد، قتل اور انتقام کو مسترد کرنا",
            titleEn = "Rejecting Violence, Murder and Revenge",
            objectivesUr = listOf(
                "انسانی جان کی حرمت اور بے گناہ قتل کی سنگینی کو قرآنی روشنی میں سمجھنا۔",
                "قانون ہاتھ میں لینے (vigilantism) اور خاندانی یا قبائلی انتقام کی مذمت۔",
                "عدالت، قانون اور پرامن انصاف پر اعتماد کی اہمیت جاننا۔"
            ),
            objectivesEn = listOf(
                "Understand the absolute sanctity of human life in the Quran.",
                "Reject vigilantism, mob justice, domestic abuse, and cycles of revenge.",
                "Support lawful justice and peaceful protection of human life."
            ),
            introUr = "اسلام میں انسانی جان کی حرمت کعبہ کی حرمت سے بھی زیادہ قیمتی قرار دی گئی ہے؛ تشدد اور انتقام کسی مسئلے کا حل نہیں۔",
            introEn = "Islam upholds the sanctity of human life as sacred; violence, abuse, and revenge only multiply tragedy.",
            explanationUr = "قرآن کریم کا یہ عالمگیر اصول پوری انسانیت کے لیے منشورِ امن ہے کہ جس نے ایک بے گناہ انسان کو قتل کیا گویا اس نے پوری انسانیت کو قتل کیا، اور جس نے ایک جان بچائی گویا اس نے پوری انسانیت کو بچا لیا۔ اسلام نہ صرف قتل بلکہ گھریلو تشدد، بدمعاشی، ہجوم کے تشدد (mob violence) اور ذاتی انتقام کو بھی سختی سے حرام قرار دیتا ہے۔ انصاف کا اختیار افراد کے پاس نہیں بلکہ باقاعدہ قانون اور عدالت کے پاس ہوتا ہے۔ حقیقی طاقت ظلم کو روکنے اور امن قائم کرنے میں ہے، نہ کہ بدلے کی آگ بھڑکانے میں۔",
            explanationEn = "The Quran establishes a universal charter for human life: whoever takes one innocent life, it is as if they killed all of humanity; and whoever saves a life, it is as if they saved all of humanity. Islam strictly forbids murder, domestic violence, bullying, mob vigilantism, and private revenge. Justice belongs to lawful, accountable institutions—not angry individuals or crowds. True courage protects life and breaks cycles of vengeance.",
            quranArabic = "مَن قَتَلَ نَفْسًا بِغَيْرِ نَفْسٍ أَوْ فَسَادٍ فِي الْأَرْضِ فَكَأَنَّمَا قَتَلَ النَّاسَ جَمِيعًا وَمَنْ أَحْيَاهَا فَكَأَنَّمَا أَحْيَا النَّاسَ جَمِيعًا",
            quranTranslationUr = "جس نے کسی جان کو قتل کیا بغیر کسی جان کے بدلے یا زمین میں فساد پھیلانے کے، تو گویا اس نے تمام انسانوں کو قتل کیا، اور جس نے کسی کی جان بچائی تو گویا اس نے سب انسانوں کی جان بچائی۔",
            quranTranslationEn = "Whoever kills a soul unless for a soul or for corruption in the land—it is as if they had slain mankind entirely; and whoever saves one—it is as if they had saved mankind entirely.",
            quranRefUr = "سورۃ المائدہ 5:32",
            quranRefEn = "Surah Al-Ma'idah 5:32",
            hadithTextUr = "حقیقی مسلمان وہ ہے جس کی زبان اور ہاتھ سے دوسرے لوگ محفوظ رہیں۔",
            hadithTextEn = "A true Muslim is one from whose tongue and hand other people are safe.",
            hadithRefUr = "صحیح بخاری، حدیث 10 / صحیح مسلم، حدیث 40 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 10 / Sahih Muslim, Hadith 40 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول میں بدمعاشی (bullying) یا مار پیٹ کا حصہ نہ بننا اور کسی مظلوم ساتھی کی حفاظت کے لیے استاد یا والدین کو اطلاع دینا۔",
            teenExampleEn = "Refusing to join school bullying or fights, and alerting a teacher or parent if someone is being harmed.",
            youngAdultExampleUr = "کسی بھی اشتعال انگیز ہجوم یا پر تشدد احتجاج سے دور رہنا اور اختلاف کو ہمیشہ پرامن و قانونی دائرے میں رکھنا۔",
            youngAdultExampleEn = "Stepping away from mob anger or violent confrontation and insisting on peaceful, lawful solutions.",
            adultExampleUr = "گھر میں ہاتھ اٹھانے یا دھمکی دینے سے مکمل اجتناب اور خاندانی یا زمینی تنازعات میں انتقام کے بجائے قانون و صلح کا راستہ اپنانا۔",
            adultExampleEn = "Maintaining zero tolerance for physical or verbal abuse at home and choosing lawful mediation over revenge in disputes.",
            keyLessonsUr = listOf(
                "ایک بے گناہ کی جان کی حفاظت پوری انسانیت کی حفاظت کے برابر ہے۔",
                "مسلمان کی زبان اور ہاتھ دونوں سے لوگ محفوظ رہتے ہیں۔",
                "قانون ہاتھ میں لینا اور انتقام لینا معاشرے کو تباہ کر دیتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Protecting one innocent life honors all of humanity.",
                "True faith guarantees safety from one's tongue and hands.",
                "Vigilantism and revenge destroy justice and communal safety."
            ),
            practicalActivityUr = "عہد کریں کہ گھر، گلی اور آن لائن ہر جگہ زبان اور ہاتھ سے کسی کو خوف یا تکلیف نہیں پہنچائیں گے، اور امن کا پیغام عام کریں گے۔",
            practicalActivityEn = "Commit to non-violence in words and actions everywhere—at home, on the street, and online.",
            reflectionPromptUr = "ہمارے معاشرے میں انتقام کے چکر کو روکنے کے لیے ہم بڑوں اور نوجوانوں کی سوچ میں کیا تبدیلی لا سکتے ہیں؟",
            reflectionPromptEn = "How can we help replace cycles of retaliation in our community with lawful peace and patience?",
            goodDeedChallengeUr = "آج کسی کمزور یا پریشان شخص کو تحفظ، حوصلہ یا پرامن مدد فراہم کریں۔",
            goodDeedChallengeEn = "Stand up gently for someone vulnerable today or offer calm reassurance to someone anxious.",
            quiz = listOf(
                QuizQuestion("d19q1", "سورۃ المائدہ (5:32) میں ایک بے گناہ جان بچانے کو کس کے برابر قرار دیا گیا ہے؟", "What does Surah Al-Ma'idah (5:32) compare saving one innocent life to?", listOf("ایک چھوٹی نیکی", "پوری انسانیت کی جان بچانے کے برابر", "صرف اپنے خاندان کو بچانے کے", "کوئی خاص فضیلت نہیں"), listOf("A minor act", "Saving all of humanity", "Saving only one family", "Nothing special"), 1, "اسلام انسانی جان کو غیر معمولی تقدس دیتا ہے۔", "Islam gives every innocent human life sacred value."),
                QuizQuestion("d19q2", "صحیح بخاری کی حدیث کے مطابق حقیقی مسلمان کون ہے؟", "According to Sahih al-Bukhari, who is a true Muslim?", listOf("جو سب سے تیز بولے", "جس کی زبان اور ہاتھ سے دوسرے لوگ محفوظ رہیں", "جو بدلہ لے کر رہے", "جو الگ رہے"), listOf("Loudest speaker", "One from whose tongue and hand people are safe", "One who always retaliates", "One who isolates"), 1, "امن و سلامتی مسلمان کی پہچان ہے۔", "Safety and peace from one's words and hands define a Muslim."),
                QuizQuestion("d19q3", "کسی جرم یا تنازعے کی صورت میں قانون ہاتھ میں لینا (vigilantism) کیسا ہے؟", "How should vigilantism (taking the law into one's own hands) be viewed?", listOf("بہادری ہے", "سخت غلط اور امنِ عامہ کے خلاف ہے", "ضروری ہے", "معمولی بات ہے"), listOf("Brave", "Wrong and destructive to justice and safety", "Necessary", "Minor"), 1, "انصاف کا اختیار صرف قانونی و عدالتی نظام کے پاس ہے۔", "Justice must follow lawful, accountable processes—never mob action."),
                QuizQuestion("d19q4", "گھریلو یا اسکول تشدد کے مقابلے میں اسلام کیا سکھاتا ہے؟", "What does Islam teach regarding domestic or school violence?", listOf("اسے نظر انداز کرنا", "رحمت، عزتِ نفس اور تشدد سے مکمل پرہیز", "سخت سزا کو رواج دینا", "صرف بڑوں کو اجازت"), listOf("Ignore it", "Mercy, dignity, and zero tolerance for abuse", "Encourage harshness", "Allow it for elders"), 1, "نبی کریم ﷺ نے کبھی کسی بچے، عورت یا خادم پر ہاتھ نہیں اٹھایا۔", "The Prophet ﷺ never struck a child, spouse, or servant."),
                QuizQuestion("d19q5", "خاندانی انتقام (دشمنی) کے چکر کو کیسے توڑا جا سکتا ہے؟", "How can generational cycles of revenge be broken?", listOf("زیادہ اسلحہ لے کر", "قانون کی پاسداری، صبر اور باوقار معافی سے", "افواہیں پھیلا کر", "خاموش سازش سے"), listOf("More weapons", "Rule of law, patience, and dignified forgiveness", "Spreading rumors", "Secret plots"), 1, "صبر اور قانون ہی نسلوں کو تباہی سے بچاتے ہیں۔", "Lawful justice and forgiveness protect future generations.")
            )
        ),
        CuratedLesson(
            dayNumber = 20,
            weekNumber = 3,
            categoryIds = listOf("peace_tolerance", "family_life", "unity_brotherhood"),
            titleUr = "تنازعات کا پرامن حل",
            titleEn = "Peaceful Conflict Resolution",
            objectivesUr = listOf(
                "گھریلو، سماجی یا دفتری تنازعات کو بات چیت اور حکمت سے حل کرنے کے مراحل سیکھنا۔",
                "'میں بمقابلہ تم' کے بجائے 'ہم بمقابلہ مسئلہ' کا رویہ اپنانا۔",
                "حدیبیہ اور میثاقِ مدینہ کی طرز پر پرامن معاہدوں کی قدر سمجھنا۔"
            ),
            objectivesEn = listOf(
                "Learn step-by-step tools for resolving family, school, or workplace conflicts peacefully.",
                "Shift mindset from 'me vs. you' to 'us vs. the problem'.",
                "Appreciate Prophetic models of peaceful negotiation like Hudaybiyyah."
            ),
            introUr = "اختلاف ہر انسانی رشتے میں آتا ہے، لیکن عقلمند لوگ مسائل کو جھگڑے کے بجائے بامقصد گفتگو سے حل کرتے ہیں۔",
            introEn = "Disagreements happen in every relationship, yet wise people turn friction into constructive dialogue.",
            explanationUr = "سیرتِ طیبہ ہمیں سکھاتی ہے کہ بڑے سے بڑے بحران کو صبر، بات چیت اور معاہدوں سے حل کیا جا سکتا ہے۔ صلح حدیبیہ میں بظاہر سخت شرائط کے باوجود نبی کریم ﷺ نے امن کو ترجیح دی، جو بعد میں عظیم فتح کا سبب بنی۔ روزمرہ زندگی میں تنازعہ حل کرنے کے چار سنہری اصول ہیں: (1) غصہ ٹھنڈا ہونے تک توقف، (2) دوسرے فریق کی بات بغیر کاٹے سننا، (3) الزام کے بجائے اپنے احساس اور ضرورت کو نرم الفاظ میں بیان کرنا، اور (4) ایسا درمیانی حل نکالنا جس میں دونوں کی عزت محفوظ رہے۔",
            explanationEn = "The Prophetic biography shows that even deep crises can be transformed through dialogue and peace agreements—such as the Treaty of Hudaybiyyah, where prioritizing peace opened the door to lasting success. In everyday life, peaceful conflict resolution follows four clear steps: (1) pause until emotions cool, (2) listen fully without interrupting, (3) express your concern without insults or blame, and (4) look for a fair compromise that preserves everyone's dignity.",
            quranArabic = "وَالصُّلْحُ خَيْرٌ",
            quranTranslationUr = "اور صلح (اور باہمی مصالحت) سب سے بہتر ہے۔",
            quranTranslationEn = "And settlement (reconciliation) is best.",
            quranRefUr = "سورۃ النساء 4:128",
            quranRefEn = "Surah An-Nisa 4:128",
            hadithTextUr = "جو شخص حق پر ہونے کے باوجود جھگڑا چھوڑ دے، میں اس کے لیے جنت کے کنارے ایک گھر کی ضمانت دیتا ہوں۔",
            hadithTextEn = "I guarantee a house in the surroundings of Paradise for the one who gives up arguing even when they are in the right.",
            hadithRefUr = "سنن ابی داؤد، حدیث 4800 (حسن/مستند)",
            hadithRefEn = "Sunan Abi Dawud, Hadith 4800 (Hasan / Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "گروپ پروجیکٹ میں کام کی تقسیم پر جھگڑا ہو تو سب کی پسند سن کر متوازن فہرست بنانا۔",
            teenExampleEn = "Solving a disagreement over a school project by listening to everyone's strengths and splitting tasks fairly.",
            youngAdultExampleUr = "رومیٹ یا دوست سے کرایہ، صفائی یا وقت کی پابندی پر تلخی کے بجائے پرسکون چائے پر بیٹھ کر اصول طے کرنا۔",
            youngAdultExampleEn = "Discussing shared chores or schedules calmly over tea with a roommate instead of passive-aggressive texts.",
            adultExampleUr = "کاروباری یا خاندانی شراکت میں کسی غلط فہمی پر تحریری معاہدے اور غیر جانبدار بزرگ کے مشورے سے معاملہ سلجھانا۔",
            adultExampleEn = "Using clear written agreements and a trusted neutral mediator to settle business or family misunderstandings.",
            keyLessonsUr = listOf(
                "قرآن صلح اور مصالحت کو سب سے بہتر راستہ قرار دیتا ہے۔",
                "حق پر ہونے کے باوجود فضول جھگڑا چھوڑ دینا اعلیٰ کردار ہے۔",
                "بات چیت، سننے کا حوصلہ اور باہمی احترام ہر تنازعے کا حل ہیں۔"
            ),
            keyLessonsEn = listOf(
                "The Quran affirms that peaceful settlement is best.",
                "Walking away from bitter quarrels even when right earns great reward.",
                "Calm listening and mutual respect resolve nearly every conflict."
            ),
            practicalActivityUr = "کسی حالیہ چھوٹے اختلاف کو ذہن میں رکھیں اور 'الزام' کے بجائے 'حل کی تجویز' پر مبنی دو جملے لکھیں۔",
            practicalActivityEn = "Think of a small recent tension and write two calm sentences proposing a fair solution without blaming.",
            reflectionPromptUr = "جب کوئی بحث شروع ہوتی ہے تو کیا میری ترجیح 'جیتنا' ہوتی ہے یا 'مسئلہ حل کرنا اور رشتہ بچانا'؟",
            reflectionPromptEn = "When conflict starts, is my priority winning the point, or solving the issue and saving the relationship?",
            goodDeedChallengeUr = "آج کسی بحث میں اپنی انا چھوڑ کر امن کی خاطر پیچھے ہٹ جائیں یا مصالحت کی پیشکش کریں۔",
            goodDeedChallengeEn = "Step back gracefully from a pointless argument today to preserve warmth and peace.",
            quiz = listOf(
                QuizQuestion("d20q1", "سورۃ النساء (4:128) کا مختصر اور جامع اصول کیا ہے؟", "What concise principle is stated in Surah An-Nisa (4:128)?", listOf("ضد بہتر ہے", "صلح سب سے بہتر ہے (والصلح خیر)", "دوری بہتر ہے", "بحث بہتر ہے"), listOf("Stubbornness is best", "Peaceful settlement is best", "Distance is best", "Debate is best"), 1, "قرآن باہمی رضامندی اور مصالحت کو خیر قرار دیتا ہے۔", "Reconciliation and peaceful settlement bring lasting good."),
                QuizQuestion("d20q2", "سنن ابی داؤد کی حدیث کے مطابق حق پر ہونے کے باوجود جھگڑا چھوڑنے والے کو کیا بشارت دی گئی؟", "What is promised to one who stops arguing even when right, per Sunan Abi Dawud?", listOf("مال میں کمی", "جنت کے کنارے گھر کی ضمانت", "تنہائی", "کوئی اجر نہیں"), listOf("Loss", "A house in the surroundings of Paradise", "Isolation", "No reward"), 1, "بے فائدہ بحث اور تلخی سے بچنا جنت کی بشارت کا مستحق بناتا ہے۔", "Giving up quarrelsome pride earns Paradise."),
                QuizQuestion("d20q3", "تنازعہ حل کرنے کا پہلا عملی قدم کیا ہونا چاہیے؟", "What should be the first step in resolving a conflict?", listOf("فوراً غصے میں جواب دینا", "جذبات ٹھنڈے ہونے تک توقف اور توجہ سے سننا", "پرانی غلطیاں گنوانا", "تیسرے کو بتانا"), listOf("Snap immediately", "Pause to cool down and listen attentively", "Bring up old mistakes", "Gossip to others"), 1, "پرسکون ذہن ہی منصفانہ حل تلاش کر سکتا ہے۔", "Calm listening opens the door to fair solutions."),
                QuizQuestion("d20q4", "سیرتِ نبوی ﷺ میں صلح حدیبیہ ہمیں کیا سکھاتی ہے؟", "What does the Treaty of Hudaybiyyah teach us?", listOf("امن اور معاہدے کے لیے صبر و دور اندیشی اختیار کرنا", "کبھی بات چیت نہ کرنا", "ہمیشہ سخت شرط رکھنا", "وعدہ توڑ دینا"), listOf("Prioritizing peace through patience and foresight", "Refusing negotiation", "Never compromising", "Breaking promises"), 0, "امن کی خاطر صبر طویل مدتی کامیابی کا دروازہ کھولتا ہے۔", "Patient peacemaking yields long-term triumph."),
                QuizQuestion("d20q5", "'ہم بمقابلہ مسئلہ' سوچ کا کیا مطلب ہے؟", "What does the 'us vs. the problem' mindset mean?", listOf("ایک دوسرے کو ہرانا", "مل کر مشترکہ حل نکالنا جس میں سب کی عزت رہے", "الزام لگانا", "بات بند کرنا"), listOf("Defeating the other person", "Working together on a fair solution preserving dignity", "Blaming", "Shutting down"), 1, "اصل دشمن انسان نہیں بلکہ غلط فہمی یا مسئلہ ہوتا ہے۔", "The goal is solving the issue together, not defeating the person.")
            )
        ),
        CuratedLesson(
            dayNumber = 21,
            weekNumber = 3,
            categoryIds = listOf("unity_brotherhood", "peace_tolerance", "quizzes_assessments"),
            titleUr = "ہفتہ وار جائزہ اور عملی امتحان",
            titleEn = "Weekly Review and Practical Assessment",
            objectivesUr = listOf(
                "ہفتہ سوم (اتحاد، امن اور بھائی چارے) کے چھ اسباق کو دہرانا۔",
                "تعصب، فرقہ واریت اور تلخ بحثوں سے بچاؤ میں اپنی پیش رفت جانچنا۔",
                "چوتھے ہفتے (بہتر معاشرے کی تعمیر) کے لیے عملی عزم باندھنا۔"
            ),
            objectivesEn = listOf(
                "Review all Week 3 lessons on Unity, Peace, and Brotherhood.",
                "Assess personal progress in overcoming bias, hostility, and bitter arguments.",
                "Prepare for Week 4: Building a Better Society."
            ),
            introUr = "تین ہفتوں کی تربیت مکمل ہو چکی ہے: نفس کی اصلاح، خاندان کی مضبوطی، اور اب اتحاد و امن کا پیغام۔",
            introEn = "Three weeks are now complete: refining the self, strengthening the family, and building unity and peace.",
            explanationUr = "اس تیسرے ہفتے میں ہم نے سیکھا کہ اسلامی اخوت رنگ و نسل سے بالاتر ہے، اختلافِ رائے ادب کا متقاضی ہے، فرقہ وارانہ نفرت اور تشدد اسلام کے منافی ہیں، اور معافی و پرامن گفتگو سے بڑے سے بڑا جھگڑا سلجھ سکتا ہے۔ اب ہم آخری ہفتے یعنی چوتھے ہفتے میں داخل ہو رہے ہیں جہاں ہم یہ سیکھیں گے کہ ایک باکردار فرد پورے معاشرے میں انصاف، امانت اور خدمتِ خلق کی روشنی کیسے پھیلاتا ہے۔",
            explanationEn = "During Week 3 we learned that brotherhood transcends ethnicity and status, disagreement requires courtesy, sectarianism and violence violate Islam's spirit, and reconciliation heals broken bonds. Now we prepare for Week 4, where personal integrity and peace expand into civic responsibility—fighting corruption, protecting trust, serving the vulnerable, and building a just society.",
            quranArabic = "يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا ۚ إِنَّ أَكْرَمَكُمْ عِندَ اللَّهِ أَتْقَاكُمْ",
            quranTranslationUr = "اے لوگو! ہم نے تمہیں ایک مرد اور ایک عورت سے پیدا کیا اور تمہیں قومیں اور قبیلے بنایا تاکہ تم ایک دوسرے کو پہچانو؛ بے شک اللہ کے نزدیک تم میں سب سے معزز وہ ہے جو سب سے زیادہ پرہیزگار ہے۔",
            quranTranslationEn = "O mankind, We created you from a male and a female and made you peoples and tribes so that you may know one another. Indeed, the most noble of you in the sight of Allah is the most righteous of you.",
            quranRefUr = "سورۃ الحجرات 49:13",
            quranRefEn = "Surah Al-Hujurat 49:13",
            hadithTextUr = "مؤمنوں کی مثال باہمی محبت، رحمدلی اور ہمدردی میں ایک جسم کی طرح ہے؛ جب اس کا ایک عضو تکلیف میں ہو تو پورا جسم بے خوابی اور بخار میں مبتلا رہتا ہے۔",
            hadithTextEn = "The believers in their mutual kindness, compassion, and sympathy are like one body: when one limb aches, the whole body responds with sleeplessness and fever.",
            hadithRefUr = "صحیح بخاری، حدیث 6011 / صحیح مسلم، حدیث 2586 (مستند)",
            hadithRefEn = "Sahih al-Bukhari, Hadith 6011 / Sahih Muslim, Hadith 2586 (Verified)",
            verificationStatus = "VERIFIED",
            teenExampleUr = "اسکول اور دوستی میں امن، شائستگی اور شمولیت کی مثال بننے کا ہفتہ وار جائزہ لینا۔",
            teenExampleEn = "Reviewing how you practiced inclusion, calm speech, and anti-bullying this week.",
            youngAdultExampleUr = "سوشل میڈیا اور کیمپس کے ماحول میں نفرت انگیز گفتگو سے دور رہنے کی پیش رفت دیکھنا۔",
            youngAdultExampleEn = "Checking how consistently you avoided toxic debates and fostered respectful dialogue this week.",
            adultExampleUr = "گھر، خاندان اور محلے میں صلح صفائی اور باہمی احترام کو فروغ دینے کا جائزہ لینا۔",
            adultExampleEn = "Reflecting on how you modeled tolerance and conflict resolution for your family and neighborhood.",
            keyLessonsUr = listOf(
                "انسانی تنوع پہچان اور محبت کے لیے ہے، تفاخر اور نفرت کے لیے نہیں۔",
                "مسلمان ایک جسم کی مانند ہیں؛ ایک کی تکلیف سب کی فکر ہے۔",
                "امن، انصاف اور برداشت سے ہی بہتر معاشرہ وجود میں آتا ہے۔"
            ),
            keyLessonsEn = listOf(
                "Human diversity exists for mutual understanding, never arrogance.",
                "Human sympathy unites believers like one living body.",
                "Peace and tolerance form the bridge to social reform."
            ),
            practicalActivityUr = "ہفتہ سوم کے تمام اسباق میں سے کسی ایک عملی اصول (سلام میں پہل، بحث سے بچاؤ، یا نفرت کی مخالفت) کو اپنی مستقل عادت کے طور پر نوٹ کریں۔",
            practicalActivityEn = "Choose one Week 3 principle (initiating peace, skipping bitter arguments, or rejecting bias) as a permanent personal standard.",
            reflectionPromptUr = "تین ہفتوں کے بعد میں اپنے اندر سب سے بڑی مثبت تبدیلی کیا محسوس کرتا ہوں؟",
            reflectionPromptEn = "After three weeks in this program, what is the clearest positive shift I notice in myself?",
            goodDeedChallengeUr = "آج کسی ایسے فرد کے لیے دعا اور خیر کا پیغام بھیجیں جو کسی مشکل یا تنہائی کا شکار ہو۔",
            goodDeedChallengeEn = "Send a warm message of encouragement and prayer to someone going through a difficult week.",
            quiz = listOf(
                QuizQuestion("d21q1", "سورۃ الحجرات (49:13) کے مطابق مختلف قومیں اور قبیلے بنانے کا مقصد کیا ہے؟", "According to Surah Al-Hujurat (49:13), why were nations and tribes created?", listOf("لڑنے کے لیے", "ایک دوسرے کو پہچاننے اور جاننے کے لیے (لتعارفوا)", "برتری جتانے کے لیے", "الگ رہنے کے لیے"), listOf("To fight", "To know and understand one another", "To boast", "To stay apart"), 1, "تنوع فطرت کی خوبصورتی اور باہمی تعارف کا ذریعہ ہے۔", "Diversity is meant for mutual recognition and respect."),
                QuizQuestion("d21q2", "حدیث میں مؤمنوں کی مثال کس چیز سے دی گئی ہے؟", "What metaphor does the Hadith use for believers' mutual compassion?", listOf("الگ الگ پتھروں سے", "ایک جسم کی طرح", "دو کشتیوں کی طرح", "صحرا کی طرح"), listOf("Separate stones", "One single body", "Two ships", "A desert"), 1, "ہمدردی اور باہمی احساس امت کو ایک جسم کی طرح جوڑتا ہے۔", "Shared empathy binds the community together like one body."),
                QuizQuestion("d21q3", "ہفتہ سوم کا مرکزی پیغام کیا تھا؟", "What was the central theme of Week 3?", listOf("اتحاد، امن، برداشت اور بھائی چارہ", "صرف دولت کمانا", "تنہا زندگی گزارنا", "سخت بحث جیتنا"), listOf("Unity, peace, tolerance, and brotherhood", "Making money only", "Living in isolation", "Winning debates"), 0, "پورا تیسرا ہفتہ سماجی امن اور اخوت کے اصولوں پر مبنی تھا۔", "Week 3 centered on unity, peace, and reconciliation."),
                QuizQuestion("d21q4", "اختلافِ رائے اور فرقہ واریت میں کیا فرق ہے؟", "What is the difference between scholarly difference and sectarianism?", listOf("دونوں ایک ہیں", "اختلافِ رائے ادب و دلیل کے ساتھ ہوتا ہے جبکہ فرقہ واریت نفرت اور تفرقہ پیدا کرتی ہے", "فرقہ واریت اچھی ہے", "ادب ضروری نہیں"), listOf("They are identical", "Difference respects dignity and dialogue; sectarianism breeds hate and division", "Sectarianism is good", "Courtesy is optional"), 1, "ادب اور خیر خواہی اختلاف کو رحمت بناتی ہے، نفرت نہیں۔", "Courtesy turns difference into wisdom; hate turns it into division."),
                QuizQuestion("d21q5", "اگلے یعنی چوتھے ہفتے کا موضوع کیا ہے؟", "What is the focus of the final Week 4?", listOf("بہتر معاشرے کی تعمیر", "چھٹی منانا", "کھیلوں کے اصول", "پچھلے سبق بھول جانا"), listOf("Building a better society", "Taking a break", "Sports rules", "Forgetting earlier lessons"), 0, "چوتھا ہفتہ انصاف، امانت اور خدمتِ خلق کے ذریعے معاشرے کی تعمیر سکھاتا ہے۔", "Week 4 applies character and peace to building a just, caring society.")
            )
        )
    )
}

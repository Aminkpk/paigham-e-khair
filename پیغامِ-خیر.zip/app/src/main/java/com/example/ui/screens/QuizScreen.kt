package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.CuratedLesson
import com.example.ui.theme.VerifiedGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    lesson: CuratedLesson,
    language: AppLanguage,
    onBack: () -> Unit,
    onQuizSubmitted: (scorePercent: Int) -> Unit
) {
    val isUrdu = language.isUrdu
    val questions = lesson.quiz
    var currentIndex by remember { mutableIntStateOf(0) }
    val selectedAnswers = remember { mutableStateMapOf<Int, Int>() }
    var answerChecked by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUrdu) "دن ${lesson.dayNumber} کا کوئز" else "Day ${lesson.dayNumber} Quiz",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("quiz_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (questions.isEmpty()) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (isUrdu) "اس سبق کا کوئز ابھی شامل نہیں کیا گیا۔" else "No quiz questions attached to this lesson yet.",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            } else if (finished) {
                val correctCount = questions.indices.count { idx ->
                    selectedAnswers[idx] == questions[idx].correctIndex
                }
                val scorePercent = ((correctCount * 100f) / questions.size).toInt()

                Column(
                    modifier = Modifier
                        .widthIn(max = 600.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(54.dp)
                            )
                            Text(
                                text = if (isUrdu) "کوئز مکمل ہو گیا!" else "Quiz Completed!",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "$scorePercent% ($correctCount/${questions.size})",
                                style = MaterialTheme.typography.displaySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = if (isUrdu) {
                                    if (scorePercent >= 80) "ماشاءاللہ! شاندار فہم اور توجہ۔" else "اچھی کوشش! سبق کا خلاصہ ایک بار پھر پڑھیں۔"
                                } else {
                                    if (scorePercent >= 80) "MashaAllah! Excellent understanding." else "Good effort! Review the key takeaways anytime."
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    Button(
                        onClick = {
                            onQuizSubmitted(scorePercent)
                            onBack()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("quiz_save_and_finish"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(if (isUrdu) "اسکور محفوظ کریں اور واپس جائیں" else "Save Score & Return")
                    }

                    OutlinedButton(
                        onClick = {
                            selectedAnswers.clear()
                            currentIndex = 0
                            answerChecked = false
                            finished = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                    ) {
                        Text(if (isUrdu) "دوبارہ کوئز دیں" else "Retake Quiz")
                    }
                }
            } else {
                val q = questions[currentIndex]
                val chosen = selectedAnswers[currentIndex]
                val options = if (isUrdu) q.optionsUr else q.optionsEn

                Column(
                    modifier = Modifier
                        .widthIn(max = 640.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isUrdu) "سوال ${currentIndex + 1} از ${questions.size}" else "Question ${currentIndex + 1} of ${questions.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isUrdu) lesson.titleUr else lesson.titleEn,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (currentIndex + 1f) / questions.size.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50))
                    )

                    Text(
                        text = if (isUrdu) q.questionUr else q.questionEn,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    options.forEachIndexed { idx, optText ->
                        val isSelected = chosen == idx
                        val isCorrect = idx == q.correctIndex
                        val borderColor = when {
                            answerChecked && isCorrect -> VerifiedGreen
                            answerChecked && isSelected && !isCorrect -> MaterialTheme.colorScheme.error
                            isSelected -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        }
                        val bgColor = when {
                            answerChecked && isCorrect -> VerifiedGreen.copy(alpha = 0.12f)
                            answerChecked && isSelected && !isCorrect -> MaterialTheme.colorScheme.error.copy(alpha = 0.10f)
                            isSelected -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .clickable(enabled = !answerChecked) {
                                    selectedAnswers[currentIndex] = idx
                                }
                                .testTag("quiz_option_$idx"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = bgColor),
                            border = BorderStroke(if (isSelected || (answerChecked && isCorrect)) 2.dp else 1.dp, borderColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = when {
                                        answerChecked && isCorrect -> Icons.Default.CheckCircle
                                        answerChecked && isSelected && !isCorrect -> Icons.Default.ErrorOutline
                                        isSelected -> Icons.Default.CheckCircle
                                        else -> Icons.Default.RadioButtonUnchecked
                                    },
                                    contentDescription = null,
                                    tint = borderColor
                                )
                                Text(
                                    text = optText,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }
                    }

                    if (answerChecked) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (chosen == q.correctIndex) {
                                        if (isUrdu) "درست جواب!" else "Correct!"
                                    } else {
                                        if (isUrdu) "وضاحت:" else "Explanation:"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isUrdu) q.explanationUr else q.explanationEn,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (!answerChecked) {
                        Button(
                            onClick = { answerChecked = true },
                            enabled = chosen != null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("quiz_check_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(if (isUrdu) "جواب کی تصدیق کریں" else "Check Answer")
                        }
                    } else {
                        Button(
                            onClick = {
                                if (currentIndex + 1 < questions.size) {
                                    currentIndex += 1
                                    answerChecked = false
                                } else {
                                    finished = true
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("quiz_next_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = if (currentIndex + 1 < questions.size) {
                                    if (isUrdu) "اگلا سوال" else "Next Question"
                                } else {
                                    if (isUrdu) "نتیجہ دیکھیں" else "View Result"
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

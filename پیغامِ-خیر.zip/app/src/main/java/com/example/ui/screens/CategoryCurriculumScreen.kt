package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.CuratedLesson
import com.example.data.model.LessonProgress

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryCurriculumScreen(
    titleUr: String,
    titleEn: String,
    categoryFilter: String?,
    lessons: List<CuratedLesson>,
    progressList: List<LessonProgress>,
    language: AppLanguage,
    onBack: () -> Unit,
    onOpenLesson: (Int) -> Unit
) {
    val isUrdu = language.isUrdu
    val filteredLessons = if (categoryFilter.isNullOrBlank()) {
        lessons
    } else {
        lessons.filter { lesson ->
            lesson.categoryIds.any { it.equals(categoryFilter, ignoreCase = true) }
        }.ifEmpty { lessons }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUrdu) titleUr else titleEn,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("category_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isUrdu) {
                                "${filteredLessons.size} اسباق اس شعبے میں شامل ہیں۔ کسی بھی سبق پر ٹیپ کر کے مکمل مطالعہ، آڈیو اور کوئز کھولیں۔"
                            } else {
                                "${filteredLessons.size} curated lessons in this track. Tap any lesson to read, listen, and take the quiz."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                items(filteredLessons, key = { it.dayNumber }) { lesson ->
                    val progress = progressList.firstOrNull { it.lessonDay.toInt() == lesson.dayNumber }
                    LessonSummaryCard(
                        lesson = lesson,
                        progress = progress,
                        isUrdu = isUrdu,
                        onClick = { onOpenLesson(lesson.dayNumber) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedLessonsScreen(
    lessons: List<CuratedLesson>,
    progressList: List<LessonProgress>,
    language: AppLanguage,
    onBack: () -> Unit,
    onOpenLesson: (Int) -> Unit
) {
    val isUrdu = language.isUrdu
    val savedDays = progressList.filter { it.bookmarked }.map { it.lessonDay.toInt() }.toSet()
    val savedLessons = lessons.filter { it.dayNumber in savedDays }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUrdu) "محفوظ اسباق" else "Saved Lessons",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("saved_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (savedLessons.isEmpty()) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 480.dp)
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isUrdu) "ابھی کوئی سبق محفوظ نہیں ہے" else "No saved lessons yet",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isUrdu) {
                            "کسی بھی سبق کے اندر اوپر بک مارک بٹن دبا کر اسے یہاں محفوظ کریں۔"
                        } else {
                            "Open any lesson and tap the bookmark button in the top bar to save it here."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(savedLessons, key = { it.dayNumber }) { lesson ->
                        val progress = progressList.firstOrNull { it.lessonDay.toInt() == lesson.dayNumber }
                        LessonSummaryCard(
                            lesson = lesson,
                            progress = progress,
                            isUrdu = isUrdu,
                            onClick = { onOpenLesson(lesson.dayNumber) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizzesHubScreen(
    lessons: List<CuratedLesson>,
    progressList: List<LessonProgress>,
    language: AppLanguage,
    onBack: () -> Unit,
    onStartQuiz: (Int) -> Unit
) {
    val isUrdu = language.isUrdu
    val quizLessons = lessons.filter { it.quiz.isNotEmpty() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUrdu) "کوئز اور امتحان" else "Quizzes & Assessments",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("quizzes_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = if (isUrdu) {
                                    "ہر دن کے سبق کے 5 معروضی سوالات (کل 150 سوالات)۔ اپنا فہم جانچیں اور بہتر اسکور محفوظ کریں۔"
                                } else {
                                    "5 multiple-choice questions for each of the 30 days (150 total). Test understanding and track your best score."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
                items(quizLessons, key = { it.dayNumber }) { lesson ->
                    val prog = progressList.firstOrNull { it.lessonDay.toInt() == lesson.dayNumber }
                    val best = prog?.bestQuizScore ?: 0L
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .clickable { onStartQuiz(lesson.dayNumber) }
                            .testTag("quiz_hub_day_${lesson.dayNumber}"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (isUrdu) "دن ${lesson.dayNumber}: ${lesson.titleUr}" else "Day ${lesson.dayNumber}: ${lesson.titleEn}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = if (isUrdu) {
                                        if (best > 0) "بہترین اسکور: $best% • ${lesson.quiz.size} سوالات" else "${lesson.quiz.size} سوالات • ابھی حل نہیں ہوا"
                                    } else {
                                        if (best > 0) "Best Score: $best% • ${lesson.quiz.size} questions" else "${lesson.quiz.size} questions • Not attempted"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (best >= 60) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = { onStartQuiz(lesson.dayNumber) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(if (isUrdu) "شروع" else "Start")
                            }
                        }
                    }
                }
            }
        }
    }
}

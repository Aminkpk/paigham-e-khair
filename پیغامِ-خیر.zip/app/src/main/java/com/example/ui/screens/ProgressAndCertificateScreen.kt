package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.CuratedLesson
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.GoodDeedLog
import com.example.data.model.LessonProgress

@Composable
fun ProgressAndCertificateScreen(
    profile: FirestoreUserProfile,
    lessons: List<CuratedLesson>,
    progressList: List<LessonProgress>,
    goodDeedLogs: List<GoodDeedLog>,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isUrdu = language.isUrdu
    val completedDays = progressList.filter { it.completed }.map { it.lessonDay.toInt() }.toSet()
    val quizScores = progressList.filter { it.quizAttempts > 0 }.map { it.bestQuizScore.toInt() }
    val avgQuiz = if (quizScores.isEmpty()) 0 else quizScores.average().toInt()
    val reflections = progressList.filter { it.reflectionText.isNotBlank() }.sortedBy { it.lessonDay }
    val certificateUnlocked = completedDays.size >= 30

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
                .testTag("progress_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = if (isUrdu) "میری پیش رفت اور سرٹیفکیٹ" else "My Progress & Certificate",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Stat Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            icon = Icons.Default.School,
                            label = if (isUrdu) "مکمل اسباق" else "Lessons Done",
                            value = "${completedDays.size}/30",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            icon = Icons.Default.EmojiEvents,
                            label = if (isUrdu) "اوسط کوئز اسکور" else "Avg Quiz Score",
                            value = "$avgQuiz%",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            icon = Icons.Default.Favorite,
                            label = if (isUrdu) "روزانہ نیکیاں" else "Good Deeds",
                            value = "${goodDeedLogs.size}",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            icon = Icons.Default.LocalFireDepartment,
                            label = if (isUrdu) "مسلسل سلسلہ" else "Current Streak",
                            value = if (isUrdu) "${profile.currentStreak} دن" else "${profile.currentStreak} days",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Weekly Progress
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (isUrdu) "ہفتہ وار کارکردگی" else "Weekly Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        (1..4).forEach { week ->
                            val weekDays = lessons.filter { it.weekNumber == week }.map { it.dayNumber }
                            val doneInWeek = weekDays.count { it in completedDays }
                            val totalInWeek = weekDays.size.coerceAtLeast(1)
                            val weekTitle = when (week) {
                                1 -> if (isUrdu) "ہفتہ 1: اصلاحِ نفس" else "Week 1: Self Improvement"
                                2 -> if (isUrdu) "ہفتہ 2: خاندان و ذمہ داری" else "Week 2: Family & Social"
                                3 -> if (isUrdu) "ہفتہ 3: اتحاد و امن" else "Week 3: Unity & Peace"
                                else -> if (isUrdu) "ہفتہ 4: بہتر معاشرہ" else "Week 4: Better Society"
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(weekTitle, style = MaterialTheme.typography.bodySmall)
                                    Text("$doneInWeek/$totalInWeek", style = MaterialTheme.typography.labelSmall)
                                }
                                LinearProgressIndicator(
                                    progress = { doneInWeek.toFloat() / totalInWeek.toFloat() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(7.dp)
                                        .clip(RoundedCornerShape(50))
                                )
                            }
                        }
                    }
                }
            }

            // 30-Day Certificate Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("completion_certificate_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (certificateUnlocked) {
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    border = BorderStroke(
                        width = if (certificateUnlocked) 2.dp else 1.dp,
                        color = if (certificateUnlocked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_certificate_seal),
                            contentDescription = if (isUrdu) "سرٹیفکیٹ کی مہر" else "Certificate seal",
                            modifier = Modifier
                                .size(86.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Text(
                            text = if (isUrdu) "30 روزہ تعلیمی تکمیل کا سرٹیفکیٹ" else "30-Day Course Completion Certificate",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = profile.displayName,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = if (certificateUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = when {
                                    certificateUnlocked && isUrdu -> "مکمل اور جاری کردہ (${completedDays.size}/30 اسباق)"
                                    certificateUnlocked && !isUrdu -> "Unlocked & Awarded (${completedDays.size}/30 Lessons)"
                                    isUrdu -> "مکمل کرنے کے لیے ${30 - completedDays.size} اسباق باقی ہیں"
                                    else -> "${30 - completedDays.size} more lessons needed to unlock"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = if (certificateUnlocked) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                        Text(
                            text = if (isUrdu) {
                                "وضاحت: یہ سند صرف پیغامِ خیر کے 30 روزہ تربیتی کورس کی تکمیل کی علامت ہے؛ یہ کوئی دینی سندِ افتاء یا پیشہ ورانہ ڈگری نہیں ہے۔"
                            } else {
                                "Notice: This certificate recognizes completion of the 30-day Paigham-e-Khair self-development curriculum only and does not grant religious scholarly authority or professional qualification."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Personal Reflections
            item {
                Text(
                    text = if (isUrdu) "میری ذاتی تحریریں اور محاسبہ (${reflections.size})" else "My Saved Reflections (${reflections.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (reflections.isEmpty()) {
                item {
                    Text(
                        text = if (isUrdu) {
                            "اسباق کے اندر 'ذاتی محاسبہ' سیکشن میں لکھی گئی آپ کی یادداشتیں یہاں محفوظ ہوں گی۔"
                        } else {
                            "Notes saved in the Personal Reflection section inside any lesson will appear here."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(reflections, key = { it.lessonDay }) { entry ->
                    val lesson = lessons.firstOrNull { it.dayNumber == entry.lessonDay.toInt() }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (isUrdu) {
                                    "دن ${entry.lessonDay}: ${lesson?.titleUr ?: ""}"
                                } else {
                                    "Day ${entry.lessonDay}: ${lesson?.titleEn ?: ""}"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = entry.reflectionText,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            Text(text = value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

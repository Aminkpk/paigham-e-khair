package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.audio.LessonAudioPlayer
import com.example.data.model.AppLanguage
import com.example.data.model.CuratedLesson
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.LessonProgress
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.ArabicScriptFont

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonDetailScreen(
    lesson: CuratedLesson,
    profile: FirestoreUserProfile,
    progress: LessonProgress?,
    language: AppLanguage,
    audioPlayer: LessonAudioPlayer,
    onBack: () -> Unit,
    onToggleBookmark: (Boolean) -> Unit,
    onToggleCompleted: (Boolean) -> Unit,
    onToggleActivity: (Boolean) -> Unit,
    onSaveReflection: (String) -> Unit,
    onLogGoodDeed: () -> Unit,
    onStartQuiz: () -> Unit,
    onSubmitReport: (String) -> Unit
) {
    val isUrdu = language.isUrdu
    val context = LocalContext.current
    val audioStatus by audioPlayer.status.collectAsState()

    var reflectionText by remember(lesson.dayNumber, progress?.reflectionText) {
        mutableStateOf(progress?.reflectionText ?: "")
    }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    val isBookmarked = progress?.bookmarked == true
    val isCompleted = progress?.completed == true
    val isActivityDone = progress?.activityCompleted == true

    val speechPayload = remember(lesson, isUrdu, profile.ageGroupEnum) {
        if (isUrdu) {
            "${lesson.titleUr}۔ ${lesson.introUr}۔ ${lesson.explanationUr}۔ عملی مثال: ${lesson.exampleFor(profile.ageGroupEnum, true)}"
        } else {
            "${lesson.titleEn}. ${lesson.introEn}. ${lesson.explanationEn}. Practical example: ${lesson.exampleFor(profile.ageGroupEnum, false)}"
        }
    }

    DisposableEffect(lesson.dayNumber) {
        onDispose {
            audioPlayer.pauseOrStop()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isUrdu) "دن ${lesson.dayNumber} • ہفتہ ${lesson.weekNumber}" else "Day ${lesson.dayNumber} • Week ${lesson.weekNumber}",
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("lesson_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onToggleBookmark(!isBookmarked) },
                        modifier = Modifier.testTag("lesson_bookmark_button")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = if (isUrdu) "محفوظ کریں" else "Save lesson",
                            tint = if (isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = { showReportDialog = true },
                        modifier = Modifier.testTag("lesson_report_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = if (isUrdu) "حوالہ یا مواد کی اطلاع دیں" else "Report or request scholarly review"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Lesson Header
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            VerificationBadge(status = lesson.verificationStatus, isUrdu = isUrdu)
                            if (isCompleted) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = if (isUrdu) "مکمل شدہ" else "Completed",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = if (isUrdu) lesson.titleUr else lesson.titleEn,
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isUrdu) lesson.introUr else lesson.introEn,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Audio & Media Section (TTS + Optional Admin Audio/Video Links)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (isUrdu) "آڈیو اور صوتی خواندگی" else "Lesson Audio & Speech Reader",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            Text(
                                text = if (isUrdu) audioStatus.statusNoteUr else audioStatus.statusNoteEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val isPlaying = audioStatus.playbackState == AudioPlaybackState.PLAYING
                                Button(
                                    onClick = {
                                        if (isPlaying) {
                                            audioPlayer.pauseOrStop()
                                        } else {
                                            audioPlayer.play(speechPayload, isUrdu)
                                        }
                                    },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("lesson_tts_play_button")
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = when {
                                            isPlaying && isUrdu -> "روکیں"
                                            isPlaying && !isUrdu -> "Pause"
                                            isUrdu -> "سبق سنیں"
                                            else -> "Listen"
                                        }
                                    )
                                }
                                OutlinedButton(
                                    onClick = { audioPlayer.resumeOrReplay(speechPayload, isUrdu) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Replay,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isUrdu) "دوبارہ" else "Replay")
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                                    FilterChip(
                                        selected = audioStatus.speed == speed,
                                        onClick = { audioPlayer.setSpeed(speed) },
                                        label = { Text("${speed}x") }
                                    )
                                }
                            }

                            if (lesson.audioUrl.startsWith("https://") || lesson.videoUrl.startsWith("https://")) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (lesson.audioUrl.startsWith("https://")) {
                                        OutlinedButton(
                                            onClick = {
                                                runCatching {
                                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lesson.audioUrl)))
                                                }
                                            }
                                        ) {
                                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (isUrdu) "ایڈمن آڈیو کھولیں" else "Open Audio Link")
                                        }
                                    }
                                    if (lesson.videoUrl.startsWith("https://")) {
                                        OutlinedButton(
                                            onClick = {
                                                runCatching {
                                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lesson.videoUrl)))
                                                }
                                            }
                                        ) {
                                            Icon(Icons.Default.OndemandVideo, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (isUrdu) "ویڈیو سبق دیکھیں" else "Watch Video Link")
                                        }
                                    }
                                }
                            } else {
                                Text(
                                    text = if (isUrdu) {
                                        "ریکارڈ شدہ آڈیو/ویڈیو ابھی ایڈمن کی طرف سے منسلک نہیں — تحریری سبق اور ڈیوائس وائس ریڈر دستیاب ہیں۔"
                                    } else {
                                        "Recorded external audio/video has not been attached yet — full text lesson & device speech reader are available."
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Learning Objectives
                item {
                    SectionCard(title = if (isUrdu) "سیکھنے کے مقاصد" else "Learning Objectives") {
                        val objectives = if (isUrdu) lesson.objectivesUr else lesson.objectivesEn
                        objectives.forEach { obj ->
                            Text(
                                text = "• $obj",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Detailed Explanation
                item {
                    SectionCard(title = if (isUrdu) "تفصیلی وضاحت" else "Detailed Explanation") {
                        Text(
                            text = if (isUrdu) lesson.explanationUr else lesson.explanationEn,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Quranic Guidance
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUrdu) "قرآنی رہنمائی" else "Quranic Guidance",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                VerificationBadge(status = lesson.verificationStatus, isUrdu = isUrdu)
                            }
                            if (lesson.quranArabic.isNotBlank()) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                    Text(
                                        text = lesson.quranArabic,
                                        fontFamily = ArabicScriptFont,
                                        fontSize = 22.sp,
                                        lineHeight = 38.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            Text(
                                text = if (isUrdu) lesson.quranTranslationUr else lesson.quranTranslationEn,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isUrdu) "حوالہ: ${lesson.quranRefUr}" else "Reference: ${lesson.quranRefEn}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Authentic Hadith Guidance
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUrdu) "حدیثِ مبارکہ" else "Prophetic Guidance (Hadith)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                VerificationBadge(status = lesson.verificationStatus, isUrdu = isUrdu)
                            }
                            Text(
                                text = if (isUrdu) lesson.hadithTextUr else lesson.hadithTextEn,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isUrdu) "ماخذ: ${lesson.hadithRefUr}" else "Source: ${lesson.hadithRefEn}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Age-Appropriate Practical Example
                item {
                    SectionCard(
                        title = if (isUrdu) {
                            "عملی مثال (${profile.ageGroupEnum.rangeUr})"
                        } else {
                            "Everyday Example (${profile.ageGroupEnum.rangeEn})"
                        }
                    ) {
                        Text(
                            text = lesson.exampleFor(profile.ageGroupEnum, isUrdu),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // 3 Key Lessons
                item {
                    SectionCard(title = if (isUrdu) "یاد رکھنے کی 3 اہم باتیں" else "Three Key Takeaways") {
                        val takeaways = if (isUrdu) lesson.keyLessonsUr else lesson.keyLessonsEn
                        takeaways.forEachIndexed { idx, item ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "${idx + 1}. $item",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                // Practical Activity
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleActivity(!isActivityDone) }
                            .testTag("lesson_activity_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Checkbox(
                                checked = isActivityDone,
                                onCheckedChange = { onToggleActivity(it) },
                                modifier = Modifier.testTag("lesson_activity_checkbox")
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = if (isUrdu) "آج کی عملی سرگرمی" else "Today's Practical Activity",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (isUrdu) lesson.practicalActivityUr else lesson.practicalActivityEn,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                // Reflection Exercise
                item {
                    SectionCard(title = if (isUrdu) "ذاتی محاسبہ (Reflection)" else "Personal Reflection") {
                        Text(
                            text = if (isUrdu) lesson.reflectionPromptUr else lesson.reflectionPromptEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = reflectionText,
                            onValueChange = { reflectionText = it },
                            placeholder = {
                                Text(if (isUrdu) "اپنے خیالات اور عزم یہاں لکھیں..." else "Write your personal thoughts or commitment...")
                            },
                            minLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("lesson_reflection_input")
                        )
                        Button(
                            onClick = { onSaveReflection(reflectionText) },
                            enabled = reflectionText.isNotBlank(),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("save_reflection_button")
                        ) {
                            Text(if (isUrdu) "محاسبہ محفوظ کریں" else "Save Reflection")
                        }
                    }
                }

                // Daily Good Deed Challenge
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isUrdu) "آج کی نیکی کا چیلنج" else "Daily Good Deed Challenge",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Text(
                                text = if (isUrdu) lesson.goodDeedChallengeUr else lesson.goodDeedChallengeEn,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Button(
                                onClick = onLogGoodDeed,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("lesson_log_deed_button")
                            ) {
                                Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (isUrdu) "میں نے یہ نیکی کر لی" else "Log This Good Deed")
                            }
                        }
                    }
                }

                // Quiz & Complete Lesson Actions
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (lesson.quiz.isNotEmpty()) {
                            Button(
                                onClick = onStartQuiz,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("lesson_start_quiz_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(Icons.Default.Quiz, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                val best = progress?.bestQuizScore ?: 0L
                                Text(
                                    text = if (isUrdu) {
                                        if (best > 0) "5 سوالوں کا کوئز (بہترین: $best%)" else "5 سوالوں کا کوئز حل کریں"
                                    } else {
                                        if (best > 0) "Take 5-Question Quiz (Best: $best%)" else "Take 5-Question Quiz"
                                    }
                                )
                            }
                        }

                        Button(
                            onClick = { onToggleCompleted(!isCompleted) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("lesson_complete_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
                                contentColor = if (isCompleted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = when {
                                    isCompleted && isUrdu -> "مکمل شدہ (حالت بدلنے کے لیے ٹیپ کریں)"
                                    isCompleted && !isUrdu -> "Completed (Tap to Undo)"
                                    isUrdu -> "سبق مکمل قرار دیں"
                                    else -> "Mark Lesson Completed"
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = {
                Text(if (isUrdu) "حوالہ یا مواد کی اصلاح کی اطلاع" else "Report Reference / Content")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isUrdu) {
                            "اگر کسی قرآنی یا حدیثی حوالے کی تصدیق یا اصلاح درکار ہو تو تفصیل لکھیں:"
                        } else {
                            "Let administrators know if any reference or text requires scholarly review:"
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (reportReason.isNotBlank()) {
                            onSubmitReport(reportReason)
                            reportReason = ""
                            showReportDialog = false
                        }
                    }
                ) {
                    Text(if (isUrdu) "بھیجیں" else "Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text(if (isUrdu) "منسوخ" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

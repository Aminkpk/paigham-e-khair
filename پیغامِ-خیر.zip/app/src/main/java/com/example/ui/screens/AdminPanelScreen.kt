package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminLesson
import com.example.data.model.AgeGroup
import com.example.data.model.Announcement
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityPost
import com.example.data.model.ContentReport
import com.example.data.model.CuratedLesson
import com.example.data.model.FirestoreUserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    isAdmin: Boolean,
    language: AppLanguage,
    lessons: List<CuratedLesson>,
    announcements: List<Announcement>,
    reports: List<ContentReport>,
    communityPosts: List<CommunityPost>,
    users: List<FirestoreUserProfile>,
    onBack: () -> Unit,
    onSaveAdminLesson: (AdminLesson) -> Unit,
    onPublishAnnouncement: (titleUr: String, titleEn: String, bodyUr: String, bodyEn: String) -> Unit,
    onDeleteAnnouncement: (id: String) -> Unit,
    onAddCustomGoodDeed: (titleUr: String, titleEn: String, category: String) -> Unit,
    onReviewReport: (reportId: String, status: String, note: String) -> Unit,
    onModeratePost: (postId: String, status: String) -> Unit
) {
    val isUrdu = language.isUrdu
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isUrdu) "ایڈمن کنٹرول پینل" else "Administrator Panel")
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "واپس" else "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (!isAdmin) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isUrdu) "اس صفحے تک رسائی صرف مجاز ایڈمن کے لیے ہے۔" else "Access restricted to authorized administrators.",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val tabs = if (isUrdu) {
                listOf("اسباق", "اعلانات/نیکی", "ماڈریشن", "اعداد و شمار")
            } else {
                listOf("Lessons", "Notices/Deeds", "Moderation", "Stats")
            }
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(label, maxLines = 1) }
                    )
                }
            }

            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                when (selectedTab) {
                    0 -> AdminLessonEditorTab(
                        isUrdu = isUrdu,
                        lessons = lessons,
                        onSaveAdminLesson = onSaveAdminLesson
                    )
                    1 -> AdminAnnouncementsAndDeedsTab(
                        isUrdu = isUrdu,
                        announcements = announcements,
                        onPublishAnnouncement = onPublishAnnouncement,
                        onDeleteAnnouncement = onDeleteAnnouncement,
                        onAddCustomGoodDeed = onAddCustomGoodDeed
                    )
                    2 -> AdminModerationTab(
                        isUrdu = isUrdu,
                        reports = reports,
                        communityPosts = communityPosts,
                        onReviewReport = onReviewReport,
                        onModeratePost = onModeratePost
                    )
                    else -> AdminStatsTab(
                        isUrdu = isUrdu,
                        users = users,
                        announcements = announcements,
                        reports = reports
                    )
                }
            }
        }
    }
}

@Composable
private fun AdminLessonEditorTab(
    isUrdu: Boolean,
    lessons: List<CuratedLesson>,
    onSaveAdminLesson: (AdminLesson) -> Unit
) {
    var selectedDay by remember { mutableIntStateOf(1) }
    val current = lessons.firstOrNull { it.dayNumber == selectedDay } ?: lessons.first()

    var titleUr by remember(selectedDay, current.titleUr) { mutableStateOf(current.titleUr) }
    var titleEn by remember(selectedDay, current.titleEn) { mutableStateOf(current.titleEn) }
    var summaryUr by remember(selectedDay, current.introUr) { mutableStateOf(current.introUr) }
    var explanationUr by remember(selectedDay, current.explanationUr) { mutableStateOf(current.explanationUr) }
    var quranRef by remember(selectedDay, current.quranRefUr) { mutableStateOf(current.quranRefUr) }
    var hadithRef by remember(selectedDay, current.hadithRefUr) { mutableStateOf(current.hadithRefUr) }
    var verificationStatus by remember(selectedDay, current.verificationStatus) { mutableStateOf(current.verificationStatus) }
    var audioUrl by remember(selectedDay, current.audioUrl) { mutableStateOf(current.audioUrl) }
    var videoUrl by remember(selectedDay, current.videoUrl) { mutableStateOf(current.videoUrl) }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { if (selectedDay > 1) selectedDay -= 1 }) { Text("-") }
                Text(
                    text = if (isUrdu) "دن $selectedDay / 30" else "Editing Day $selectedDay / 30",
                    style = MaterialTheme.typography.titleMedium
                )
                OutlinedButton(onClick = { if (selectedDay < 30) selectedDay += 1 }) { Text("+") }
            }
        }
        item {
            OutlinedTextField(
                value = titleUr,
                onValueChange = { titleUr = it },
                label = { Text(if (isUrdu) "اردو عنوان" else "Title (Urdu)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = titleEn,
                onValueChange = { titleEn = it },
                label = { Text(if (isUrdu) "انگریزی عنوان" else "Title (English)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = summaryUr,
                onValueChange = { summaryUr = it },
                label = { Text(if (isUrdu) "مختصر تعارف" else "Summary (Urdu)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = explanationUr,
                onValueChange = { explanationUr = it },
                label = { Text(if (isUrdu) "تفصیلی وضاحت" else "Detailed Explanation (Urdu)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = quranRef,
                onValueChange = { quranRef = it },
                label = { Text(if (isUrdu) "قرآنی حوالہ" else "Quran Reference") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = hadithRef,
                onValueChange = { hadithRef = it },
                label = { Text(if (isUrdu) "حدیث حوالہ" else "Hadith Reference") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = verificationStatus == "VERIFIED",
                    onClick = { verificationStatus = "VERIFIED" },
                    label = { Text(if (isUrdu) "مستند (Verified)" else "VERIFIED") }
                )
                FilterChip(
                    selected = verificationStatus == "NEEDS_SCHOLAR_REVIEW",
                    onClick = { verificationStatus = "NEEDS_SCHOLAR_REVIEW" },
                    label = { Text(if (isUrdu) "نظرِ ثانی درکار" else "NEEDS_SCHOLAR_REVIEW") }
                )
            }
        }
        item {
            OutlinedTextField(
                value = audioUrl,
                onValueChange = { audioUrl = it },
                label = { Text("Audio URL (https://..., optional)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = videoUrl,
                onValueChange = { videoUrl = it },
                label = { Text("Video URL (https://..., optional)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    onSaveAdminLesson(
                        AdminLesson(
                            id = "day_$selectedDay",
                            dayNumber = selectedDay.toLong(),
                            weekNumber = current.weekNumber.toLong(),
                            categoryId = current.categoryIds.firstOrNull() ?: "self_improvement",
                            titleUrdu = titleUr,
                            titleEnglish = titleEn,
                            summaryUrdu = summaryUr,
                            explanationUrdu = explanationUr,
                            explanationEnglish = current.explanationEn,
                            quranRef = quranRef,
                            quranArabic = current.quranArabic,
                            quranTranslationUrdu = current.quranTranslationUr,
                            hadithRef = hadithRef,
                            hadithTextUrdu = current.hadithTextUr,
                            verificationStatus = verificationStatus,
                            practicalActivityUrdu = current.practicalActivityUr,
                            goodDeedChallengeUrdu = current.goodDeedChallengeUr,
                            audioUrl = audioUrl.trim(),
                            videoUrl = videoUrl.trim(),
                            published = true
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .minimumInteractiveComponentSize()
            ) {
                Text(if (isUrdu) "سبق کی تبدیلی محفوظ و شائع کریں" else "Save & Publish Lesson Update")
            }
        }
    }
}

@Composable
private fun AdminAnnouncementsAndDeedsTab(
    isUrdu: Boolean,
    announcements: List<Announcement>,
    onPublishAnnouncement: (String, String, String, String) -> Unit,
    onDeleteAnnouncement: (String) -> Unit,
    onAddCustomGoodDeed: (String, String, String) -> Unit
) {
    var annTitleUr by remember { mutableStateOf("") }
    var annTitleEn by remember { mutableStateOf("") }
    var annBodyUr by remember { mutableStateOf("") }
    var annBodyEn by remember { mutableStateOf("") }

    var deedTitleUr by remember { mutableStateOf("") }
    var deedTitleEn by remember { mutableStateOf("") }
    var deedCategory by remember { mutableStateOf("service") }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isUrdu) "نیا اعلان شائع کریں" else "Publish Announcement", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(value = annTitleUr, onValueChange = { annTitleUr = it }, label = { Text("عنوان (اردو)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = annTitleEn, onValueChange = { annTitleEn = it }, label = { Text("Title (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = annBodyUr, onValueChange = { annBodyUr = it }, label = { Text("تفصیل (اردو)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = annBodyEn, onValueChange = { annBodyEn = it }, label = { Text("Body (English)") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        enabled = annTitleUr.isNotBlank() && annBodyUr.isNotBlank(),
                        onClick = {
                            onPublishAnnouncement(annTitleUr, annTitleEn, annBodyUr, annBodyEn)
                            annTitleUr = ""
                            annTitleEn = ""
                            annBodyUr = ""
                            annBodyEn = ""
                        }
                    ) {
                        Text(if (isUrdu) "اعلان شائع کریں" else "Publish Notice")
                    }
                }
            }
        }

        items(announcements, key = { it.id }) { ann ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (isUrdu) ann.titleUrdu else ann.titleEnglish.ifBlank { ann.titleUrdu }, style = MaterialTheme.typography.titleSmall)
                        Text(if (isUrdu) ann.bodyUrdu else ann.bodyEnglish.ifBlank { ann.bodyUrdu }, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { onDeleteAnnouncement(ann.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isUrdu) "نئی کمیونٹی نیکی شامل کریں" else "Add Featured Daily Good Deed", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(value = deedTitleUr, onValueChange = { deedTitleUr = it }, label = { Text("نیکی (اردو)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = deedTitleEn, onValueChange = { deedTitleEn = it }, label = { Text("Good Deed (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = deedCategory, onValueChange = { deedCategory = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        enabled = deedTitleUr.isNotBlank(),
                        onClick = {
                            onAddCustomGoodDeed(deedTitleUr, deedTitleEn.ifBlank { deedTitleUr }, deedCategory)
                            deedTitleUr = ""
                            deedTitleEn = ""
                        }
                    ) {
                        Text(if (isUrdu) "شامل کریں" else "Add Good Deed")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminModerationTab(
    isUrdu: Boolean,
    reports: List<ContentReport>,
    communityPosts: List<CommunityPost>,
    onReviewReport: (String, String, String) -> Unit,
    onModeratePost: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = if (isUrdu) "رپورٹس (${reports.size})" else "User Reports (${reports.size})",
                style = MaterialTheme.typography.titleMedium
            )
        }
        if (reports.isEmpty()) {
            item {
                Text(if (isUrdu) "کوئی زیر التوا رپورٹ نہیں۔" else "No reports submitted.", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            items(reports, key = { it.id }) { report ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${report.targetType} • ${report.targetId} • ${report.status}", style = MaterialTheme.typography.labelMedium)
                        Text(report.reason, style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onReviewReport(report.id, "RESOLVED", "Reviewed by admin") }) {
                                Text(if (isUrdu) "حل شدہ" else "Resolve")
                            }
                            OutlinedButton(onClick = { onReviewReport(report.id, "DISMISSED", "No issue found") }) {
                                Text(if (isUrdu) "مسترد" else "Dismiss")
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (isUrdu) "کمیونٹی پوسٹس (${communityPosts.size})" else "Community Posts (${communityPosts.size})",
                style = MaterialTheme.typography.titleMedium
            )
        }
        items(communityPosts, key = { it.id }) { post ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${post.authorDisplayName} (${post.authorAgeGroup})", style = MaterialTheme.typography.labelMedium)
                    Text(post.content, style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = { onModeratePost(post.id, "HIDDEN") }) {
                        Text(if (isUrdu) "پوسٹ چھپائیں" else "Hide Post")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatsTab(
    isUrdu: Boolean,
    users: List<FirestoreUserProfile>,
    announcements: List<Announcement>,
    reports: List<ContentReport>
) {
    val teens = users.count { it.ageGroupEnum == AgeGroup.TEEN }
    val youngAdults = users.count { it.ageGroupEnum == AgeGroup.YOUNG_ADULT }
    val adults = users.count { it.ageGroupEnum == AgeGroup.ADULT }
    val openReports = reports.count { it.status == "OPEN" }
    val totalCompletedLessons = users.sumOf { it.completedDaysCount }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (isUrdu) "اصل پلیٹ فارم اعداد و شمار" else "Live Platform Analytics",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(if (isUrdu) "کل رجسٹرڈ صارفین: ${users.size}" else "Total Registered Learners: ${users.size}")
                    Text(if (isUrdu) "نوجوان (13–17): $teens" else "Teens (13–17): $teens")
                    Text(if (isUrdu) "نوجوان بالغ (18–25): $youngAdults" else "Young Adults (18–25): $youngAdults")
                    Text(if (isUrdu) "بالغ افراد (26+): $adults" else "Adults (26+): $adults")
                    Text(if (isUrdu) "مجموعی مکمل کردہ اسباق: $totalCompletedLessons" else "Cumulative Completed Lessons: $totalCompletedLessons")
                    Text(if (isUrdu) "فعال اعلانات: ${announcements.size}" else "Active Announcements: ${announcements.size}")
                    Text(if (isUrdu) "زیر التوا رپورٹس: $openReports" else "Open Content Reports: $openReports")
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.CurriculumRepository
import com.example.data.model.CustomGoodDeed
import com.example.data.model.GoodDeedLog

@Composable
fun GoodDeedsScreen(
    goodDeedLogs: List<GoodDeedLog>,
    customGoodDeeds: List<CustomGoodDeed>,
    language: AppLanguage,
    onLogDeed: (deedKey: String, titleUr: String, titleEn: String, category: String, note: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUrdu = language.isUrdu
    var customTitle by remember { mutableStateOf("") }
    var customNote by remember { mutableStateOf("") }
    var showCustomDialog by remember { mutableStateOf(false) }

    var pendingDeed by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var pendingCategory by remember { mutableStateOf("character") }
    var pendingNote by remember { mutableStateOf("") }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = if (isUrdu) "روزانہ نیکی (Daily Good Deed)" else "Daily Good Deeds",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Private, shame-free assurance card
            item {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isUrdu) {
                                "آپ کی نیکیاں صرف اللہ اور آپ کے ذاتی ریکارڈ کے لیے ہیں — کوئی عوامی درجہ بندی یا موازنہ نہیں۔"
                            } else {
                                "Your good deeds stay strictly private for self-encouragement — never publicly ranked or compared."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Quick log custom deed CTA
            item {
                OutlinedButton(
                    onClick = { showCustomDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("open_custom_deed_dialog"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isUrdu) "اپنی ذاتی نیکی ریکارڈ کریں" else "Log Your Own Good Deed")
                }
            }

            // Built-in deeds
            item {
                Text(
                    text = if (isUrdu) "آج کے عملی خیر کے کام" else "Suggested Daily Good Deeds",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(CurriculumRepository.builtInGoodDeeds, key = { it.key }) { deed ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isUrdu) deed.titleUr else deed.titleEn,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = if (isUrdu) deed.categoryUr else deed.categoryEn,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = {
                                pendingDeed = Triple(deed.key, deed.titleUr, deed.titleEn)
                                pendingCategory = deed.categoryEn
                                pendingNote = ""
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("log_deed_${deed.key}")
                        ) {
                            Text(if (isUrdu) "مکمل" else "Done")
                        }
                    }
                }
            }

            // Admin custom good deeds
            if (customGoodDeeds.isNotEmpty()) {
                item {
                    Text(
                        text = if (isUrdu) "خصوصی کمیونٹی نیکیاں" else "Special Featured Good Deeds",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
                items(customGoodDeeds, key = { it.id }) { deed ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isUrdu) deed.titleUrdu else deed.titleEnglish.ifBlank { deed.titleUrdu },
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = deed.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = {
                                    pendingDeed = Triple(
                                        "admin_${deed.id}",
                                        deed.titleUrdu,
                                        deed.titleEnglish.ifBlank { deed.titleUrdu }
                                    )
                                    pendingCategory = deed.category
                                    pendingNote = ""
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(if (isUrdu) "مکمل" else "Done")
                            }
                        }
                    }
                }
            }

            // Personal History
            item {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (isUrdu) "میری ذاتی نیکیوں کا ریکارڈ (${goodDeedLogs.size})" else "My Personal Good Deeds History (${goodDeedLogs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (goodDeedLogs.isEmpty()) {
                item {
                    Text(
                        text = if (isUrdu) {
                            "ابھی تک کوئی نیکی ریکارڈ نہیں کی گئی۔ آج پہلا قدم اٹھائیں!"
                        } else {
                            "No good deeds logged yet. Start with one small act of kindness today!"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(goodDeedLogs, key = { it.id }) { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = if (isUrdu) log.titleUrdu else log.titleEnglish.ifBlank { log.titleUrdu },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (log.note.isNotBlank()) {
                                    Text(
                                        text = log.note,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "${log.dateKey} • ${log.category}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeed?.let { (key, titleUr, titleEn) ->
        AlertDialog(
            onDismissRequest = { pendingDeed = null },
            title = { Text(if (isUrdu) "نیکی محفوظ کریں" else "Record Good Deed") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isUrdu) titleUr else titleEn,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = pendingNote,
                        onValueChange = { pendingNote = it },
                        label = { Text(if (isUrdu) "اختیاری نوٹ" else "Optional personal note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onLogDeed(key, titleUr, titleEn, pendingCategory, pendingNote)
                        pendingDeed = null
                    }
                ) {
                    Text(if (isUrdu) "محفوظ کریں" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeed = null }) {
                    Text(if (isUrdu) "منسوخ" else "Cancel")
                }
            }
        )
    }

    if (showCustomDialog) {
        AlertDialog(
            onDismissRequest = { showCustomDialog = false },
            title = { Text(if (isUrdu) "نئی ذاتی نیکی" else "Log Custom Good Deed") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customTitle,
                        onValueChange = { customTitle = it },
                        label = { Text(if (isUrdu) "آج آپ نے کون سی نیکی کی؟" else "What good deed did you do?") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_deed_title_input")
                    )
                    OutlinedTextField(
                        value = customNote,
                        onValueChange = { customNote = it },
                        label = { Text(if (isUrdu) "مزید تفصیل (اختیاری)" else "Reflection note (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = customTitle.isNotBlank(),
                    onClick = {
                        val trimmed = customTitle.trim()
                        onLogDeed("custom", trimmed, trimmed, "personal", customNote)
                        customTitle = ""
                        customNote = ""
                        showCustomDialog = false
                    },
                    modifier = Modifier.testTag("save_custom_deed_button")
                ) {
                    Text(if (isUrdu) "ریکارڈ کریں" else "Record")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomDialog = false }) {
                    Text(if (isUrdu) "منسوخ" else "Cancel")
                }
            }
        )
    }
}

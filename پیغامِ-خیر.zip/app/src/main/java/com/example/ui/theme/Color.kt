package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette — Serene Islamic Emerald, Ivory, Parchment & Antique Gold
val EmeraldPrimary = Color(0xFF0F4C3A)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFD6EDE3)
val EmeraldOnContainer = Color(0xFF07291E)

val GoldSecondary = Color(0xFFB38327)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldContainer = Color(0xFFF9EBD0)
val GoldOnContainer = Color(0xFF362400)

val TealTertiary = Color(0xFF1F635E)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealContainer = Color(0xFFCDE9E5)
val TealOnContainer = Color(0xFF062624)

val IvoryBackground = Color(0xFFFAF7F0)
val ParchmentSurface = Color(0xFFF3EFE4)
val CardSurface = Color(0xFFFFFFFF)
val SlateInk = Color(0xFF182420)
val MutedSlate = Color(0xFF4F5E58)
val SubtleOutline = Color(0xFFD5D0C3)

// Dark Palette — Night Mosque Emerald & Warm Gold
val DarkEmeraldPrimary = Color(0xFF7FD4B5)
val DarkEmeraldOnPrimary = Color(0xFF003828)
val DarkEmeraldContainer = Color(0xFF13503E)
val DarkEmeraldOnContainer = Color(0xFFD6EDE3)

val DarkGoldSecondary = Color(0xFFE7BD64)
val DarkGoldOnSecondary = Color(0xFF3E2A00)
val DarkGoldContainer = Color(0xFF593E06)
val DarkGoldOnContainer = Color(0xFFF9EBD0)

val DarkTealTertiary = Color(0xFF8BD3CC)
val DarkTealOnTertiary = Color(0xFF003733)
val DarkTealContainer = Color(0xFF1A4F4A)
val DarkTealOnContainer = Color(0xFFCDE9E5)

val DarkMosqueBackground = Color(0xFF0B1714)
val DarkMosqueSurface = Color(0xFF12231E)
val DarkMosqueSurfaceVariant = Color(0xFF1B312A)
val WarmCreamText = Color(0xFFEDEAE0)
val MutedCreamText = Color(0xFFB5C4BD)
val DarkOutline = Color(0xFF2D463E)

// Semantic Status Tokens
val VerifiedGreen = Color(0xFF1B7A4A)
val ReviewAmber = Color(0xFFC77D16)
val SoftErrorRed = Color(0xFFBA1A1A)

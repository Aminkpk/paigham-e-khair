package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Diversity3
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.DashboardSectionId
import com.example.ui.theme.ReviewAmber
import com.example.ui.theme.VerifiedGreen

@Composable
fun LanguageToggleChip(
    currentLanguage: AppLanguage,
    onToggle: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    val nextLang = if (currentLanguage.isUrdu) AppLanguage.ENGLISH else AppLanguage.URDU
    AssistChip(
        onClick = { onToggle(nextLang) },
        modifier = modifier.testTag("language_toggle_chip"),
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Language,
                contentDescription = if (currentLanguage.isUrdu) "زبان تبدیل کریں" else "Switch language",
                modifier = Modifier.size(18.dp)
            )
        },
        label = {
            Text(
                text = if (currentLanguage.isUrdu) "English" else "اردو",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    )
}

@Composable
fun VerificationBadge(
    status: String,
    isUrdu: Boolean,
    modifier: Modifier = Modifier
) {
    val isVerified = status == "VERIFIED"
    val badgeColor = if (isVerified) VerifiedGreen else ReviewAmber
    val icon = if (isVerified) Icons.Default.Verified else Icons.Default.PendingActions
    val text = when {
        isVerified && isUrdu -> "مستند حوالہ"
        isVerified && !isUrdu -> "Verified Source"
        !isVerified && isUrdu -> "علمی نظرِ ثانی درکار"
        else -> "Pending Scholar Review"
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = badgeColor.copy(alpha = 0.14f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = badgeColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun EmeraldBannerBox(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.tertiary
                    )
                )
            )
            .padding(18.dp)
    ) {
        content()
    }
}

fun sectionIconFor(id: DashboardSectionId): ImageVector = when (id) {
    DashboardSectionId.TODAYS_LESSON -> Icons.AutoMirrored.Filled.MenuBook
    DashboardSectionId.SELF_IMPROVEMENT -> Icons.Default.SelfImprovement
    DashboardSectionId.ISLAMIC_CHARACTER -> Icons.Default.CheckCircle
    DashboardSectionId.YOUTH_DEVELOPMENT -> Icons.Default.School
    DashboardSectionId.FAMILY_LIFE -> Icons.Default.FamilyRestroom
    DashboardSectionId.UNITY_BROTHERHOOD -> Icons.Default.Groups
    DashboardSectionId.PEACE_TOLERANCE -> Icons.Default.Handshake
    DashboardSectionId.SOCIAL_REFORM -> Icons.Default.Public
    DashboardSectionId.COMMUNITY_SERVICE -> Icons.Default.VolunteerActivism
    DashboardSectionId.DAILY_GOOD_DEED -> Icons.Default.Favorite
    DashboardSectionId.QUIZZES_ASSESSMENTS -> Icons.Default.Quiz
    DashboardSectionId.MY_PROGRESS -> Icons.AutoMirrored.Filled.TrendingUp
    DashboardSectionId.SAVED_LESSONS -> Icons.Default.Bookmark
    DashboardSectionId.ABOUT_GUIDANCE -> Icons.Default.Info
}

fun sectionAccentColor(id: DashboardSectionId, primary: Color, secondary: Color, tertiary: Color): Color =
    when (id) {
        DashboardSectionId.TODAYS_LESSON,
        DashboardSectionId.SELF_IMPROVEMENT,
        DashboardSectionId.MY_PROGRESS -> primary
        DashboardSectionId.DAILY_GOOD_DEED,
        DashboardSectionId.QUIZZES_ASSESSMENTS,
        DashboardSectionId.ISLAMIC_CHARACTER -> secondary
        else -> tertiary
    }

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AgeGroup
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityPost
import com.example.data.model.FirestoreUserProfile
import com.example.ui.components.LanguageToggleChip

@Composable
fun CommunityServiceScreen(
    profile: FirestoreUserProfile,
    posts: List<CommunityPost>,
    language: AppLanguage,
    onCreatePost: (topic: String, content: String) -> Unit,
    onMarkHelpful: (postId: String) -> Unit,
    onBlockUser: (targetUid: String) -> Unit,
    onReportPost: (postId: String, reason: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUrdu = language.isUrdu
    val isTeen = profile.ageGroupEnum == AgeGroup.TEEN || profile.teenSafeMode
    var selectedTopic by remember { mutableStateOf("ALL") }
    var newPostTopic by remember { mutableStateOf("COMMUNITY_SERVICE") }
    var newPostContent by remember { mutableStateOf("") }
    var reportTargetPost by remember { mutableStateOf<CommunityPost?>(null) }
    var reportReason by remember { mutableStateOf("") }

    val topics = listOf(
        Triple("ALL", "سب", "All"),
        Triple("COMMUNITY_SERVICE", "خدمتِ خلق", "Service"),
        Triple("POSITIVE_DISCUSSION", "مثبت گفتگو", "Discussions"),
        Triple("UNITY_INTERFAITH", "اتحاد و احترام", "Unity & Respect")
    )

    val visiblePosts = remember(posts, selectedTopic) {
        if (selectedTopic == "ALL") posts else posts.filter { it.topic == selectedTopic }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = if (isUrdu) "خدمتِ خلق اور اتحاد فورم" else "Community Service & Unity Hub",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (isTeen) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Text(
                                text = if (isUrdu) {
                                    "نوجوان حفاظتی موڈ: 13–17 سال کے اکاؤنٹس کے لیے عوامی پوسٹنگ اور پرائیویٹ چیٹ بند ہے؛ آپ صرف مثبت خیالات پڑھ سکتے اور سراہ سکتے ہیں۔"
                                } else {
                                    "Teen Safety Mode: Public posting and private messaging are disabled for ages 13–17. You can safely browse and appreciate verified posts."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isUrdu) "مثبت پیغام یا خدمتِ خلق کا تجربہ شیئر کریں" else "Share a Positive Reflection or Service Idea",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(topics.drop(1)) { (code, labelUr, labelEn) ->
                                    FilterChip(
                                        selected = newPostTopic == code,
                                        onClick = { newPostTopic = code },
                                        label = { Text(if (isUrdu) labelUr else labelEn) }
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = newPostContent,
                                onValueChange = { newPostContent = it },
                                placeholder = {
                                    Text(
                                        if (isUrdu) "امن، ہمدردی، یا فلاحی کام کا پیغام لکھیں (پرائیویٹ میسجنگ کی اجازت نہیں)..."
                                        else "Share an uplifting message or community service effort..."
                                    )
                                },
                                minLines = 2,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("community_post_input")
                            )
                            Button(
                                onClick = {
                                    if (newPostContent.isNotBlank()) {
                                        onCreatePost(newPostTopic, newPostContent)
                                        newPostContent = ""
                                    }
                                },
                                enabled = newPostContent.isNotBlank(),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("community_publish_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (isUrdu) "شائع کریں" else "Publish")
                            }
                        }
                    }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(topics) { (code, labelUr, labelEn) ->
                        FilterChip(
                            selected = selectedTopic == code,
                            onClick = { selectedTopic = code },
                            label = { Text(if (isUrdu) labelUr else labelEn) }
                        )
                    }
                }
            }

            if (visiblePosts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Text(
                            text = if (isUrdu) {
                                "اس موضوع میں ابھی کوئی پوسٹ موجود نہیں۔ اتحاد، خیرخواہی اور خدمتِ خلق پر پہلی پوسٹ شیئر کریں۔"
                            } else {
                                "No community posts in this topic yet. Be the first adult learner to share an encouraging message."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(visiblePosts, key = { it.id }) { post ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = post.authorDisplayName.ifBlank { "Learner" },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val topicLabel = topics.firstOrNull { it.first == post.topic }
                                    Text(
                                        text = if (isUrdu) (topicLabel?.second ?: post.topic) else (topicLabel?.third ?: post.topic),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            reportTargetPost = post
                                            reportReason = ""
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Flag,
                                            contentDescription = if (isUrdu) "رپورٹ کریں" else "Report post",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (post.authorUid != profile.userId) {
                                        IconButton(onClick = { onBlockUser(post.authorUid) }) {
                                            Icon(
                                                imageVector = Icons.Default.Block,
                                                contentDescription = if (isUrdu) "صارف کو بلاک کریں" else "Block user",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                            Text(
                                text = post.content,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            TextButton(
                                onClick = { onMarkHelpful(post.id) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (isUrdu) "مفید (${post.helpfulCount})" else "Helpful (${post.helpfulCount})"
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    reportTargetPost?.let { target ->
        AlertDialog(
            onDismissRequest = { reportTargetPost = null },
            title = { Text(if (isUrdu) "پوسٹ کی اطلاع دیں" else "Report Post") },
            text = {
                OutlinedTextField(
                    value = reportReason,
                    onValueChange = { reportReason = it },
                    label = { Text(if (isUrdu) "رپورٹ کی وجہ لکھیں" else "Reason for reporting") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = reportReason.isNotBlank(),
                    onClick = {
                        onReportPost(target.id, reportReason)
                        reportTargetPost = null
                    }
                ) {
                    Text(if (isUrdu) "بھیجیں" else "Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { reportTargetPost = null }) {
                    Text(if (isUrdu) "منسوخ" else "Cancel")
                }
            }
        )
    }
}

@Composable
fun AboutAndGuidanceScreen(
    profile: FirestoreUserProfile,
    language: AppLanguage,
    isAdmin: Boolean,
    onLanguageChange: (AppLanguage) -> Unit,
    onAgeGroupChange: (AgeGroup) -> Unit,
    onOpenAdminPanel: () -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUrdu = language.isUrdu
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUrdu) "ہماری رہنمائی اور ترتیبات" else "About, Guidance & Settings",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    LanguageToggleChip(currentLanguage = language, onToggle = onLanguageChange)
                }
            }

            // Admin Dashboard button strictly for verified admin
            if (isAdmin) {
                item {
                    Button(
                        onClick = onOpenAdminPanel,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("open_admin_panel_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isUrdu) "ایڈمن کنٹرول پینل کھولیں" else "Open Administrator Panel")
                    }
                }
            }

            // Mission card
            item {
                GuidanceCard(
                    title = if (isUrdu) "مشن: پیغامِ خیر" else "Our Mission: Paigham-e-Khair",
                    body = if (isUrdu) {
                        "خود کو بدلیں، اپنے خاندان کو سنواریں، اور ایک بہتر معاشرہ تعمیر کریں۔ ہمارا مقصد قرآن و سنت کی روشنی میں اخلاقی اصلاح، امن، اتحاد، درگزر، عدل اور خدمتِ خلق کا فروغ ہے۔"
                    } else {
                        "Transform Yourself, Improve Your Family, Build a Better Society. We promote character reform, peace, unity, patience, justice, and service to humanity through structured daily education."
                    }
                )
            }

            // Age Path Switcher
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isUrdu) "تعلیمی عمر کا گروپ" else "Learning Path Age Group",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(AgeGroup.entries) { group ->
                                FilterChip(
                                    selected = profile.ageGroupEnum == group,
                                    onClick = { onAgeGroupChange(group) },
                                    label = { Text(if (isUrdu) group.rangeUr else group.rangeEn) }
                                )
                            }
                        }
                    }
                }
            }

            // Reference verification & Safety
            item {
                GuidanceCard(
                    title = if (isUrdu) "مستند حوالہ جات اور حفاظتی اصول" else "Reference Verification & Safety Policy",
                    body = if (isUrdu) {
                        "• تمام قرآنی آیات سورہ اور آیت نمبر کے ساتھ شامل کی گئی ہیں۔\n• احادیث صحیح بخاری، صحیح مسلم، ترمذی اور معتبر کتب سے ماخوذ ہیں۔ غیر مصدقہ حوالہ جات پر 'علمی نظرِ ثانی درکار' کا لیبل ظاہر کیا جاتا ہے۔\n• کسی قسم کی فرقہ واریت، نفرت انگیزی یا تشدد کی حوصلہ افزائی سختی سے ممنوع ہے۔"
                    } else {
                        "• All Quranic citations list exact Surah and Ayah numbers.\n• Hadith references identify the book and verification badge; items awaiting scholarly confirmation are labeled 'Pending Scholar Review'.\n• Sectarianism, violence, and personal shaming are strictly prohibited."
                    }
                )
            }

            // Offline & Cloud Backup
            item {
                GuidanceCard(
                    title = if (isUrdu) "آف لائن رسائی اور کلاؤڈ بیک اپ" else "Offline Access & Cloud Backup",
                    body = if (isUrdu) {
                        "تمام 30 بنیادی اسباق اور 150 کوئز سوالات انٹرنیٹ کے بغیر بھی ایپ میں دستیاب ہیں۔ آن لائن ہونے پر آپ کی پیش رفت، نیکیاں اور محاسبات خودکار طور پر آپ کے Google اکاؤنٹ سے منسلک کلاؤڈ میں محفوظ رہتے ہیں۔"
                    } else {
                        "All 30 core lessons and 150 quiz questions work offline out of the box. When connected, your progress, reflections, and good deeds sync automatically to your Google-authenticated cloud storage."
                    }
                )
            }

            // Account Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("sign_out_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isUrdu) "سائن آؤٹ کریں" else "Sign Out")
                    }

                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("delete_account_data_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isUrdu) "میرا تمام ڈیٹا اور اکاؤنٹ حذف کریں" else "Delete All My Data & Sign Out")
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(if (isUrdu) "ڈیٹا حذف کرنے کی تصدیق" else "Confirm Data Deletion") },
            text = {
                Text(
                    if (isUrdu) {
                        "کیا آپ واقعی اپنی تمام تعلیمی پیش رفت، محاسبات اور نیکیوں کا ریکارڈ مستقل طور پر حذف کرنا چاہتے ہیں؟ یہ عمل واپس نہیں ہو سکے گا۔"
                    } else {
                        "Are you sure you want to permanently delete all your lesson progress, reflections, and good deeds from cloud storage?"
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteAccount()
                    },
                    modifier = Modifier.testTag("confirm_delete_data_button")
                ) {
                    Text(if (isUrdu) "ہاں، حذف کریں" else "Yes, Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(if (isUrdu) "منسوخ" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun GuidanceCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(text = body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.PaighamRepository
import com.example.data.firebase.PreferencesRepository
import com.example.data.model.AdminLesson
import com.example.data.model.AgeGroup
import com.example.data.model.Announcement
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityPost
import com.example.data.model.ContentReport
import com.example.data.model.CuratedLesson
import com.example.data.model.CurriculumRepository
import com.example.data.model.CustomGoodDeed
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.GoodDeedLog
import com.example.data.model.LessonProgress
import com.example.data.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: PaighamRepository,
    private val preferences: PreferencesRepository,
    private val currentUserId: String,
    private val defaultDisplayName: String
) : ViewModel() {

    private val _isAdmin = MutableStateFlow(repository.isBootstrapAdmin())
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val profileState: StateFlow<UiState<FirestoreUserProfile?>> =
        repository.observeUserProfile(currentUserId)
            .toUiState("profile")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val progressList: StateFlow<List<LessonProgress>> =
        repository.observeLessonProgress(currentUserId)
            .catchLogEmpty("lessonProgress")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val goodDeedLogs: StateFlow<List<GoodDeedLog>> =
        repository.observeGoodDeedLogs(currentUserId)
            .catchLogEmpty("goodDeeds")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val announcements: StateFlow<List<Announcement>> =
        repository.observeActiveAnnouncements()
            .catchLogEmpty("announcements")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val customGoodDeeds: StateFlow<List<CustomGoodDeed>> =
        repository.observeActiveCustomGoodDeeds()
            .catchLogEmpty("customGoodDeeds")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val lessons: StateFlow<List<CuratedLesson>> =
        repository.observePublishedAdminLessons()
            .map { adminList -> CurriculumRepository.mergeWithAdminLessons(adminList) }
            .catch { error ->
                val firestoreError = unwrapFirestore(error)
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Using offline bundled curriculum due to error", firestoreError ?: error)
                emit(CurriculumRepository.baseLessons)
            }
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                CurriculumRepository.baseLessons
            )

    val communityPosts: StateFlow<List<CommunityPost>> =
        combine(
            repository.observeApprovedCommunityPosts().catchLogEmpty("communityPosts"),
            profileState
        ) { posts, profileUi ->
            val blocked = (profileUi as? UiState.Success)?.data?.blockedUserIds.orEmpty().toSet()
            posts.filter { it.authorUid !in blocked }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val adminUsers: StateFlow<List<FirestoreUserProfile>> =
        repository.observeAllUsersForAdmin()
            .catchLogEmpty("adminUsers")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val adminReports: StateFlow<List<ContentReport>> =
        repository.observeAllReportsForAdmin()
            .catchLogEmpty("adminReports")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    init {
        viewModelScope.launch {
            _isAdmin.value = repository.checkIsAdmin()
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun saveOnboarding(displayName: String, ageGroup: AgeGroup, language: AppLanguage) {
        val nameToSave = displayName.trim().ifBlank { defaultDisplayName.ifBlank { "Learner" } }
        runAction(
            successUr = "پروفائل محفوظ ہو گئی۔ خوش آمدید!",
            successEn = "Profile saved. Welcome!"
        ) {
            preferences.setLanguage(language)
            repository.saveOnboardingProfile(nameToSave, ageGroup, language)
        }
    }

    fun toggleLanguage(target: AppLanguage) {
        viewModelScope.launch {
            preferences.setLanguage(target)
            try {
                if (repository.getUserProfile(currentUserId) != null) {
                    repository.updateLanguage(target)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed syncing language to cloud", e)
            }
        }
    }

    fun updateAgeGroup(ageGroup: AgeGroup) {
        runAction(
            successUr = "عمر کا گروپ اپ ڈیٹ ہو گیا۔",
            successEn = "Learning path updated."
        ) {
            repository.updateAgeGroup(ageGroup)
        }
    }

    fun markLessonCompleted(dayNumber: Int, completed: Boolean) {
        runAction(
            successUr = if (completed) "ماشاءاللہ! سبق مکمل نشان زد ہو گیا۔" else "سبق کی تکمیل ہٹا دی گئی۔",
            successEn = if (completed) "Lesson marked as completed!" else "Completion removed."
        ) {
            repository.saveLessonProgress(lessonDay = dayNumber, completed = completed)
        }
    }

    fun toggleBookmark(dayNumber: Int, bookmarked: Boolean) {
        runAction(
            successUr = if (bookmarked) "سبق محفوظ کر لیا گیا۔" else "محفوظ فہرست سے ہٹا دیا گیا۔",
            successEn = if (bookmarked) "Lesson saved." else "Removed from saved lessons."
        ) {
            repository.saveLessonProgress(lessonDay = dayNumber, bookmarked = bookmarked)
        }
    }

    fun toggleActivityCompleted(dayNumber: Int, completed: Boolean) {
        runAction(
            successUr = if (completed) "عملی سرگرمی مکمل ہو گئی!" else "عملی سرگرمی کی حالت بدل دی گئی۔",
            successEn = if (completed) "Practical activity marked done!" else "Activity unchecked."
        ) {
            repository.saveLessonProgress(lessonDay = dayNumber, activityCompleted = completed)
        }
    }

    fun saveReflection(dayNumber: Int, reflection: String) {
        runAction(
            successUr = "آپ کا ذاتی محاسبہ محفوظ ہو گیا۔",
            successEn = "Reflection saved securely."
        ) {
            repository.saveLessonProgress(lessonDay = dayNumber, reflectionText = reflection)
        }
    }

    fun submitQuizScore(dayNumber: Int, scorePercent: Int) {
        runAction(
            successUr = "کوئز اسکور ($scorePercent%) محفوظ ہو گیا۔",
            successEn = "Quiz score ($scorePercent%) saved!"
        ) {
            repository.saveLessonProgress(lessonDay = dayNumber, quizScore = scorePercent)
        }
    }

    fun logGoodDeed(
        deedKey: String,
        titleUr: String,
        titleEn: String,
        category: String,
        note: String
    ) {
        runAction(
            successUr = "جزاک اللہ خیر! آج کی نیکی ریکارڈ ہو گئی۔",
            successEn = "Good deed logged! May Allah accept it."
        ) {
            repository.logGoodDeed(deedKey, titleUr, titleEn, category, note)
        }
    }

    fun createCommunityPost(
        displayName: String,
        ageGroup: AgeGroup,
        topic: String,
        content: String
    ) {
        val blockedWords = listOf("hate", "kill", "sectarian", "نفرت", "قتل", "تکفیر")
        if (blockedWords.any { content.contains(it, ignoreCase = true) }) {
            _snackbarMessage.value = "براہ کرم مثبت اور پُرامن الفاظ استعمال کریں۔ / Please keep posts peaceful and constructive."
            return
        }
        runAction(
            successUr = "مثبت پیغام کمیونٹی میں شائع ہو گیا۔",
            successEn = "Your positive post has been published."
        ) {
            repository.createCommunityPost(displayName, ageGroup, topic, content)
        }
    }

    fun markPostHelpful(postId: String) {
        viewModelScope.launch {
            try {
                repository.markPostHelpful(postId)
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Action failed"
            }
        }
    }

    fun blockUser(targetUid: String) {
        runAction(
            successUr = "صارف کی پوسٹس آپ کی فیڈ سے چھپا دی گئی ہیں۔",
            successEn = "User hidden from your community feed."
        ) {
            repository.blockCommunityUser(targetUid)
        }
    }

    fun submitReport(targetType: String, targetId: String, reason: String) {
        runAction(
            successUr = "آپ کی رپورٹ ایڈمن جائزے کے لیے بھیج دی گئی ہے۔",
            successEn = "Report submitted for administrator review."
        ) {
            repository.submitReport(targetType, targetId, reason)
        }
    }

    // Admin Actions
    fun publishAnnouncement(titleUr: String, titleEn: String, bodyUr: String, bodyEn: String) {
        runAction(
            successUr = "اعلان شائع ہو گیا۔",
            successEn = "Announcement published."
        ) {
            repository.publishAnnouncement(titleUr, titleEn, bodyUr, bodyEn)
        }
    }

    fun deleteAnnouncement(id: String) {
        runAction(
            successUr = "اعلان حذف کر دیا گیا۔",
            successEn = "Announcement deleted."
        ) {
            repository.deleteAnnouncement(id)
        }
    }

    fun saveAdminLesson(lesson: AdminLesson) {
        runAction(
            successUr = "سبق کامیابی سے شائع/اپ ڈیٹ ہو گیا۔",
            successEn = "Lesson published/updated successfully."
        ) {
            repository.saveAdminLesson(lesson)
        }
    }

    fun addCustomGoodDeed(titleUr: String, titleEn: String, category: String) {
        runAction(
            successUr = "نئی روزانہ نیکی شامل کر دی گئی۔",
            successEn = "Custom good deed added."
        ) {
            repository.addCustomGoodDeed(titleUr, titleEn, category)
        }
    }

    fun reviewReport(reportId: String, status: String, note: String) {
        runAction(
            successUr = "رپورٹ اپ ڈیٹ کر دی گئی۔",
            successEn = "Report updated."
        ) {
            repository.reviewContentReport(reportId, status, note)
        }
    }

    fun moderatePost(postId: String, status: String) {
        runAction(
            successUr = "پوسٹ کی حیثیت اپ ڈیٹ ہو گئی۔",
            successEn = "Post moderation updated."
        ) {
            repository.moderateCommunityPost(postId, status)
        }
    }

    fun deleteAccountAndData(onComplete: () -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                repository.deleteAllUserData()
                preferences.clearPreferences()
                onComplete()
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to delete user data"
            } finally {
                _isBusy.value = false
            }
        }
    }

    private fun runAction(successUr: String, successEn: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                block()
                val isUr = (profileState.value as? UiState.Success)?.data?.languageEnum?.isUrdu ?: true
                _snackbarMessage.value = if (isUr) successUr else successEn
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Operation failed"
            } finally {
                _isBusy.value = false
            }
        }
    }

    private fun <T> Flow<T>.toUiState(label: String): Flow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = unwrapFirestore(error)
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to observe $label"))
            }

    private fun <T> Flow<List<T>>.catchLogEmpty(label: String): Flow<List<T>> =
        catch { error ->
            val firestoreError = unwrapFirestore(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing $label", firestoreError ?: error)
            emit(emptyList())
        }

    private fun unwrapFirestore(error: Throwable): FirebaseFirestoreException? =
        generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()

    private companion object {
        const val TAG = "MainViewModel"
        const val STOP_TIMEOUT_MS = 5000L
    }
}

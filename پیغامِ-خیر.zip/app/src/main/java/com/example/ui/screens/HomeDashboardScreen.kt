package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AgeGroup
import com.example.data.model.Announcement
import com.example.data.model.AppLanguage
import com.example.data.model.CuratedLesson
import com.example.data.model.CurriculumRepository
import com.example.data.model.DashboardSectionId
import com.example.data.model.DashboardSectionItem
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.LessonProgress
import com.example.ui.components.LanguageToggleChip
import com.example.ui.components.sectionAccentColor
import com.example.ui.components.sectionIconFor

@Composable
fun HomeDashboardScreen(
    profile: FirestoreUserProfile,
    lessons: List<CuratedLesson>,
    progressList: List<LessonProgress>,
    announcements: List<Announcement>,
    language: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    onOpenLesson: (Int) -> Unit,
    onOpenSection: (DashboardSectionItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUrdu = language.isUrdu
    val completedDays = progressList.filter { it.completed }.map { it.lessonDay.toInt() }.toSet()
    val currentDay = ((1..30).firstOrNull { it !in completedDays } ?: 30)
    val currentLesson = lessons.firstOrNull { it.dayNumber == currentDay } ?: lessons.first()

    var selectedWeek by remember { mutableIntStateOf(currentLesson.weekNumber) }
    val weekLessons = remember(lessons, selectedWeek) {
        lessons.filter { it.weekNumber == selectedWeek }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Brand Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "پیغامِ خیر",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isUrdu) {
                                "السلام علیکم، ${profile.displayName} • ${profile.ageGroupEnum.rangeUr}"
                            } else {
                                "Assalamu Alaikum, ${profile.displayName} • ${profile.ageGroupEnum.rangeEn}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LanguageToggleChip(
                        currentLanguage = language,
                        onToggle = onLanguageChange
                    )
                }
            }

            // Teen Safe Mode Banner
            if (profile.ageGroupEnum == AgeGroup.TEEN || profile.teenSafeMode) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = if (isUrdu) {
                                    "نوجوان حفاظتی موڈ فعال ہے — عمر کے مطابق محفوظ مثالیں اور پرائیویٹ چیٹ سے تحفظ۔"
                                } else {
                                    "Teen Safety Mode Active — age-appropriate examples & moderated community protection."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }

            // Hero Today's Lesson Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(225.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_sanctuary),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0x4409281E), Color(0xE60B3226))
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = Color(0x33FFFFFF)
                                    ) {
                                        Text(
                                            text = if (isUrdu) "آج کا سبق • دن ${currentLesson.dayNumber}/30" else "Today's Lesson • Day ${currentLesson.dayNumber}/30",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = Color(0x33E5B85C)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.LocalFireDepartment,
                                                contentDescription = null,
                                                tint = Color(0xFFFFD87D),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = if (isUrdu) "${profile.currentStreak} دن" else "${profile.currentStreak}d streak",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = if (isUrdu) currentLesson.titleUr else currentLesson.titleEn,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (isUrdu) currentLesson.introUr else currentLesson.introEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFE3EFEA),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Button(
                                        onClick = { onOpenLesson(currentLesson.dayNumber) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFE5B85C),
                                            contentColor = Color(0xFF1D1605)
                                        ),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("hero_open_today_lesson")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isUrdu) "سبق شروع کریں" else "Open Today's Lesson",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Active Admin Announcements
            if (announcements.isNotEmpty()) {
                item {
                    val topAnn = announcements.first()
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = if (isUrdu) topAnn.titleUrdu else topAnn.titleEnglish.ifBlank { topAnn.titleUrdu },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                                Text(
                                    text = if (isUrdu) topAnn.bodyUrdu else topAnn.bodyEnglish.ifBlank { topAnn.bodyUrdu },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }
                }
            }

            // 30-Day Progress Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isUrdu) "30 روزہ پروگرام پیش رفت" else "30-Day Program Progress",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${completedDays.size}/30",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        LinearProgressIndicator(
                            progress = { (completedDays.size / 30f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(50))
                        )
                    }
                }
            }

            // All 14 Main Dashboard Sections
            item {
                Text(
                    text = if (isUrdu) "بنیادی شعبہ جات (14)" else "All Program Sections (14)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            val pairs = CurriculumRepository.dashboardSections.chunked(2)
            items(pairs) { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { section ->
                        DashboardSectionCard(
                            section = section,
                            isUrdu = isUrdu,
                            onClick = { onOpenSection(section) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // 30-Day Curriculum Browser
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isUrdu) "مکمل 30 روزہ نصاب" else "Complete 30-Day Curriculum",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items((1..4).toList()) { week ->
                        val label = when (week) {
                            1 -> if (isUrdu) "ہفتہ 1: اصلاحِ نفس" else "Week 1: Self"
                            2 -> if (isUrdu) "ہفتہ 2: خاندان" else "Week 2: Family"
                            3 -> if (isUrdu) "ہفتہ 3: اتحاد و امن" else "Week 3: Unity"
                            else -> if (isUrdu) "ہفتہ 4: معاشرہ" else "Week 4: Society"
                        }
                        FilterChip(
                            selected = selectedWeek == week,
                            onClick = { selectedWeek = week },
                            label = { Text(label) },
                            modifier = Modifier.testTag("week_chip_$week")
                        )
                    }
                }
            }

            items(weekLessons, key = { it.dayNumber }) { lesson ->
                val progress = progressList.firstOrNull { it.lessonDay.toInt() == lesson.dayNumber }
                LessonSummaryCard(
                    lesson = lesson,
                    progress = progress,
                    isUrdu = isUrdu,
                    onClick = { onOpenLesson(lesson.dayNumber) }
                )
            }
        }
    }
}

@Composable
private fun DashboardSectionCard(
    section: DashboardSectionItem,
    isUrdu: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = sectionAccentColor(
        section.id,
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.secondary,
        MaterialTheme.colorScheme.tertiary
    )
    Card(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag("section_card_${section.id.name.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = accent.copy(alpha = 0.14f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = sectionIconFor(section.id),
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Text(
                text = if (isUrdu) section.titleUr else section.titleEn,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (isUrdu) section.subtitleUr else section.subtitleEn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun LessonSummaryCard(
    lesson: CuratedLesson,
    progress: LessonProgress?,
    isUrdu: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = progress?.completed == true
    Card(
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag("lesson_card_day_${lesson.dayNumber}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = if (isUrdu) "مکمل" else "Completed",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text(
                            text = "${lesson.dayNumber}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = if (isUrdu) "دن ${lesson.dayNumber}: ${lesson.titleUr}" else "Day ${lesson.dayNumber}: ${lesson.titleEn}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isUrdu) lesson.introUr else lesson.introEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if ((progress?.bestQuizScore ?: 0L) > 0L) {
                    Text(
                        text = if (isUrdu) "کوئز اسکور: ${progress?.bestQuizScore}%" else "Best Quiz: ${progress?.bestQuizScore}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.audio.LessonAudioPlayer
import com.example.data.firebase.PaighamRepository
import com.example.data.firebase.PreferencesRepository
import com.example.data.model.AppLanguage
import com.example.data.model.DashboardSectionId
import com.example.data.model.FirestoreUserProfile
import com.example.data.model.UiState
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.OnboardingScreen
import com.example.ui.auth.authStateFlow
import com.example.ui.auth.signOutUser
import com.example.ui.screens.AboutAndGuidanceScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.CategoryCurriculumScreen
import com.example.ui.screens.CommunityServiceScreen
import com.example.ui.screens.GoodDeedsScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.ProgressAndCertificateScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.QuizzesHubScreen
import com.example.ui.screens.SavedLessonsScreen
import com.example.ui.theme.PaighamTheme
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

object Routes {
    const val HOME = "home"
    const val DEEDS = "deeds"
    const val PROGRESS = "progress"
    const val COMMUNITY = "community"
    const val GUIDANCE = "guidance"
    const val SAVED = "saved"
    const val QUIZZES = "quizzes"
    const val ADMIN = "admin"
    const val LESSON = "lesson/{day}"
    const val QUIZ = "quiz/{day}"
    const val CATEGORY = "category/{filter}/{titleUr}/{titleEn}"

    fun lesson(day: Int) = "lesson/$day"
    fun quiz(day: Int) = "quiz/$day"
    fun category(filter: String, titleUr: String, titleEn: String) =
        "category/${Uri.encode(filter)}/${Uri.encode(titleUr)}/${Uri.encode(titleEn)}"
}

private data class TopTabItem(
    val route: String,
    val labelUr: String,
    val labelEn: String,
    val icon: ImageVector,
    val tag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PaighamEKhaireApp()
        }
    }
}

@Composable
fun PaighamEKhaireApp() {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val preferences = remember(appContext) { PreferencesRepository(appContext) }
    val savedLanguage by preferences.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.URDU)
    val currentUser by remember { Firebase.auth.authStateFlow() }
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    val audioPlayer = remember(appContext) { LessonAudioPlayer(appContext) }
    DisposableEffect(Unit) {
        onDispose { audioPlayer.release() }
    }

    val user = currentUser
    if (user == null) {
        PaighamTheme(isUrdu = savedLanguage.isUrdu) {
            AuthScreen(
                language = savedLanguage,
                onLanguageChange = { target ->
                    scope.launch { preferences.setLanguage(target) }
                },
                onAuthSuccess = { /* Firebase authStateFlow switches to authenticated graph */ }
            )
        }
        return
    }

    key(user.uid) {
        val repository = remember(appContext, user.uid) { PaighamRepository(appContext) }
        val viewModel: MainViewModel = viewModel(
            key = "main_vm_${user.uid}",
            factory = object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(
                        repository = repository,
                        preferences = preferences,
                        currentUserId = user.uid,
                        defaultDisplayName = user.displayName.orEmpty()
                    ) as T
                }
            }
        )

        val profileState by viewModel.profileState.collectAsStateWithLifecycle()
        val lessons by viewModel.lessons.collectAsStateWithLifecycle()
        val progressList by viewModel.progressList.collectAsStateWithLifecycle()
        val goodDeedLogs by viewModel.goodDeedLogs.collectAsStateWithLifecycle()
        val announcements by viewModel.announcements.collectAsStateWithLifecycle()
        val customGoodDeeds by viewModel.customGoodDeeds.collectAsStateWithLifecycle()
        val communityPosts by viewModel.communityPosts.collectAsStateWithLifecycle()
        val adminUsers by viewModel.adminUsers.collectAsStateWithLifecycle()
        val adminReports by viewModel.adminReports.collectAsStateWithLifecycle()
        val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
        val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
        val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

        val activeProfile = (profileState as? UiState.Success)?.data
        val activeLanguage = activeProfile?.languageEnum ?: savedLanguage

        PaighamTheme(isUrdu = activeLanguage.isUrdu) {
            val snackbarHostState = remember { SnackbarHostState() }
            LaunchedEffect(snackbarMessage) {
                val msg = snackbarMessage
                if (!msg.isNullOrBlank()) {
                    snackbarHostState.showSnackbar(msg)
                    viewModel.clearSnackbar()
                }
            }

            when (profileState) {
                is UiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Success -> {
                    val profile = activeProfile
                    if (profile == null || !profile.onboardingCompleted) {
                        OnboardingScreen(
                            initialName = profile?.displayName ?: user.displayName.orEmpty(),
                            language = activeLanguage,
                            isBusy = isBusy,
                            onLanguageChange = { viewModel.toggleLanguage(it) },
                            onCompleteOnboarding = { name, age, lang ->
                                viewModel.saveOnboarding(name, age, lang)
                            }
                        )
                    } else {
                        AuthenticatedScaffold(
                            profile = profile,
                            language = activeLanguage,
                            isAdmin = isAdmin,
                            lessons = lessons,
                            progressList = progressList,
                            goodDeedLogs = goodDeedLogs,
                            announcements = announcements,
                            customGoodDeeds = customGoodDeeds,
                            communityPosts = communityPosts,
                            adminUsers = adminUsers,
                            adminReports = adminReports,
                            audioPlayer = audioPlayer,
                            snackbarHostState = snackbarHostState,
                            viewModel = viewModel
                        )
                    }
                }
                is UiState.Error -> {
                    val fallbackProfile = FirestoreUserProfile(
                        userId = user.uid,
                        displayName = user.displayName.orEmpty().ifBlank { "Learner" },
                        language = activeLanguage.code,
                        onboardingCompleted = true
                    )
                    AuthenticatedScaffold(
                        profile = fallbackProfile,
                        language = activeLanguage,
                        isAdmin = isAdmin,
                        lessons = lessons,
                        progressList = progressList,
                        goodDeedLogs = goodDeedLogs,
                        announcements = announcements,
                        customGoodDeeds = customGoodDeeds,
                        communityPosts = communityPosts,
                        adminUsers = adminUsers,
                        adminReports = adminReports,
                        audioPlayer = audioPlayer,
                        snackbarHostState = snackbarHostState,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedScaffold(
    profile: FirestoreUserProfile,
    language: AppLanguage,
    isAdmin: Boolean,
    lessons: List<com.example.data.model.CuratedLesson>,
    progressList: List<com.example.data.model.LessonProgress>,
    goodDeedLogs: List<com.example.data.model.GoodDeedLog>,
    announcements: List<com.example.data.model.Announcement>,
    customGoodDeeds: List<com.example.data.model.CustomGoodDeed>,
    communityPosts: List<com.example.data.model.CommunityPost>,
    adminUsers: List<FirestoreUserProfile>,
    adminReports: List<com.example.data.model.ContentReport>,
    audioPlayer: LessonAudioPlayer,
    snackbarHostState: SnackbarHostState,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val isUrdu = language.isUrdu

    val topTabs = listOf(
        TopTabItem(Routes.HOME, "مرکز", "Home", Icons.Default.Home, "nav_home"),
        TopTabItem(Routes.DEEDS, "نیکی", "Deeds", Icons.Default.Favorite, "nav_deeds"),
        TopTabItem(Routes.PROGRESS, "پیش رفت", "Progress", Icons.AutoMirrored.Filled.TrendingUp, "nav_progress"),
        TopTabItem(Routes.COMMUNITY, "خدمت", "Community", Icons.Default.VolunteerActivism, "nav_community"),
        TopTabItem(Routes.GUIDANCE, "رہنمائی", "About", Icons.Default.Info, "nav_guidance")
    )
    val topRoutes = remember(topTabs) { topTabs.map { it.route }.toSet() }
    val showTopLevelNav = currentRoute in topRoutes

    fun navigateTopTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = showTopLevelNav && maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useRail) {
                NavigationRail(
                    modifier = Modifier.fillMaxHeight(),
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    topTabs.forEach { tab ->
                        NavigationRailItem(
                            selected = currentRoute == tab.route,
                            onClick = { navigateTopTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(if (isUrdu) tab.labelUr else tab.labelEn, maxLines = 1) },
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (showTopLevelNav && !useRail) {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            topTabs.forEach { tab ->
                                NavigationBarItem(
                                    selected = currentRoute == tab.route,
                                    onClick = { navigateTopTab(tab.route) },
                                    icon = { Icon(tab.icon, contentDescription = null) },
                                    label = { Text(if (isUrdu) tab.labelUr else tab.labelEn, maxLines = 1) },
                                    modifier = Modifier.testTag(tab.tag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = Routes.HOME,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    composable(Routes.HOME) {
                        HomeDashboardScreen(
                            profile = profile,
                            lessons = lessons,
                            progressList = progressList,
                            announcements = announcements,
                            language = language,
                            onLanguageChange = { viewModel.toggleLanguage(it) },
                            onOpenLesson = { day -> navController.navigate(Routes.lesson(day)) },
                            onOpenSection = { section ->
                                when (section.id) {
                                    DashboardSectionId.TODAYS_LESSON -> {
                                        val completed = progressList.filter { it.completed }.map { it.lessonDay.toInt() }.toSet()
                                        val nextDay = (1..30).firstOrNull { it !in completed } ?: 30
                                        navController.navigate(Routes.lesson(nextDay))
                                    }
                                    DashboardSectionId.DAILY_GOOD_DEED -> navigateTopTab(Routes.DEEDS)
                                    DashboardSectionId.MY_PROGRESS -> navigateTopTab(Routes.PROGRESS)
                                    DashboardSectionId.COMMUNITY_SERVICE -> navigateTopTab(Routes.COMMUNITY)
                                    DashboardSectionId.ABOUT_GUIDANCE -> navigateTopTab(Routes.GUIDANCE)
                                    DashboardSectionId.SAVED_LESSONS -> navController.navigate(Routes.SAVED)
                                    DashboardSectionId.QUIZZES_ASSESSMENTS -> navController.navigate(Routes.QUIZZES)
                                    else -> {
                                        val filter = section.categoryFilter ?: "self_improvement"
                                        navController.navigate(Routes.category(filter, section.titleUr, section.titleEn))
                                    }
                                }
                            }
                        )
                    }

                    composable(Routes.DEEDS) {
                        GoodDeedsScreen(
                            goodDeedLogs = goodDeedLogs,
                            customGoodDeeds = customGoodDeeds,
                            language = language,
                            onLogDeed = { key, titleUr, titleEn, cat, note ->
                                viewModel.logGoodDeed(key, titleUr, titleEn, cat, note)
                            }
                        )
                    }

                    composable(Routes.PROGRESS) {
                        ProgressAndCertificateScreen(
                            profile = profile,
                            lessons = lessons,
                            progressList = progressList,
                            goodDeedLogs = goodDeedLogs,
                            language = language
                        )
                    }

                    composable(Routes.COMMUNITY) {
                        CommunityServiceScreen(
                            profile = profile,
                            posts = communityPosts,
                            language = language,
                            onCreatePost = { topic, content ->
                                viewModel.createCommunityPost(
                                    displayName = profile.displayName,
                                    ageGroup = profile.ageGroupEnum,
                                    topic = topic,
                                    content = content
                                )
                            },
                            onMarkHelpful = { viewModel.markPostHelpful(it) },
                            onBlockUser = { viewModel.blockUser(it) },
                            onReportPost = { postId, reason ->
                                viewModel.submitReport("COMMUNITY_POST", postId, reason)
                            }
                        )
                    }

                    composable(Routes.GUIDANCE) {
                        AboutAndGuidanceScreen(
                            profile = profile,
                            language = language,
                            isAdmin = isAdmin,
                            onLanguageChange = { viewModel.toggleLanguage(it) },
                            onAgeGroupChange = { viewModel.updateAgeGroup(it) },
                            onOpenAdminPanel = { navController.navigate(Routes.ADMIN) },
                            onSignOut = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope
                                )
                            },
                            onDeleteAccount = {
                                viewModel.deleteAccountAndData {
                                    signOutUser(credentialManager = credentialManager, scope = scope)
                                }
                            }
                        )
                    }

                    composable(Routes.SAVED) {
                        SavedLessonsScreen(
                            lessons = lessons,
                            progressList = progressList,
                            language = language,
                            onBack = { navController.popBackStack() },
                            onOpenLesson = { day -> navController.navigate(Routes.lesson(day)) }
                        )
                    }

                    composable(Routes.QUIZZES) {
                        QuizzesHubScreen(
                            lessons = lessons,
                            progressList = progressList,
                            language = language,
                            onBack = { navController.popBackStack() },
                            onStartQuiz = { day -> navController.navigate(Routes.quiz(day)) }
                        )
                    }

                    composable(
                        route = Routes.CATEGORY,
                        arguments = listOf(
                            navArgument("filter") { type = NavType.StringType },
                            navArgument("titleUr") { type = NavType.StringType },
                            navArgument("titleEn") { type = NavType.StringType }
                        )
                    ) { backStack ->
                        val filter = Uri.decode(backStack.arguments?.getString("filter").orEmpty())
                        val titleUr = Uri.decode(backStack.arguments?.getString("titleUr").orEmpty())
                        val titleEn = Uri.decode(backStack.arguments?.getString("titleEn").orEmpty())
                        CategoryCurriculumScreen(
                            titleUr = titleUr,
                            titleEn = titleEn,
                            categoryFilter = filter,
                            lessons = lessons,
                            progressList = progressList,
                            language = language,
                            onBack = { navController.popBackStack() },
                            onOpenLesson = { day -> navController.navigate(Routes.lesson(day)) }
                        )
                    }

                    composable(
                        route = Routes.LESSON,
                        arguments = listOf(navArgument("day") { type = NavType.IntType })
                    ) { backStack ->
                        val day = backStack.arguments?.getInt("day") ?: 1
                        val lesson = lessons.firstOrNull { it.dayNumber == day } ?: lessons.first()
                        val progress = progressList.firstOrNull { it.lessonDay.toInt() == day }
                        LessonDetailScreen(
                            lesson = lesson,
                            profile = profile,
                            progress = progress,
                            language = language,
                            audioPlayer = audioPlayer,
                            onBack = { navController.popBackStack() },
                            onToggleBookmark = { viewModel.toggleBookmark(day, it) },
                            onToggleCompleted = { viewModel.markLessonCompleted(day, it) },
                            onToggleActivity = { viewModel.toggleActivityCompleted(day, it) },
                            onSaveReflection = { viewModel.saveReflection(day, it) },
                            onLogGoodDeed = {
                                viewModel.logGoodDeed(
                                    deedKey = "lesson_day_$day",
                                    titleUr = lesson.goodDeedChallengeUr,
                                    titleEn = lesson.goodDeedChallengeEn,
                                    category = "lesson_challenge",
                                    note = if (isUrdu) "دن $day کا سبق" else "Day $day Challenge"
                                )
                            },
                            onStartQuiz = { navController.navigate(Routes.quiz(day)) },
                            onSubmitReport = { reason ->
                                viewModel.submitReport("LESSON", "day_$day", reason)
                            }
                        )
                    }

                    composable(
                        route = Routes.QUIZ,
                        arguments = listOf(navArgument("day") { type = NavType.IntType })
                    ) { backStack ->
                        val day = backStack.arguments?.getInt("day") ?: 1
                        val lesson = lessons.firstOrNull { it.dayNumber == day } ?: lessons.first()
                        QuizScreen(
                            lesson = lesson,
                            language = language,
                            onBack = { navController.popBackStack() },
                            onQuizSubmitted = { score -> viewModel.submitQuizScore(day, score) }
                        )
                    }

                    composable(Routes.ADMIN) {
                        AdminPanelScreen(
                            isAdmin = isAdmin,
                            language = language,
                            lessons = lessons,
                            announcements = announcements,
                            reports = adminReports,
                            communityPosts = communityPosts,
                            users = adminUsers,
                            onBack = { navController.popBackStack() },
                            onSaveAdminLesson = { viewModel.saveAdminLesson(it) },
                            onPublishAnnouncement = { tUr, tEn, bUr, bEn ->
                                viewModel.publishAnnouncement(tUr, tEn, bUr, bEn)
                            },
                            onDeleteAnnouncement = { viewModel.deleteAnnouncement(it) },
                            onAddCustomGoodDeed = { tUr, tEn, cat ->
                                viewModel.addCustomGoodDeed(tUr, tEn, cat)
                            },
                            onReviewReport = { id, status, note ->
                                viewModel.reviewReport(id, status, note)
                            },
                            onModeratePost = { id, status ->
                                viewModel.moderatePost(id, status)
                            }
                        )
                    }
                }
            }
        }
    }
}

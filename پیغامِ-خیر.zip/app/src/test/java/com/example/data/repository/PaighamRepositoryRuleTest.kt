package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.firebase.PaighamRepository
import com.example.data.model.AgeGroup
import com.example.data.model.AppLanguage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class PaighamRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun onboardingAndLessonProgress_authenticatedOwner_succeedsAndSyncsStats() = runBlocking {
        val uid = signInTestUser("learner1@test.com")
        val repository = PaighamRepository(firestore, auth)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveOnboardingProfile(
                displayName = "Amina",
                ageGroup = AgeGroup.YOUNG_ADULT,
                language = AppLanguage.URDU
            )
            repository.saveLessonProgress(
                lessonDay = 1,
                completed = true,
                bookmarked = true,
                activityCompleted = true,
                reflectionText = "Reflecting on truthfulness today.",
                quizScore = 100
            )
        }

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) { repository.getUserProfile(uid) }
        assertNotNull(profile)
        assertEquals("Amina", profile?.displayName)
        assertEquals(1L, profile?.completedDaysCount)

        val progressList = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeLessonProgress(uid).first { it.any { p -> p.lessonDay == 1L } }
        }
        assertTrue(progressList.any { it.lessonDay == 1L && it.completed && it.bestQuizScore == 100L })
    }

    @Test
    fun goodDeedLogging_authenticatedOwner_persistsAndIncrementsTotal() = runBlocking {
        val uid = signInTestUser("learner2@test.com")
        val repository = PaighamRepository(firestore, auth)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveOnboardingProfile("Bilal", AgeGroup.TEEN, AppLanguage.URDU)
            repository.logGoodDeed(
                deedKey = "respect_parents",
                titleUrdu = "والدین کا ادب",
                titleEnglish = "Respect parents",
                category = "family",
                note = "Helped at home"
            )
        }

        val deeds = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeGoodDeedLogs(uid).first { it.isNotEmpty() }
        }
        assertEquals("respect_parents", deeds.first().deedKey)

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) { repository.getUserProfile(uid) }
        assertEquals(true, profile?.teenSafeMode)
        assertEquals(1L, profile?.totalGoodDeedsCount)
    }

    @Test
    fun crossUserProfileAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser("alice_rule@test.com")
        val aliceRepo = PaighamRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveOnboardingProfile("Alice", AgeGroup.ADULT, AppLanguage.ENGLISH)
        }

        signInTestUser("bob_rule@test.com")
        val bobRepo = PaighamRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getUserProfile(aliceUid)
            }
            fail("Expected PERMISSION_DENIED when reading another user's profile")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    @Test
    fun observeLessonProgress_unauthenticated_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = PaighamRepository(firestore, auth)
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeLessonProgress("some_user_123").first()
            }
            fail("Expected PERMISSION_DENIED for unauthenticated listener")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    @Test
    fun teenUser_cannotPublishOpenCommunityPost() = runBlocking {
        signInTestUser("teen_rule@test.com")
        val repo = PaighamRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.createCommunityPost(
                    authorDisplayName = "TeenUser",
                    authorAgeGroup = AgeGroup.TEEN,
                    topic = "POSITIVE_DISCUSSION",
                    content = "Hello everyone"
                )
            }
            fail("Expected IllegalArgumentException for TEEN user community post")
        } catch (_: IllegalArgumentException) {
            // Expected client & rule safeguard
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}

package com.example

import com.example.data.model.AgeGroup
import com.example.data.model.CurriculumRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun curriculum_hasAll30DaysAcross4WeeksWith150QuizQuestions() {
        val lessons = CurriculumRepository.baseLessons
        assertEquals(30, lessons.size)
        assertEquals((1..30).toList(), lessons.map { it.dayNumber })

        val totalQuestions = lessons.sumOf { it.quiz.size }
        assertEquals(150, totalQuestions)

        lessons.forEach { lesson ->
            assertTrue("Day ${lesson.dayNumber} missing Urdu title", lesson.titleUr.isNotBlank())
            assertTrue("Day ${lesson.dayNumber} missing English title", lesson.titleEn.isNotBlank())
            assertTrue("Day ${lesson.dayNumber} missing Quran ref", lesson.quranRefUr.isNotBlank())
            assertTrue("Day ${lesson.dayNumber} missing Hadith ref", lesson.hadithRefUr.isNotBlank())
            assertEquals("Day ${lesson.dayNumber} must have 3 key takeaways", 3, lesson.keyLessonsUr.size)
            assertEquals("Day ${lesson.dayNumber} must have 5 quiz questions", 5, lesson.quiz.size)
            AgeGroup.entries.forEach { age ->
                assertTrue(
                    "Day ${lesson.dayNumber} missing example for $age",
                    lesson.exampleFor(age, true).isNotBlank()
                )
            }
        }
    }

    @Test
    fun dashboard_containsAll14SectionsAndBuiltInGoodDeeds() {
        assertEquals(14, CurriculumRepository.dashboardSections.size)
        assertTrue(CurriculumRepository.builtInGoodDeeds.size >= 8)
    }
}

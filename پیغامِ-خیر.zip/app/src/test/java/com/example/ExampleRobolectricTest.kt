package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AgeGroup
import com.example.data.model.AppLanguage
import com.example.data.model.CurriculumRepository
import com.example.data.model.FirestoreUserProfile
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.ProgressAndCertificateScreen
import com.example.ui.theme.PaighamTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun readAppNameFromContext_matchesPaighamEKhair() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("پیغامِ خیر", appName)
    }

    @Test
    fun homeDashboard_displaysUrduTitleAndTeenSafetyBanner() {
        val teenProfile = FirestoreUserProfile(
            userId = "teen_1",
            displayName = "بلال",
            ageGroup = AgeGroup.TEEN.code,
            language = AppLanguage.URDU.code,
            onboardingCompleted = true,
            teenSafeMode = true
        )

        composeRule.setContent {
            PaighamTheme(isUrdu = true) {
                HomeDashboardScreen(
                    profile = teenProfile,
                    lessons = CurriculumRepository.baseLessons,
                    progressList = emptyList(),
                    announcements = emptyList(),
                    language = AppLanguage.URDU,
                    onLanguageChange = {},
                    onOpenLesson = {},
                    onOpenSection = {}
                )
            }
        }

        composeRule.onNodeWithText("پیغامِ خیر").assertIsDisplayed()
        composeRule.onNodeWithTag("hero_open_today_lesson").assertIsDisplayed()
        composeRule.onNodeWithTag("language_toggle_chip").assertIsDisplayed()
    }

    @Test
    fun progressScreen_displaysCertificateCardAndDisclaimer() {
        val adultProfile = FirestoreUserProfile(
            userId = "adult_1",
            displayName = "Ayesha",
            ageGroup = AgeGroup.ADULT.code,
            language = AppLanguage.ENGLISH.code,
            onboardingCompleted = true
        )

        composeRule.setContent {
            PaighamTheme(isUrdu = false) {
                ProgressAndCertificateScreen(
                    profile = adultProfile,
                    lessons = CurriculumRepository.baseLessons,
                    progressList = emptyList(),
                    goodDeedLogs = emptyList(),
                    language = AppLanguage.ENGLISH
                )
            }
        }

        composeRule.onNodeWithTag("progress_list")
            .performScrollToNode(hasTestTag("completion_certificate_card"))
        composeRule.onNodeWithTag("completion_certificate_card")
            .assertIsDisplayed()
    }
}

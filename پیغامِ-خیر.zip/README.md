# پیغامِ خیر — Paigham-e-Khair

**Tagline:** Transform Yourself, Improve Your Family, Build a Better Society.  
**Mission:** Promote moral development, Islamic values, peace, unity, compassion, justice, tolerance, family harmony, and service to humanity through structured daily education and practical activities.

---

## Key Features Implemented

- **Bilingual RTL-First Experience:** Primary **Urdu** (`LayoutDirection.Rtl`) with bundled local Google Fonts (`Noto Nastaliq Urdu`, `Noto Sans Arabic`, `Amiri`) and secondary **English** (`LayoutDirection.Ltr` with `Plus Jakarta Sans`), switchable dynamically across the app.
- **3 Age-Appropriate Learning Paths:**
  - **Teenagers (13–17):** Age-tailored examples plus **Teen Safe Mode** (disables open public posting and eliminates private messaging).
  - **Young Adults (18–25):** Higher education, career integrity, character growth, and civic leadership.
  - **Adults (26+):** Family harmony, raising children, workplace honesty, neighborhood care, and social reform.
- **14 Functional Dashboard Sections:**
  1. آج کا سبق (Today's Lesson)
  2. اصلاحِ نفس (Self Improvement)
  3. اسلامی اخلاق (Islamic Character)
  4. نوجوانوں کی تربیت (Youth Development)
  5. خاندانی زندگی (Family Life)
  6. اتحاد و بھائی چارہ (Unity & Brotherhood)
  7. امن و برداشت (Peace & Tolerance)
  8. معاشرتی اصلاح (Social Reform)
  9. خدمتِ خلق (Community Service & Moderated Unity Hub)
  10. روزانہ نیکی (Daily Good Deed Tracker — strictly private, no public shaming/ranking)
  11. کوئز اور امتحان (Quizzes & Assessments — 150 questions across 30 days)
  12. میری پیش رفت (My Progress, Streak & 30-Day Completion Certificate with clear educational disclaimer)
  13. محفوظ اسباق (Saved/Bookmarked Lessons)
  14. ہماری رہنمائی (About, Scholarly Verification Policy, Offline/Backup Info, Privacy Deletion, & Role-Gated Admin Panel)
- **Complete 30-Day Curriculum:** Every lesson includes learning objectives, introduction, detailed explanation, verified Quranic guidance (Surah:Ayah), authentic Hadith with source & verification badge (`VERIFIED` / `NEEDS_SCHOLAR_REVIEW`), age-tailored everyday example, 3 key takeaways, practical activity, 5-question interactive quiz, reflection journal, daily good deed challenge, and completion tracking.
- **Audio & Media Support:** On-device Android `TextToSpeech` reader (`0.75x–1.5x`) with honest voice availability detection plus optional Admin-linked external audio/video URLs.
- **Firebase Cloud Sync & Offline Persistence:** Google Sign-In via Jetpack Credential Manager, Firestore offline persistence (`PersistentCacheSettings`), and zero-trust Firestore Security Rules.

---

## Building the Android APK

> **Note:** Prebuilt `.apk` files are not checked into source control. Follow the Gradle commands below to build Debug or Release APKs locally or in CI.

### Debug APK
```bash
gradle assembleDebug
```
The compiled debug APK will be output to:
`app/build/outputs/apk/debug/app-debug.apk`

### Signed Release APK (Google Play / Distribution)
Configure your upload keystore credentials via environment variables (do **not** commit keystores or secrets):
```bash
export KEYSTORE_PATH=/path/to/my-upload-key.jks
export STORE_PASSWORD=your_store_password
export KEY_PASSWORD=your_key_password

gradle assembleRelease
```
The signed release APK will be output to:
`app/build/outputs/apk/release/app-release.apk`

---

## Firebase & Security Rules Setup

- **Authentication:** Google Sign-In via Android Jetpack `CredentialManager`. Ensure SHA-1 / SHA-256 signing fingerprints of your keystore are registered in the Firebase Console (`app/google-services.json` already contains the debug configuration for `com.aistudio.paighamekhair.vqrmzt`).
- **Firestore Database:** Named database configured in `app/src/main/res/values/firebase_applet_config.xml` (`firestore_database_id`).
- **Security Rules (`firestore.rules`):** Enforces per-user ownership on `/users/{userId}` subcollections, Teen Safe Mode on `/communityPosts`, and verified admin access on `/lessons`, `/announcements`, `/customGoodDeeds`, and `/contentReports`.

### Running Tests Locally
- **Firestore JS Rules Tests:**
  ```bash
  FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
  ```
- **Android Unit & Robolectric Tests:**
  ```bash
  gradle :app:testDebugUnitTest
  ```
